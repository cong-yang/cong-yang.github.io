function [ DistanceMatrix, AngleMatrix ] = f_get_Point_Feature( segpoints )
%f_get_Point_Feature: this function is used to generate point featues. 
%   input: 
%         segpoints: all point lists
%   output:
%         DistanceMatrix: a matrix of their distance
%         AngleMatrix: matrix of all points angles

mylength = length(segpoints);
DistanceMatrix = zeros(mylength,mylength);
AngleMatrix = zeros(mylength,mylength);

for i = 1:mylength
    p1 = segpoints(i,:);
    for j = 1:mylength
        p2 = segpoints(j,:);
        DistanceMatrix(i,j) = log((sqrt(sum((p1 - p2).^2))) + 1);
        p3 = p1 - p2;
        AngleMatrix(i,j) = atan2(p3(1),p3(2));
    end
end

end
