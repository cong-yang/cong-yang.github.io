function [ bool_edgeneibhgour ] = f_is_edge_neighbor( x1, y1, x2, y2 )
%f_is_edge_neighbor: check if the coordinates specified by the 
%                    parameter are edge neighbor coordinates.
%   010
%   121
%   010
%   like upper example, all 1 are edge neibhtour of 2, all 0 are vertex
%   neighbour of 2.

% input:
%       point1_cox: x axis of the point1
%       point1_coy: y axis of the point1
%       point2_cox: x axis of the point2
%       point2_coy: y axis of the point2

% output:
%       bool_edgeneibhgour: edge neighbour(1) or not(0).

bool_edgeneibhgour = 0;

% upper neighbor
if x1 == x2 && (y1 == y2 - 1)
    bool_edgeneibhgour = 1;
    return;
end

%lower neighbor
if x1 == x2 && (y1 == y2 + 1)
    bool_edgeneibhgour = 1;
    return;
end

%left neighbor
if x1 == (x2 - 1) && (y1 == y2)
    bool_edgeneibhgour = 1;
    return;
end

%right neighbour
if x1 == (x2 + 1) && (y1 == y2)
    bool_edgeneibhgour = 1;
    return;
end

end

