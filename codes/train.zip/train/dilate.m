function [ nBW ] = dilate( BW )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
nBW = BW;
%dilatewhite
for i=1:size(BW,1);
    for j=1:size(BW,2);
        if BW(i,j) == 1;
            nBW(i-1,j-1) = 1;
            nBW(i-1,j) = 1;
            nBW(i-1,j+1) = 1;
            nBW(i,j-1) = 1;
            nBW(i,j+1) = 1;
            nBW(i+1,j-1) = 1;
            nBW(i+1,j) = 1;
            nBW(i+1,j+1) = 1;
        end
    end
end

end

