function varargout = Parameters(varargin)
% PARAMETERS MATLAB code for Parameters.fig
%      PARAMETERS, by itself, creates a new PARAMETERS or raises the existing
%      singleton*.
%
%      H = PARAMETERS returns the handle to a new PARAMETERS or the handle to
%      the existing singleton*.
%
%      PARAMETERS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PARAMETERS.M with the given input arguments.
%
%      PARAMETERS('Property','Value',...) creates a new PARAMETERS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Parameters_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Parameters_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Parameters

% Last Modified by GUIDE v2.5 20-Nov-2014 18:17:21

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Parameters_OpeningFcn, ...
                   'gui_OutputFcn',  @Parameters_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Parameters is made visible.
function Parameters_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Parameters (see VARARGIN)

% Choose default command line output for Parameters
handles.output = hObject;

%defalult parameters
global AlgorithmRECParameters;
pascainv = AlgorithmRECParameters(1);
parotinv = AlgorithmRECParameters(2);

paCompareDisEnds = AlgorithmRECParameters(3);
paComparePathLength = AlgorithmRECParameters(4);
paCompareNFMaxBoxSizeRatio = AlgorithmRECParameters(5);
paCompareNFTopBlockSizeRatio = AlgorithmRECParameters(6);
paCompareNFMiddleBlockSizeRatio = AlgorithmRECParameters(7);
paCompareNFBottomBlockSizeRatio = AlgorithmRECParameters(8);
paCompareNFBottomTopBlockAreaRatio = AlgorithmRECParameters(9);
paCompareNFMiddleTopBlockAreaRatio= AlgorithmRECParameters(10);
paCompareNFClosedRegionArea = AlgorithmRECParameters(11);
paCompareRatioConPathandEnd = AlgorithmRECParameters(12);

set(handles.checkbox_scale_invariant, 'Value', pascainv);
set(handles.checkbox_rotation_invariant, 'Value', parotinv);

set(handles.input_feature1, 'String', num2str(paCompareDisEnds));
set(handles.input_feature2, 'String', num2str(paComparePathLength));
set(handles.input_feature3, 'String', num2str(paCompareNFMaxBoxSizeRatio));
set(handles.input_feature4, 'String', num2str(paCompareNFTopBlockSizeRatio));
set(handles.input_feature5, 'String', num2str(paCompareNFMiddleBlockSizeRatio));
set(handles.input_feature6, 'String', num2str(paCompareNFBottomBlockSizeRatio));
set(handles.input_feature7, 'String', num2str(paCompareNFBottomTopBlockAreaRatio));
set(handles.input_feature8, 'String', num2str(paCompareNFMiddleTopBlockAreaRatio));
set(handles.input_feature9, 'String', num2str(paCompareNFClosedRegionArea));
set(handles.input_feature10, 'String', num2str(paCompareRatioConPathandEnd));

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Parameters wait for user response (see UIRESUME)
% uiwait(handles.figure_Parameters);


% --- Outputs from this function are returned to the command line.
function varargout = Parameters_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton_reset.
function pushbutton_reset_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_reset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global AlgorithmRECParameters;
pascainv = AlgorithmRECParameters(1);
parotinv = AlgorithmRECParameters(2);

paCompareDisEnds = AlgorithmRECParameters(3);
paComparePathLength = AlgorithmRECParameters(4);
paCompareNFMaxBoxSizeRatio = AlgorithmRECParameters(5);
paCompareNFTopBlockSizeRatio = AlgorithmRECParameters(6);
paCompareNFMiddleBlockSizeRatio = AlgorithmRECParameters(7);
paCompareNFBottomBlockSizeRatio = AlgorithmRECParameters(8);
paCompareNFBottomTopBlockAreaRatio = AlgorithmRECParameters(9);
paCompareNFMiddleTopBlockAreaRatio= AlgorithmRECParameters(10);
paCompareNFClosedRegionArea = AlgorithmRECParameters(11);
paCompareRatioConPathandEnd = AlgorithmRECParameters(12);

set(handles.checkbox_scale_invariant, 'Value', pascainv);
set(handles.checkbox_rotation_invariant, 'Value', parotinv);

set(handles.input_feature1, 'String', paCompareDisEnds);
set(handles.input_feature2, 'String', paComparePathLength);
set(handles.input_feature3, 'String', paCompareNFMaxBoxSizeRatio);
set(handles.input_feature4, 'String', paCompareNFTopBlockSizeRatio);
set(handles.input_feature5, 'String', paCompareNFMiddleBlockSizeRatio);
set(handles.input_feature6, 'String', paCompareNFBottomBlockSizeRatio);
set(handles.input_feature7, 'String', paCompareNFBottomTopBlockAreaRatio);
set(handles.input_feature8, 'String', paCompareNFMiddleTopBlockAreaRatio);
set(handles.input_feature9, 'String', paCompareNFClosedRegionArea);
set(handles.input_feature10, 'String', paCompareRatioConPathandEnd);


% --- Executes on button press in pushbutton_apply.
function pushbutton_apply_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_apply (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
pascainv = get(handles.checkbox_scale_invariant, 'Value');
parotinv = get(handles.checkbox_rotation_invariant, 'Value');

paCompareDisEnds = str2num(get(handles.input_feature1, 'String'));
paComparePathLength = str2num(get(handles.input_feature2, 'String'));
paCompareNFMaxBoxSizeRatio = str2num(get(handles.input_feature3, 'String'));
paCompareNFTopBlockSizeRatio = str2num(get(handles.input_feature4, 'String'));
paCompareNFMiddleBlockSizeRatio = str2num(get(handles.input_feature5, 'String'));
paCompareNFBottomBlockSizeRatio = str2num(get(handles.input_feature6, 'String'));
paCompareNFBottomTopBlockAreaRatio = str2num(get(handles.input_feature7, 'String'));
paCompareNFMiddleTopBlockAreaRatio = str2num(get(handles.input_feature8, 'String'));
paCompareNFClosedRegionArea = str2num(get(handles.input_feature9, 'String'));
paCompareRatioConPathandEnd = str2num(get(handles.input_feature10, 'String'));

if isnan(paCompareDisEnds) || isnan(paComparePathLength)...
|| isnan(paCompareNFMaxBoxSizeRatio) || isnan(paCompareNFTopBlockSizeRatio)...
|| isnan(paCompareNFMiddleBlockSizeRatio) || isnan(paCompareNFBottomBlockSizeRatio)...
|| isnan(paCompareNFBottomTopBlockAreaRatio) || isnan(paCompareNFMiddleTopBlockAreaRatio)...
|| isnan(paCompareNFClosedRegionArea) || isnan(paCompareRatioConPathandEnd)
    errordlg('You must enter a numeric value','Bad Input','modal');
    uicontrol(hObject);
    return;
end

global AlgorithmRECParameters;
AlgorithmRECParameters(1) = pascainv;
AlgorithmRECParameters(2) = parotinv;

AlgorithmRECParameters(3) = paCompareDisEnds;
AlgorithmRECParameters(4) = paComparePathLength;
AlgorithmRECParameters(5) = paCompareNFMaxBoxSizeRatio;
AlgorithmRECParameters(6) = paCompareNFTopBlockSizeRatio;
AlgorithmRECParameters(7) = paCompareNFMiddleBlockSizeRatio;
AlgorithmRECParameters(8) = paCompareNFBottomBlockSizeRatio;
AlgorithmRECParameters(9) = paCompareNFBottomTopBlockAreaRatio;
AlgorithmRECParameters(10) = paCompareNFMiddleTopBlockAreaRatio;
AlgorithmRECParameters(11) = paCompareNFClosedRegionArea;
AlgorithmRECParameters(12) = paCompareRatioConPathandEnd;

delete(handles.figure_Parameters);

% --- Executes on button press in pushbutton_exit.
function pushbutton_exit_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
delete(handles.figure_Parameters);


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2


% --- Executes on button press in checkbox_scale_invariant.
function checkbox_scale_invariant_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_scale_invariant (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_scale_invariant


% --- Executes on button press in checkbox_rotation_invariant.
function checkbox_rotation_invariant_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_rotation_invariant (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_rotation_invariant



function input_feature1_Callback(hObject, eventdata, handles)
% hObject    handle to input_feature1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of input_feature1 as text
%        str2double(get(hObject,'String')) returns contents of input_feature1 as a double


% --- Executes during object creation, after setting all properties.
function input_feature1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to input_feature1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function input_feature2_Callback(hObject, eventdata, handles)
% hObject    handle to input_feature2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of input_feature2 as text
%        str2double(get(hObject,'String')) returns contents of input_feature2 as a double


% --- Executes during object creation, after setting all properties.
function input_feature2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to input_feature2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function input_feature3_Callback(hObject, eventdata, handles)
% hObject    handle to input_feature3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of input_feature3 as text
%        str2double(get(hObject,'String')) returns contents of input_feature3 as a double


% --- Executes during object creation, after setting all properties.
function input_feature3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to input_feature3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function input_feature4_Callback(hObject, eventdata, handles)
% hObject    handle to input_feature4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of input_feature4 as text
%        str2double(get(hObject,'String')) returns contents of input_feature4 as a double


% --- Executes during object creation, after setting all properties.
function input_feature4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to input_feature4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function input_feature5_Callback(hObject, eventdata, handles)
% hObject    handle to input_feature5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of input_feature5 as text
%        str2double(get(hObject,'String')) returns contents of input_feature5 as a double


% --- Executes during object creation, after setting all properties.
function input_feature5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to input_feature5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function input_feature6_Callback(hObject, eventdata, handles)
% hObject    handle to input_feature6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of input_feature6 as text
%        str2double(get(hObject,'String')) returns contents of input_feature6 as a double


% --- Executes during object creation, after setting all properties.
function input_feature6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to input_feature6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function input_feature7_Callback(hObject, eventdata, handles)
% hObject    handle to input_feature7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of input_feature7 as text
%        str2double(get(hObject,'String')) returns contents of input_feature7 as a double


% --- Executes during object creation, after setting all properties.
function input_feature7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to input_feature7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function input_feature8_Callback(hObject, eventdata, handles)
% hObject    handle to input_feature8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of input_feature8 as text
%        str2double(get(hObject,'String')) returns contents of input_feature8 as a double


% --- Executes during object creation, after setting all properties.
function input_feature8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to input_feature8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function input_feature9_Callback(hObject, eventdata, handles)
% hObject    handle to input_feature9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of input_feature9 as text
%        str2double(get(hObject,'String')) returns contents of input_feature9 as a double


% --- Executes during object creation, after setting all properties.
function input_feature9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to input_feature9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function input_feature10_Callback(hObject, eventdata, handles)
% hObject    handle to input_feature10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of input_feature10 as text
%        str2double(get(hObject,'String')) returns contents of input_feature10 as a double


% --- Executes during object creation, after setting all properties.
function input_feature10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to input_feature10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
