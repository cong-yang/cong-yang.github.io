function [ nodesOnPart ] = f_add_nodesOnPart( pointx, pointy, nodesOnPart )
%f_add_nodesOnPart: add point to a point list
%   input:
%         [pointx,pointy]: point that to be added
%         nodesOnPart: original 
%   output:
%         nodesOnPart: node point list after adding [pointx, pointy]

mysize = size(nodesOnPart,1);
mysize = mysize + 1;
nodesOnPart(mysize, 1) = pointx;
nodesOnPart(mysize, 2) = pointy;

end

