function [ segment1, segment2 ] = f_segment_generation( im2 )
%f_segment_generation: this function is used to generate segment line from the image
%   input:
%         im2: the original image
%   output:
%         segment1: the first segment
%         segment2: the second segment

r = im2(:,:,1);
g = im2(:,:,2);
b = im2(:,:,3);

%figure,imshow(r+g);

BW = edge(r+g,'sobel');
se = strel('disk',7);

while size(bwboundaries(BW),1) >2 
    %BW = dilate(BW);
    BW = imdilate(BW,se);
end
%figure,imshow(BW);
contours = bwboundaries(BW);
%Split both Contours
cont1 = uint8(zeros(size(BW)));
for i=1:size(contours{1},1)
   cont1(contours{1}(i,1),contours{1}(i,2)) = 255; 
end
%Boundingbox
[r,c] = find(cont1==255);
startpointX = min(c);
startpointY = min(r);
recwidth = max(c)-startpointX + 1;
recheight = max(r)-startpointY + 1;
cont1 = imcrop(cont1,[startpointX startpointY recwidth recheight]);

%figure, imshow(cont1);
cont1 = imfill(cont1);

cont2 = uint8(zeros(size(BW)));
for i=1:size(contours{2},1)
   cont2(contours{2}(i,1),contours{2}(i,2)) = 255; 
end
[r,c] = find(cont2==255);
startpointX = min(c);
startpointY = min(r);
recwidth = max(c)-startpointX + 1;
recheight = max(r)-startpointY + 1;
cont2 = imcrop(cont2,[startpointX startpointY recwidth recheight]);
%figure, imshow(cont2);
cont2 = imfill(cont2);


skel1 = bwmorph(cont1,'skel',Inf);
%figure, imshow(skel1);
skel1 = im2bw(removeBranches(skel1));
%figure, imshow(skel1);


skel2 = bwmorph(cont2,'skel',Inf);
%figure, imshow(skel2);
skel2 = removeBranches(skel2);
skel2 = im2bw(skel2);
%figure, imshow(skel2);

segment1 = skel1;
segment2 = skel2;

end

