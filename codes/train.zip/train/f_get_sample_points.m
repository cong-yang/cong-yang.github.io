function [ sample1, sample2 ] = f_get_sample_points( segpoints1, segpoints2 )
%f_get_sample_points:  get sample points. the number of sample points are
%determinted by the length of shorter segment
%   Input:
%         segpoints1: the first segment point list
%         segpoints2: the second segment point list
%   output:
%         sample1: sample points for the first segment
%         sample2: sample points for the second segment

length1 = length(segpoints1);
length2 = length(segpoints2);

if length1 == length2
    sample1 = segpoints1;
    sample2 = segpoints2;
    return;
end
 
if length1 < length2
    mylength = length1;
    [newsample2] = f_sample_Points(segpoints2, mylength);
    sample1 = segpoints1;
    sample2 = newsample2;
    return;
end

if length1 > length2
    mylength = length2;
    [newsample1] = f_sample_Points(segpoints1, mylength);
    sample1 = newsample1;
    sample2 = segpoints2;
    return;
end

end

