function [ br ] = bottomRight( onlyred )

br = onlyred(size(onlyred,1)/2:size(onlyred,1),size(onlyred,2)/2:size(onlyred,2));
peak = max(max(br));
br = im2bw((br / peak),0.1);
cont = bwboundaries(br);
cont = cont{1};
m = size(br,1)+size(br,2);
vali = 0;
for i=1:size(cont,1)
    if cont(i,1)+cont(i,2) < m
        m = cont(i,1)+cont(i,2);
        vali = i;
    end;
end
br = cont(vali,:)+(size(onlyred)/2)-1;

end

