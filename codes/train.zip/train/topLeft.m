function [ tl ] = topLeft( onlyred )

tl = onlyred(1:size(onlyred,1)/2,1:size(onlyred,2)/2);
peak = max(max(tl));
tl = im2bw((tl / peak),0.1);
cont = bwboundaries(tl);
cont = cont{1};
m = 0;
vali = 0;
for i=1:size(cont,1)
    if cont(i,1)+cont(i,2) > m
        m = cont(i,1)+cont(i,2);
        vali = i;
    end;
end
tl = cont(vali,:);

end