function [ bool_visited ] = f_is_visited( pointx, pointy, skeletonpointlist )
%f_is_visited: to check a skeleton point(pointx, pointy) is visited(1) or not(0).
%   input:
%         [pointx,pointy]: a point to be checked.
%         skeletonpointlist: all skeleton point list.
%   output:
%          bool_visited: visited(1) or not visited(0)

bool_visited = 0;

for i = 1:size(skeletonpointlist,1)
    if pointx == skeletonpointlist(i,1) && pointy == skeletonpointlist(i,2)
        if skeletonpointlist(i,3) == 1
            bool_visited = 1;
            return;
        end
    end
end


end

