function [ skeletonpointlist ] = f_mark_as_visited( pointx, pointy, skeletonpointlist )
%f_mark_as_visited: this function is used to mark one skeleton point as
%                   visited, set the third dimension as one.(1: visited; 0: not visited)
%  input:
%        [pointx, pointy]: point will be marked.
%        skeletonpointlist: all skeleton point list
%  output:
%        skeletonpointlist: marked skeleton point list

for i = 1:size(skeletonpointlist,1)
    if pointx == skeletonpointlist(i,1) && pointy == skeletonpointlist(i,2)
        skeletonpointlist(i,3) = 1;
        return;
    end
end

end

