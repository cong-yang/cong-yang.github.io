function varargout = CSDemo(varargin)
% CSDEMO MATLAB code for CSDemo.fig
%      CSDEMO, by itself, creates a new CSDEMO or raises the existing
%      singleton*.
%
%      H = CSDEMO returns the handle to a new CSDEMO or the handle to
%      the existing singleton*.
%
%      CSDEMO('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CSDEMO.M with the given input arguments.
%
%      CSDEMO('Property','Value',...) creates a new CSDEMO or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before CSDemo_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to CSDemo_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help CSDemo

% Last Modified by GUIDE v2.5 20-Nov-2014 17:29:57

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CSDemo_OpeningFcn, ...
                   'gui_OutputFcn',  @CSDemo_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before CSDemo is made visible.
function CSDemo_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to CSDemo (see VARARGIN)

% Choose default command line output for CSDemo
handles.output = hObject;

axes(handles.axes_camera);

setappdata(handles.axes_camera,'selectedalgorithm','AlgorithmREC');
set(handles.pushbutton_parameters, 'Visible', 'on');
setappdata(handles.checkbox_thining,'bool_thinning',0);

set(handles.panel_carrying, 'Visible', 'on');
set(handles.panel_feature1, 'Visible', 'off');
set(handles.panel_feature2, 'Visible', 'off');

%set defature parameters for AlgorithmREC
global AlgorithmRECParameters;
AlgorithmRECParameters = [1,1,1,1,1,1,1,1,1,1,1,1];

%detect camera
win_info = imaqhwinfo('winvideo');
deviceinfo = win_info.DeviceInfo;
for i = 1:length(deviceinfo)
    singledevice = deviceinfo(i);
    deviceid = singledevice.DeviceID;
    devicename = singledevice.DeviceName;
    myitems{i} = sprintf(devicename);
    display(['Device ID: ',num2str(deviceid),', Device Name: ', devicename]);
end
set(handles.popupmenu_camera,'String',myitems);

vid = videoinput('winvideo',2,'I420_1280x720');
hImage = image(zeros(720,1280,3), 'Parent', handles.axes_camera);
preview(vid,hImage);

%set the global information
setappdata(handles.axes_camera,'mycamera',vid);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes CSDemo wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = CSDemo_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in popupmenu_camera.
function popupmenu_camera_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_camera (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_camera contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_camera

contents = cellstr(get(hObject,'String'));
selectedcamera = contents{get(hObject,'Value')};

vid = getappdata(handles.axes_camera,'mycamera');
if isempty(vid) == 0
    stoppreview(vid);
end

if strcmp('FJ Camera',selectedcamera) == 1
    if length(contents) > 1
        vid = videoinput('winvideo',1,'MJPG_1280x720');
    else
        vid = videoinput('winvideo',1,'MJPG_1280x720');
    end
else
    vid = videoinput('winvideo',1,'I420_1280x720');
end

hImage = image(zeros(720,1280,3), 'Parent', handles.axes_camera);
preview(vid,hImage);

%set the global information
setappdata(handles.axes_camera,'mycamera',vid);


% --- Executes during object creation, after setting all properties.
function popupmenu_camera_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_camera (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_generate_line.
function pushbutton_generate_line_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_generate_line (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.panel_carrying, 'Visible', 'on');
set(handles.panel_feature1, 'Visible', 'off');
set(handles.panel_feature2, 'Visible', 'off');

contourimage = getappdata(handles.axes_camera,'contourimage');
axes(handles.axis_imageshow);
imshow(contourimage);
[segment1, segment2] = f_segment_generation(contourimage);

bool_thinning = getappdata(handles.checkbox_thining,'bool_thinning');
if bool_thinning  == 1
    [segment1] = f_segment_thinning(segment1);
    [segment2] = f_segment_thinning(segment2);
end

%generate point list along the segment path
[segpoints1] = f_get_path_points(segment1);
[segpoints2] = f_get_path_points(segment2);

%set data for the next step
setappdata(handles.axes_camera,'segpoints1',segpoints1);
setappdata(handles.axes_camera,'segpoints2',segpoints2);

%show the segmented line segments
axes(handles.line_seg1);
imshow(segment1);
axes(handles.line_seg2);
imshow(segment2);


% --- Executes on button press in pushbutton_similarity.
function pushbutton_similarity_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_similarity (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.panel_carrying, 'Visible', 'on');
set(handles.panel_feature1, 'Visible', 'off');
set(handles.panel_feature2, 'Visible', 'off');

myalgirthm = getappdata(handles.axes_camera,'selectedalgorithm');
segpoints1 = getappdata(handles.axes_camera,'segpoints1');
segpoints2 = getappdata(handles.axes_camera,'segpoints2');

% save 'segment1.mat','mysegment1';
% save 'segment2.mat','mysegment2';
global AlgorithmRECParameters;

%different results for different algorithm: AlgorithmREC, AlgorithmPC
%display(myalgirthm);
%the algorithm with rectangle compare
if strcmp(myalgirthm, 'AlgorithmREC') == 1
    %display(AlgorithmRECParameters);
    [CSFeature1] = f_Get_CS_features(segpoints1, AlgorithmRECParameters);
    [CSFeature2] = f_Get_CS_features(segpoints2, AlgorithmRECParameters);
    simialrity = dot(CSFeature1,CSFeature2)/(norm(CSFeature1)*norm(CSFeature2));
    set(handles.text_similarity,'String',num2str(simialrity));
else%if strcmp(myalgirthm,'AlgorithmPC') == 1
    [sample1, sample2] = f_get_sample_points(segpoints1, segpoints2);
%     sample1 = segpoints1;
%     sample2 = segpoints2;
    [DistanceMatrix1, AngleMatrix1] = f_get_Point_Feature(sample1);
    [DistanceMatrix2, AngleMatrix2] = f_get_Point_Feature(sample2);
    [similarity] = f_get_similarity_points(DistanceMatrix1, DistanceMatrix2, AngleMatrix1, AngleMatrix2);
    similarity = similarity/2;
    set(handles.text_similarity,'String',num2str(similarity));
end
%display('mmm');


% --- Executes on selection change in popupmenu_algorithms.
function popupmenu_algorithms_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_algorithms (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_algorithms contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_algorithms
contents = cellstr(get(hObject,'String'));
algirthm = contents{get(hObject,'Value')};
%display(algirthm);
setappdata(handles.axes_camera,'selectedalgorithm',algirthm);
if strcmp(algirthm, 'AlgorithmREC') == 1
    set(handles.pushbutton_parameters, 'Visible', 'on');
else
    set(handles.pushbutton_parameters, 'Visible', 'off');
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function popupmenu_algorithms_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_algorithms (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in pushbutton_check_feature.
function pushbutton_check_feature_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_check_feature (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.panel_carrying, 'Visible', 'off');
set(handles.panel_feature1, 'Visible', 'on');
set(handles.panel_feature2, 'Visible', 'on');

segpoints1 = getappdata(handles.axes_camera,'segpoints1');
segpoints2 = getappdata(handles.axes_camera,'segpoints2');
myalgirthm = getappdata(handles.axes_camera,'selectedalgorithm');

global AlgorithmRECParameters;

if strcmp(myalgirthm, 'AlgorithmREC') == 1
    %display(AlgorithmRECParameters);
    axes(handles.axes_line1_feature);
    [SuperVector1] = f_CS_feature_show(segpoints1,AlgorithmRECParameters);
    axes(handles.axes_line2_feature);
    [SuperVector2] = f_CS_feature_show(segpoints2,AlgorithmRECParameters);
else
    axes(handles.axes_line1_feature);
    plot(segpoints1(:,2), segpoints1(:,1),'*r');
    axes(handles.axes_line2_feature);
    plot(segpoints2(:,2), segpoints2(:,1),'*r');
end



% --- Executes on button press in pushbutton_about.
function pushbutton_about_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_about (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[cdata,map] = imread('PR-Logo.png'); 
h=msgbox({'Research Group of Pattern Recognition','University of Siegen','Developer: Cong Yang, Oliver Tiebe'},'Copyright','custom',cdata,map);


% --- Executes on button press in pushbutton_exit.
function pushbutton_exit_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clearStr = 'clear all';
evalin('base', clearStr);
delete(handles.figure1);



% --- Executes on button press in pushbutton_camera_test.
function pushbutton_camera_test_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_camera_test (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
imaqtool;


% --- Executes on button press in pushbutton_take_image.
function pushbutton_take_image_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_take_image (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.panel_carrying, 'Visible', 'on');
set(handles.panel_feature1, 'Visible', 'off');
set(handles.panel_feature2, 'Visible', 'off');

mycamera = getappdata(handles.axes_camera,'mycamera');
start(mycamera);
contourimage = getsnapshot(mycamera);
contourimage = ycbcr2rgb(contourimage);

%contourimage = imread('temp\2014111915224.225.png');

myclock = clock;
tempname = ['temp/',num2str(myclock(1)),num2str(myclock(2)),num2str(myclock(3)),num2str(myclock(4)),num2str(myclock(5)),num2str(myclock(6)),'.png'];
imwrite(contourimage,tempname);

flushdata(mycamera);
axes(handles.axis_imageshow);
imshow(contourimage);
drawnow;
[contourimage, tl, br] = f_image_preprocessing(contourimage, 1);
hold on;
plot(tl(2),tl(1), 'g.');
plot(br(2),br(1), 'g.');
rectangle('Position',[tl(2),tl(1),abs(br(2)-tl(2)),abs(br(1)-tl(1))],'LineWidth',1,'EdgeColor','r');
hold off;
setappdata(handles.axes_camera,'contourimage',contourimage);


% --- Executes on button press in checkbox_thining.
function checkbox_thining_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_thining (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_thining
bool_thinning = get(hObject,'Value');
setappdata(handles.checkbox_thining,'bool_thinning',bool_thinning);


% --- Executes when figure1 is resized.
function figure1_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton_parameters.
function pushbutton_parameters_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_parameters (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Parameters;
