function [ im2, tl, br ] = f_image_preprocessing( im, resizepower )
%f_image_preprocessing: this function is used to detect marker region and
%                       to cut the rigion with segments
%   input:
%         im: the original image
%         resizepower: parameter for image resize, 0.75 is proposed
%   output:
%         im2: the processed image

im = imresize(im,resizepower);
%First step: Detect Red Points!
r = im(:,:,1);
g = im(:,:,2);
b = im(:,:,3);
onlyred = r-g-b;
onlyred = double(onlyred);
%imshow(im);

se = strel('disk',5);

while size(bwboundaries(onlyred),1) >2 
    %BW = dilate(BW);
    onlyred = imerode(onlyred,se);
end

%imshow(onlyred);

%Top Left:
tl = topLeft(onlyred);
%hold on; plot(tl(2),tl(1), 'g.');

%Bottom Right:
br = bottomRight(onlyred);
%hold on; plot(br(2),br(1), 'g.');

%Cut Image
im2 = imcrop(im,[tl(2)+5 tl(1)+5 br(2)-tl(2)-10 br(1)-tl(1)-10]);
%figure, imshow(im2);

end

