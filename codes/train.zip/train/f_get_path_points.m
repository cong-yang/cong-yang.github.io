function [ pointlist ] = f_get_path_points( OriMatrix )
%f_get_path_points: this function is used to generate points along the
%segment. All points are ordered along with the segment path
%   input:
%         OriMatrix: matrix with the line segment
%   output:
%         pathpoints: ordered points along the path

%step 1: generate all points
%[x,y] = ind2sub(size(OriMatrix), find(OriMatrix > 0));
[x,y] = find(OriMatrix == 1);
mysize = length(y);
pathpoints = zeros(mysize,3);
pathpoints(:,1) = x(:);
pathpoints(:,2) = y(:);
pathpoints(:,3) = 0; % 0 means not readed, 1 means readed

%step 2: detect the endpoints
indexendpoint = 1;
for i = 1:mysize
    pointx = pathpoints(i,1);
    pointy = pathpoints(i,2);
    [neighbours,~] = f_all_neighbors(pointx, pointy, OriMatrix);
    if neighbours == 1
        endpoints(indexendpoint,1) = pointx;
        endpoints(indexendpoint,2) = pointy;
        indexendpoint = indexendpoint + 1;
    end
    
    if neighbours > 3
        pathpoints = 'the generated line is not 1 pixel width';
        display(pointx);
        display(pointy);
        display(pathpoints);
        return;
    end
end

if indexendpoint ~= 3
    pathpoints = 'please check your endpoints';
    display(endpoints);
    display(pathpoints);
    return;
end

%step 3: choose one endpoint as the start point
startpoint = endpoints(1,:);
endpoint = endpoints(2,:);

%step4: start from the start point, generate point list
[pointlist, ~] = f_scanning_path(startpoint, endpoint, pathpoints, OriMatrix);

end

