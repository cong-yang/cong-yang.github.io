function [ pointlist, pathpoints ] = f_scanning_path( startpoint, endpoint, pathpoints, OriMatrix )
%f_scanning_path: this function is used to scann the line path and generate 
%                 point list along with the scanning path
%   input:
%         startpoint: [x,y] of the line start
%         endpoint: [x,y] of the line end
%         pathpoints:[x,y,mark] mark = 0, not visited, mark = 1, visited
%         OriMatrix: shape with contour line
%   output:
%         pointlist: all point list ordered along with the path
%         pathpoints: to check whetehr all points are visited

pointlist = [];

currentx = startpoint(1);
currenty = startpoint(2);

pointlist = f_add_nodesOnPart(currentx, currenty, pointlist);
[pathpoints] = f_mark_as_visited(currentx, currenty, pathpoints);
[neisize, neighbors] = f_all_neighbors(currentx, currenty, OriMatrix);

if neisize == 1
    previousx = currentx;
    previousy = currenty;
    currentx = neighbors(1);
    currenty = neighbors(2);
    running = true;
else
    pointlist = [];
    display('something wrong when we scan the next point');
    return;
end

endpointx = endpoint(1);
endpointy = endpoint(2);

while running
    %check if the current node is an end node
    if currentx == endpointx && currenty == endpointy
        %is the endpoint
        pointlist = f_add_nodesOnPart(currentx, currenty, pointlist);
        [pathpoints] = f_mark_as_visited(currentx, currenty, pathpoints);
        running = false;
    else
        %is not the endpoint
        [neisize, neighbors] = f_all_neighbors(currentx, currenty, OriMatrix);
        if neisize == 2 %normal point
            for n = 1:neisize
                nx = neighbors(n,1);
                ny = neighbors(n,2);
                if nx ~= previousx || ny ~= previousy
                    pointlist = f_add_nodesOnPart(currentx, currenty, pointlist);
                    [pathpoints] = f_mark_as_visited(currentx, currenty, pathpoints);
                    previousx = currentx;
                    previousy = currenty;
                    currentx = nx;
                    currenty = ny;
                    break;
                end
            end
        else %point area
            %try to find its edge neighbour and vertex neighbour. the edge 
            %neighbour has the higher priority
            bestFit = [];
            edgeNeighbors = [];
            vettexNeighbours = [];
            for n = 1:neisize
                nx = neighbors(n,1);
                ny = neighbors(n,2);
                [bool_visited] = f_is_visited(nx, ny, pathpoints);
                if bool_visited == 0 %not visited
                    [bool_edgeneibhgour] = f_is_edge_neighbor(nx, ny, currentx, currenty);
                    if bool_edgeneibhgour == 1 %is an edge neighbour
                        edgeNeighbors(size(edgeNeighbors,1)+1,1) = nx;
                        edgeNeighbors(size(edgeNeighbors,1),2) = ny;
                    else %is an vertex neighbour
                        vettexNeighbours(size(vettexNeighbours,1)+1,1) = nx;
                        vettexNeighbours(size(vettexNeighbours,1),2) = ny;
                    end
                end
            end
            
            %try to find a directly connected neighbor
            if size(bestFit,1) == 0
                if size(edgeNeighbors,1) > 0
                    bestFit = edgeNeighbors(1,:);
                else
                    if size(vettexNeighbours,1) > 0
                        bestFit = vettexNeighbours(1,:);
                    end
                end
            end
                    
            if size(bestFit,1) > 0
                pointlist = f_add_nodesOnPart(currentx, currenty, pointlist);
                [pathpoints] = f_mark_as_visited(currentx, currenty, pathpoints);
                previousx = currentx;
                previousy = currenty; 
                currentx = bestFit(1,1);
                currenty = bestFit(1,2);
            end
        end
    end
end

end

