clear all;
imaqmem(30000000);
mycamera = videoinput('winvideo',1,'I420_1280x720');
preview(mycamera);
start(mycamera);

%new windows
h=figure('NumberTitle','off','Name','Camera','MenuBar','none','color','c','Position',[0, 0, 1, 1], 'Visible','on');

set(h,'doublebuffer','on','outerposition',get(0,'screensize'));

h1 = axes('Position', [0.02, 0.1, 0.4, 0.8],'Parent',h); %??????  
hold on; 
axis off;  

while ishandle(h)   
    a = getsnapshot (mycamera);  
    flushdata(mycamera);    
    imshow(a);  
    drawnow;
end;  

delete(mycamera);



