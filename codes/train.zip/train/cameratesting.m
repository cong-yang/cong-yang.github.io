clear all;

info = imaqhwinfo;
myadaptors = info.InstalledAdaptors;
display(['Adaptor: ',myadaptors{4}]);

win_info = imaqhwinfo('winvideo');
adaptorpath = win_info.AdaptorDllName;
display(['Adaptor Path: ',adaptorpath]);

display('Detecting devices...............');
deviceinfo = win_info.DeviceInfo;
for i = 1:length(deviceinfo)
    singledevice = deviceinfo(i);
    deviceid = singledevice.DeviceID;
    devicename = singledevice.DeviceName;
    display(['Device ID: ',num2str(deviceid),', Device Name: ', devicename]);
end

mycamera = videoinput('winvideo',1,'I420_1280x720');
himage=preview(mycamera);
