function [ segment ] = f_segment_thinning( segment )


edge1 = [0 1;1 1];
edge2 = [1 1;1 0];
repl1 = [0 1;1 0];
edge3 = [1 0;1 1];
edge4 = [1 1;0 1];
repl2 = [1 0;0 1];

for i=1:size(segment,1)-1;
    for j=1:size(segment,2)-1;
        if (sum(sum(segment(i:i+1,j:j+1) == edge1)) == 4 || sum(sum(segment(i:i+1,j:j+1) == edge2)) == 4)
            segment(i:i+1,j:j+1) = repl1;
        end
        if (sum(sum(segment(i:i+1,j:j+1) == edge3)) == 4 || sum(sum(segment(i:i+1,j:j+1) == edge4)) == 4)
            segment(i:i+1,j:j+1) = repl2;
        end
    end
end

end

