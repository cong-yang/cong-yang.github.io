function [ bullseye ] = s_alpha( alpha )

%alpha is changed from 1 - 100

contourdir = 'resources/features/contours/';
endpointdir = 'resources/features/endpoints/';
pathdir = 'resources/features/pathes/';
radidir = 'resources/features/radiMatrix/';
skeletonsdir = 'resources/features/skeletons/';

%[m] = f_get_min_sample(pathdir);
m = 30;
topcount = 12;

alldata = dir(fullfile(skeletonsdir,['*','.mat']));
N = size(alldata,1);
for i = 1:N
    object1 = alldata(i,1).name;
    tempname =  regexp(object1,'.mat','split');
    objectname1 = tempname{1};
    
    %load contour, endpoints and pathes
    load(strcat(contourdir,object1));
    load(strcat(endpointdir,object1));
    load(strcat(pathdir,object1));
    load(strcat(radidir,object1));
    
    contour1 = mycontour;
    endpoints1 = endpoints;
    pathes1 = pathes;
    radiMatrix1 = radiMatrix;
    
    clear mycontour;
    clear endpoints;
    clear pathes;
    clear radiMatrix;
    
    normfac1 = sum(sum(contour1));
    display([num2str(i),'=',objectname1]);
    
    [matchingresult] = f_normal_matching(m, alpha, endpoints1, pathes1, radiMatrix1, normfac1, alldata, contourdir, endpointdir, pathdir, radidir);
    %save(['resources\results\',objectname1,'.mat'],'matchingresult');
    TotalResults{i} = {objectname1,matchingresult};
end

[ bullseye ] = f_Data_Analyzing( TotalResults, topcount);


end

