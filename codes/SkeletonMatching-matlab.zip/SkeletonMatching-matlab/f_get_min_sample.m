function [ m ] = f_get_min_sample( pathdir )
%f_get_min_sample: this function is used to calculate the appropriate
%number of sample points on each skeleton pathes. It's selected by the
%shortest path length.
%   input:
%         pathdir: folder of all pathes
%   output:
%         m: selected m

alldata = dir(fullfile(pathdir,['*','.mat']));
N = size(alldata,1);
m = 1000;
for i = 1:N
    object = alldata(i,1).name;
    display([num2str(i),': ', object]);
    load(strcat(pathdir,object));
    s_object = pathes;
    N2 = size(s_object,1);
    for iii = 1:N2
        s_path = s_object{iii,3};
        mylength = size(s_path,1);
%         if mylength <= 10
%             display(object);
%         end
        if mylength <= m
            m = mylength;
        end
    end
end

end

