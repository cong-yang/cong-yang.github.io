function [ OrderedMatchingResults ] = f_normal_matching(m, alpha, endpoints1, pathes1, radiMatrix1, normfac1, alldata, contourdir, endpointdir, pathdir, radidir)
%f_one_all_matching: do the matching process and output the ranked final result
%   Input:
%          m: number of sample points on each skeleton path
%          alpha: weight factor for radius and path length
%          contour1: query's contour
%          endpoints1: query's endpoint list
%          pathes1: query's all skeleton pathes
%          alldata: all object list
%          contourdir: all objects' contour folder
%          endpointdir: all objects' endpoints folder
%          pathdir: all object's skeleton pathes folder
%          radidir: all radimatrix folder
%   Output:
%          OrderedMatchingResults: similarity between query and each candidates.

ObjectListSize = size(alldata,1);
for j = 1:ObjectListSize
    object2 = alldata(j,1).name;
    tempname =  regexp(object2,'.mat','split');
    objectname2 = tempname{1};
    
    display(['----',num2str(j),':',objectname2]);
    %load contour, endpoints and pathes
    load(strcat(contourdir,object2));
    load(strcat(endpointdir,object2));
    load(strcat(pathdir,object2));
    load(strcat(radidir,object2));

    contour2 = mycontour;
    endpoints2 = endpoints;
    pathes2 = pathes;
    radiMatrix2 = radiMatrix;
    
    clear mycontour;
    clear endpoints;
    clear pathes;
    clear radiMatrix;
    
    contour2 = im2bw(contour2);
    normfac2 = sum(sum(contour2));
    [dissimilarity, corresponding] = f_object_similarity( m, alpha, pathes1, pathes2, endpoints1, endpoints2, radiMatrix1, radiMatrix2, normfac1, normfac2);
    MatchingResult{j} = {objectname2,dissimilarity};
    %display(['  --> ',objectname2,': ',num2str(dissimilarity)]);
end

%rank results
[~,order] = sort(cellfun(@(v) v{2}, MatchingResult));
MatchingRankedRestlts = MatchingResult(order);

OrderedMatchingResults={};
% tempindex = ObjectListSize;
% for ii = 1:ObjectListSize
%     OrderedMatchingResults{tempindex} = MatchingRankedRestlts{ii};
%     tempindex = tempindex - 1;
% end

tempindex = 1;
for ii = 1:ObjectListSize
    OrderedMatchingResults{tempindex} = MatchingRankedRestlts{ii};
    tempindex = tempindex + 1;
end


end

