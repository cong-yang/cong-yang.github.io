function [ dissimilarity ] = f_point_distance( point1x,point1y,point2x,point2y,pathes1,pathes2, normfac1, normfac2, radiMatrix1, radiMatrix2, m, alpha )
%f_point_distance: this function is used to calculate the matching cost between
%two endpoints p1[point1x, point1y] and p2[point2x, point2y].
% the matching cost c(p1,p2) between p1 and p2 is estimated based on the
% pathes to all other vertices in pathes1 and pathes2 that emanate from
% p1 and p2, correspondingly. 
% input:
%       [point1x, point1y]: the first end point
%       [point2x, point2y]: the second end point
%       pathes1: all pathes in skeleton 1
%       pathes2: all pathes in skeleton 2
%       normfac1: normalization factor for pathes1
%       normfac2: normalization factor for pathes2
%       radiMatrix1: distance transform 1
%       radiMatrix2: distance transform 2
%       m: number of sample points on each path
%       alpha: weight factor for radius and path length

% output:
%       similarity: similarity between p1 and p2

myrow = 1;
for i=1:length(pathes1)
    start1x = pathes1{i,1}(1);
    start1y = pathes1{i,1}(2);
    if point1x == start1x && point1y == start1y
        mycolumn = 1;
        for j=1:length(pathes2)
            start2x = pathes2{j,1}(1);
            start2y = pathes2{j,1}(2);
            if point2x == start2x && point2y == start2y
                mypath1 = pathes1{i,3};
                mypath2 = pathes2{j,3};
                [sum] = f_path_distance( mypath1,mypath2,normfac1,normfac2,m,alpha,radiMatrix1,radiMatrix2 );
                pdMatrix(myrow,mycolumn) = sum;
                mycolumn = mycolumn + 1;
            end
        end
        myrow = myrow + 1;
    end
end

%pdMatrix = abs(pdMatrix);%should we use it or not?

[dissimilarity,~,~,~] = f_OSB(pdMatrix, Inf, Inf, Inf,-1);
end

