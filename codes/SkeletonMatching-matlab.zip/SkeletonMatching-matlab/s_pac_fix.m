% fid = fopen('AllObjects.txt', 'wt');
% for i = 1:216
%     %sbatch --output=log/log_1_3_4_56 --job-name=1_3_4_56 job.slurm 1 3 4 56
% %     fprintf(fid, '%s%d%s%d%s%d\n', 'sbatch --output=log/', i ,' --job-name=', i, ' job.slurm ', i);
%     myline = strcat('sbatch --output=log/',num2str(i),' --job-name=',num2str(i),' job.slurm',{' '},num2str(i),'\n');
%     myline = [myline{:}];
%     fprintf(fid,myline);
% end
% fclose(fid);

resultsdir = 'resources/results/additional/results1000/';

alldata = dir(fullfile(resultsdir,['*','.mat']));
N = size(alldata,1);
for i = 1:N
    object1 = alldata(i,1).name;
    tempname =  regexp(object1,'.mat','split');
    objectname1 = tempname{1};
    
    %load results
    load([resultsdir,object1]);
    
    %packaging results
    TotalResults{i} = {objectname1,matchingresult};
    display(objectname1);
end