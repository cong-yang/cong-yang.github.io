function [ dissimilarity, corresponding ] = f_object_similarity( m, alpha, pathes1, pathes2, endpoints1, endpoints2, radiMatrix1, radiMatrix2, normfac1, normfac2)
%f_object_similarity: to calculate similarity between two objects
%   input:
%         m: number of sample points
%         alpha: weight factor for radius and path length
%         Shape1: shape of object1
%         Shape2: shape of object2
%         Skeleton1: skeleton of object1
%         Skeleton2: skeleton of object2
%   output:
%         dissimilarity: dissimilarity value between two objects
%         corresponding: corresponding between endpoints

%m = 30; %number of sample points on one skeleton path
%alpha = 70; %weight factor for radius and path length

% contour1 = im2bw(contour1);
% contour2 = im2bw(contour2);

% radiMatrix1 = f_get_RadiMatrix(contour1);
% radiMatrix2 = f_get_RadiMatrix(contour2);
% 
% normfac1 = sum(sum(contour1));
% normfac2 = sum(sum(contour2));

sep1 = size(endpoints1,1);
sep2 = size(endpoints2,1);

DistanceMatrix = zeros(sep1,sep2);

for i = 1:sep1
    point1x = endpoints1(i,1);
    point1y = endpoints1(i,2);
    for j = 1:sep2
        point2x = endpoints2(j,1);
        point2y = endpoints2(j,2);
        [dissimilarity] = f_point_distance(point1x,point1y,point2x,point2y,pathes1,pathes2, normfac1, normfac2, radiMatrix1, radiMatrix2, m, alpha);
        DistanceMatrix(i,j) = dissimilarity;
    end
end

%finally, we compute the total disimilarity between object1 and object2
%with the Hungarian Algorithm on DistanceMatrix. Since object1 and object2
%may have different numbers of end nodes, the total dissimilarity value
%should include the penalty for each nodes that did not find any partner.

%To achieve this, we simply add additional rows with a constant value to
%DistanceMatrix so that DistanceMatrix becoomes a square matrix. The
%constant value const is the average of all the other values in
%DistanceMatrix.
[NewDistanceMatrix] = f_Adding_Dummy(DistanceMatrix);

%Hungarian algorithm to get dissimilarity and corresponding
[corresponding, dissimilarity] = f_Hungarian_Corresponding(NewDistanceMatrix);

end

