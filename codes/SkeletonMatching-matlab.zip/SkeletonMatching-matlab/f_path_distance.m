function [ sum ] = f_path_distance( path1,path2,normfac1,normfac2,m,alpha,radiMatrix1,radiMatrix2 )
%this function is used to calculate the distace between two skeleton pathes

l1 = size(path1,1)/normfac1;
l2 = size(path2,1)/normfac2;

%%%new added%%%%%%%%%%%%%
% mylength1 = size(path1,1);
% mylength2 = size(path2,1);
% if mylength1 > mylength2
%     m = mylength2;
% else
%     m = mylength1;
% end
%%%new added end%%%%%%%%

path1 = f_sample_Points(path1,m);
path2 = f_sample_Points(path2,m);

sum = 0;
for i=1:m
    ri1 = radiMatrix1(path1(i,1),path1(i,2));
    ri2 = radiMatrix2(path2(i,1),path2(i,2));
    numerator = (ri1-ri2)^2;
    denumerator = ri1+ri2;
    if denumerator == 0
        sum = sum + 0;
    else
        sum = sum+(numerator / denumerator);
    end
end

sum = sum+alpha* ( ((l1-l2)^2) / (l1+l2) );

end