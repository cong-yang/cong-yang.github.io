clear all;
clc
% clear all;
% clc
% 
% %object class for analysis
% myobjectname = 'bird02';
% objectclass = 'bird';
% 
% %load human perception
% load('resources\results\machine\TotalResults-15-one-to-one-kimia216.mat');
% for i = 1:216
%     queryname = TotalResults{i}{1};
%     if strcmp(queryname,myobjectname) == 1
%         myresults = TotalResults{i}{2};
%         break;
%     end
% end
% 
% for i = 1:216
%     objectname = myresults{i}{1};
%     dissimilarity = myresults{i}{2};
%     tempobjectname = regexp(objectname,'\d*','split');
%     objectcategory = tempobjectname{1};
%     if strcmp(objectcategory,objectclass) == 1
%         display([objectname,' = ', num2str(dissimilarity)]);
%     end
% end

%%
%mean dissimilarity value in each class
%first step: create the class matrix
AllMatrix{1,1} = 'bird';
AllMatrix{2,1} = 'bone';
AllMatrix{3,1} = 'brick';
AllMatrix{4,1} = 'camel';
AllMatrix{5,1} = 'car';
AllMatrix{6,1} = 'children';
AllMatrix{7,1} = 'classic';
AllMatrix{8,1} = 'elephant';
AllMatrix{9,1} = 'face';
AllMatrix{10,1} = 'fork';
AllMatrix{11,1} = 'fountain';
AllMatrix{12,1} = 'glas';
AllMatrix{13,1} = 'hammer';
AllMatrix{14,1} = 'heart';
AllMatrix{15,1} = 'key';
AllMatrix{16,1} = 'misk';
AllMatrix{17,1} = 'ray';
AllMatrix{18,1} = 'turtle';

%load results
load('resources\results\machine\TotalResults-14-one-to-one-kimia216.mat');
temptempindex = 1;
for i = 1:length(TotalResults)
    myquery = TotalResults{i}{1};
    myresults = TotalResults{i}{2};
    tempobjectname = regexp(myquery,'\d*','split');
    querycategory = tempobjectname{1};
    myindex = 0;
    for j = 1:size(AllMatrix,1)
        if strcmpi(querycategory,AllMatrix{j,1}) == 1
            myindex = j;
            break;
        end
    end
    tempindex = 1;
    if temptempindex > 12
        temptempindex = 1;
    end
    for j = 1:length(myresults)
        myobject = myresults{j}{1};
        mydistance = myresults{j}{2};
        tempobjectname = regexp(myobject,'\d*','split');
        objectcategory = tempobjectname{1};
        if strcmpi(objectcategory,querycategory) == 1
            AllMatrix{myindex,2}(temptempindex,tempindex) = mydistance;
            tempindex = tempindex + 1;
        end
        if tempindex > 12
            break;
        end
    end
    temptempindex = temptempindex + 1;
end

display('Finished!');

%calculate the mean value for each caltogory
for i = 1:size(AllMatrix,1)
    mymatrix = AllMatrix{i,2};
    mymean = mean(mean(mymatrix));
    AllMatrix{i,3} = mymean;
    display([AllMatrix{i,1},' = ',num2str(mymean)]);
end

display('Finally Finished!');



