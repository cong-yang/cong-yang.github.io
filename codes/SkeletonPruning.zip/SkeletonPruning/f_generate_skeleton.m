function [ fullskeleton,prunedskeleton ] = f_generate_skeleton( aa,bb,aaa,bbb,newimg,contour)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here

NONO = length(aaa);
I3 = bwperim(newimg); %find perimeter of the original shape
mark = f_curve_div(aa,bb,aaa,bbb,NONO,I3); %make signs to boundary curve
[p,q] = find(mark~=0);

u = length(p);
for i = 1:u
    mark(p(i),q(i)) = mark(p(i),q(i)) + 1;
end

mark = f_mark_other(mark, I3, contour);
fullskeleton = f_skeleton_grow_algorithm(newimg,4,mark);
bwThinned = bwmorph(fullskeleton,'thin');

[fullskeleton,sy,sx] = f_prune_skeleton(bwThinned, aaa, bbb);

skeleton = zeros(size(contour,1),size(contour,2));
for i=1:size(sx,1)
    skeleton(sy(i),sx(i)) = 1;
end

prunedskeleton = skeleton;
end

