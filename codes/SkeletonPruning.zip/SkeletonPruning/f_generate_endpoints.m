function [aa,bb, aaa, bbb] = f_generate_endpoints( newimg, dceweight )
%f_generate_endpoints: this function is used to generate skeleton endpoints
%                      for skeleton pruning.
%   input:
%         newimg: processed image
%         dceweight: weight for discrete curve evolution(maximum number of endpoints)
%   output:
%          [aa,bb]: axis of object contour
%          [aaa,bbb]: axis of endpoints

[aa,bb,~] = f_get_contour(newimg);
[temppoints,~] = f_evolution([aa',bb'],dceweight);

a = temppoints(:,1);
b = temppoints(:,2);
NO = length(a);

[convex_temp,concave_temp] = f_find_Convex(a,b,NO);
convex = zeros(1,NO);
convex(convex_temp) = 1;

m=length(a);
for i=1:m
    intersect(i) = f_intersecto(a,b,i,concave_temp,1);
end
final = convex - intersect;

remain = find(final == 1);
aaa = a(remain);
bbb = b(remain);

end

