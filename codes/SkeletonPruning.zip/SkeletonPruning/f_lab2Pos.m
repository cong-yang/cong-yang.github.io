function [x,y] = f_lab2Pos(lab,m,n)
%---------------------------------------
%Name:  [x,y] = Lab2Pos(lab,n)
%Desc:  get axis value of the element, based on mark
%Para:  lab: element mark, ordered by column prority
%       m,n  dimensionality of the matrix
%Return:x,y  axis value(row and column number) of the element
%---------------------------------------
l = lab-1;
x = floor(l/m)+1;
y = mod(l,m)+1;

[y,x] = ind2sub([m,n],lab);