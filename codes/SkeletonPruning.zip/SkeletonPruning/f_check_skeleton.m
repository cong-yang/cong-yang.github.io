function bsk=f_check_skeleton(bw,dist,lab,i,j,ro,mark)


[m,n] = size(dist);
bsk = 0;

qNeighbor = [];
nNeighbor = 0;

% index of closest non-zero value
q = zeros(1,2);

% closest contour index corresponding to the point i,j
% (related to the size m,n)
[q(1),q(2)] = f_lab2Pos(lab(i,j),m,n);

% relative position position of closest point to (i,j)
q = q-[j,i];

for qi = max(i-1,1):min(i+1,m);
    for qj = max(j-1,1):min(j+1,n);
        bIn = false;
        % if neighboring points inside shape (== 0) AND
        % if current observation point does not equal the middle point
        if bw(qi,qj) == 0 && any([i,j]~=[qi,qj]);
            tq = zeros(1,2);
            % closest contour points of all neighbors of (i,j) 
            [tq(1),tq(2)] = f_lab2Pos(lab(qi,qj),m,n);
            % relative position to (i,j)
            tq = tq-[j,i];
            for k = 1:nNeighbor;
                % get rid of duplicates
                if all(tq == qNeighbor(k,:));
                    bIn  = true;
                    break;
                end;
            end;
            
            % if current neighbor (its realtive position of the closest contour point) is no duplicate add
            if ~bIn && ~isempty(tq);
                nNeighbor = nNeighbor+1;
                qNeighbor  = [qNeighbor;tq];
            end;
        end;
    end;
end;

% check if conctivity criterion is satisfied
bIsSkeleton = false;

%%%% NOT PART OF THE PAPER %%%%
pro =2*dist(i,j)^2;
%proo=dist(i,j)^2/16;

for k = 1:nNeighbor;
    % squared distance between closest contour points
    d = sum((q-qNeighbor(k,:)).^2);
    a1=q(1)+j;
    b1=q(2)+i;
    a2=qNeighbor(k,1)+j;
    b2=qNeighbor(k,2)+i;
    %temp=(a2-a1)^2+(b2-b1)^2
    
    part1 = abs(norm(q)^2 - norm(qNeighbor(k,:))^2);
    part2 = max(abs(q-qNeighbor(k,:)));
    if d >= ro && floor(part1) <= floor(part2) %abs(sum(q.^2) - sum(qNeighbor(k,:).^2)) <= max(abs( q-qNeighbor(k,:)))
    
%     if d >= min(pro,ro) && abs(sum(q.^2) - sum(qNeighbor(k,:).^2)) <= max(abs( q-qNeighbor(k,:)));
%         % mark(b1,a1) ~= mark(b2,a2) means, that the contour parts,
%         % separated by endpoints, are not the same
%         %if abs(sum(q.^2) - sum(qNeighbor(k,:).^2)) <=1*max(abs( q-qNeighbor(k,:))) && mark(b1,a1)~=mark(b2,a2) %&&temp>121;
%         for b1 = max(b1-1,1):min(b1+1,m)
%             for a1 = max(a1-1,1):min(a1+1,n)
%                 for b2 = max(b2-1,1):min(b2+1,m)
%                     for a2 = max(a2-1,1):min(a2+1,n)
%                         if mark(b1,a1) ~= mark(b2,a2)
                             bIsSkeleton = true;
                             break;
%                         end;
%                     end
%                 end
%             end
%         end
%     end

    end
end

if bIsSkeleton;
    bsk = dist(i,j);
end;

                
                            
        
        