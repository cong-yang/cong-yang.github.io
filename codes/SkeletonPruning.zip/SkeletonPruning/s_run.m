clear all;
close all;

resize = 1;
dceweight = 10; %this is the parameter

image = imread('butterfly08.png');
image = im2bw(image);
image  = 1 - image;
[newimg,mycontour,~] = f_image_preprocessing(image,resize);

[contourx, contoury, endpointX,endpointY] = f_generate_endpoints(newimg, dceweight);

[~,skeleton] = f_generate_skeleton(contourx,contoury,endpointX,endpointY,newimg,mycontour);

myshow = mycontour + skeleton;
aaa = 1 - myshow;
imshow(aaa);

hold on;
[x,y] = size(skeleton);
for i = 1:x
    for j = 1:y
        if skeleton(i,j) == 1
            plot(j,i,'r.');
        end
    end
end
hold off;