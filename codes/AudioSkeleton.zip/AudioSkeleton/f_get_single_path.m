function [ path ] = f_get_single_path( sid,eid,newSkeletonBranches )
%f_get_single_path: this function is used to get single skeleton branch by
%start and end node id.
%   input:
%         sid: start point id
%         eid: end point id
%         newSkeletonBranches: all pathes
%   output:
%         path: a single path

for i = 1:length(newSkeletonBranches)
    if newSkeletonBranches{i,1} == sid && newSkeletonBranches{i,2} == eid
        path = newSkeletonBranches{i,3};
        return;
    end
end


end

