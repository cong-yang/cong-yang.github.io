function [ boolean_neighbour ] = f_is_neighbour( point1_cox, point1_coy, point2_cox, point2_coy )
%f_is_neighbour: check if the coordinates specified by the 
%                parameter are neighbor coordinates.
% input:
%       point1_cox: x axis of the point1
%       point1_coy: y axis of the point1
%       point2_cox: x axis of the point2
%       point2_coy: y axis of the point2

% output:
%       boolean_neighbour: neighbour(1) or not(0).

boolean_neighbour = 0;

for x_neighbor = -1:1
    for y_neighbor = -1:1
        if abs(x_neighbor) + abs(y_neighbor) ~= 0
            if point1_cox + x_neighbor == point2_cox && point1_coy + y_neighbor == point2_coy
                boolean_neighbour = 1;
                return;
            end
        end
    end
end

end

