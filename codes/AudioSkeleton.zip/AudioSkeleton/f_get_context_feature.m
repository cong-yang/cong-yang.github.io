function [ myfeature ] = f_get_context_feature( ex, ey, endpoints, junctionpoints, branches )
%f_get_context_feature: this function is used to calculate the feature of
%                       skeleton endpoint [ex,ey].
%   input: 
%         ex: x axis of endpoint
%         ey: y axis of endpoint
%         endpoints: the point list of endpoints
%         junctionpoints: the point list of junction point
%   output:
%          myfeature: the feature vector of this point

%1. the horizontal distance from the left end junction point
%1. the length of its branch
%2. the mean distance between it to all other endpoints.
%3. the mean distance between it to all other junction points.
%4. the mean angle between it to all other endpoints.
%5. the mean angle between it to all other junction points.
%normalisation factor: the length of its main fish bone

%normalisation factor
fishmax = max(junctionpoints(:,2));
fishmin = min(junctionpoints(:,2));
normfac1 = (fishmax - fishmin)/10;
normfac2 = 0;
for i = 1:length(branches)
    sinlength = size(branches{i},1);
    normfac2 = normfac2 + sinlength;
end
normfac2 = normfac2/length(branches);

%generate the horizontal distance from the left juntion point
horidis = abs(ey - fishmin);

%generate the length of its branch
[branlength] = f_get_branch_length(ex, ey, endpoints, junctionpoints, branches);

%generate the mean distance between it to all other endpoints.
[meandisends] = f_get_mean_distance(ex, ey, endpoints);

%generate the mean distance between it to all other junction points
[meandisjuncs] = f_get_mean_distance(ex, ey, junctionpoints);

%generate the mean angle between it to all other endpoints
[meanangends] = f_get_mean_angle(ex,ey, endpoints);

%generate the mean angle between it to all other junction points
[meanangjuncs] = f_get_mean_angle(ex,ey, junctionpoints);

%normalisation
%branlength = branlength/normfac2;
% meandisends = meandisends/normfac1;
% meandisjuncs = meandisjuncs/normfac1;

myfeature = [horidis, branlength, meandisends, meandisjuncs, meanangends, meanangjuncs];

end

