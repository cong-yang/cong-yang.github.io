function [ mybranch ] = f_deeperer_search( myx, myy, junctionpoints, branches )
%f_deeperer_search: the second deeper search

mybranch = 0;
for i = 1:length(branches)
    sinbranch = branches{i};
    sx = sinbranch(1,1);
    sy = sinbranch(1,2);
    if myx == sx && myy == sy
        %check the last point
        mylength = size(sinbranch,1);
        ex = sinbranch(mylength,1);
        ey = sinbranch(mylength,2);
        [bool_contain] = f_list_contains(ex, ey, junctionpoints);
        if bool_contain == 1
            mybranch = sinbranch;
            return;
        end
    end
end

end

