function [ SkeletonBranch ] = f_create_part( startx,starty,endx,endy,nodesOnPart )
%If an end node or junction node has been reached, this function can be
%used to create the part between the startnode and the current node. 

%  input:
%        [startx, starty]: the startnode of the new part
%        [endx,endy]: the endnode of the new part
%        all nodes lieing on this part, in the order of their occurance.
%  output:
%        SkeletonBranch: a skeleton part, starting at startnode and ending 
%                        at end node, connected by the list of skeleton 
%                        nodes passed as nodesOnPath

%SkeletonBranch = zeros(branchsize,2);
SkeletonBranch = [];
[my_contain] = f_list_contains(startx, starty, nodesOnPart);
if my_contain == 0
    SkeletonBranch(1,1) = startx;
    SkeletonBranch(1,2) = starty;    
end

myindex = size(SkeletonBranch,1);
for i = 1:size(nodesOnPart,1)
    myindex = myindex + 1;
    SkeletonBranch(myindex,1) = nodesOnPart(i,1);
    SkeletonBranch(myindex,2) = nodesOnPart(i,2);
end

myindex = size(SkeletonBranch,1) + 1;
[my_contain] = f_list_contains(endx, endy, SkeletonBranch);
if my_contain == 0
    SkeletonBranch(myindex,1) = endx;
    SkeletonBranch(myindex,2) = endy;
end

end

