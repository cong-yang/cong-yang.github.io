function [ juncbranches ] = f_get_junc_branches( jx, jy, junctionstay, SkeletonBranchs )
%f_get_junc_branches: this function is used to generate branches that are
%                     ending with the same junction point(jx, jy).
%   input:
%          jx: x axis of the junction point
%          jy: y axis of the junction point
%          junctionstay: all kept junction points
%          SkeletonBranchs: all skeleton branches
%   output:
%          juncbranches: the branches that are sharing the same junction
%                        point.

myindex = 1;
for i = 1:length(SkeletonBranchs)
    sinbranche = SkeletonBranchs{i};
    mylength = size(sinbranche,1);
    bx = sinbranche(mylength,1);
    by = sinbranche(mylength,2);
    [bool_stay] = f_is_junctionstay(sinbranche, junctionstay);
    if jx == bx && jy == by && bool_stay == 0
        juncbranches{myindex} = sinbranche;
        myindex = myindex + 1;
    end
end



end

