function [ branlength ] = f_get_branch_length( ex, ey, endpoints, junctionpoints, branches )
%f_branch_length: this function is used to generate length of a branch
%                 which start from the endpoint (ex,ey)
%   input:
%         ex: x axis of the endpoint
%         ey: y axis of the endpoint
%         junctionpoints: junction point list
%         branches: all branches
%         pathes: all pathes
%   output:
%         branlength: the length of the branch

branlength = 0;

countbran = 1;
%1. search the branch from branches
for i = 1:length(branches)
    sinbranch = branches{i};
    myx = sinbranch(1,1);
    myy = sinbranch(1,2);
    if myx == ex && myy == ey
        targetbraches{countbran} = sinbranch;
        countbran = countbran + 1;
    end
end

%2. check the target branches
numbran = length(targetbraches);
if numbran == 1
    mybranch = targetbraches{1};
    %check whether the last point belongs to the junction point
    mylength = size(mybranch,1);
    myx = mybranch(mylength,1);
    myy = mybranch(mylength,2);
    [bool_contain] = f_list_contains(myx, myy, junctionpoints);
    if bool_contain == 1 %correct branch
        branlength = mylength;
        plot(mybranch(:,2),mybranch(:,1),'y');
    else
        %still need to search deeper to find the real junction point
        [deepbranch] = f_deeper_search(myx, myy, endpoints, junctionpoints, branches);
        if length(deepbranch) == 1
            branlength = mylength + size(deepbranch{1},1);
            plot(mybranch(:,2),mybranch(:,1),'y');
            pause(1);
            plot(deepbranch{1}(:,2),deepbranch{1}(:,1),'g');
            pause(1);
        else
            branlength = mylength + size(deepbranch{1},1)+size(deepbranch{2},1);
            plot(mybranch(:,2),mybranch(:,1),'y');
            pause(1);
            plot(deepbranch{1}(:,2),deepbranch{1}(:,1),'g');
            pause(1);
            plot(deepbranch{2}(:,2),deepbranch{2}(:,1),'b');
            pause(1);
        end

    end
else
    display(['there are ',num2str(numbran),' branches!!']);
    return;
end

%branlength = log(branlength);

end

