function [ endpoints, junctionpoints ] = f_point_detection( skeleton )
%f_point_detection: this function is used to detect endpoints and
%                   junction points fron skeleton.
%   input:
%         skeleton: original skeleton graph, black background, white
%                   foreground.
%   output:
%          endpoints: endpoint list
%          junctionpoints: junction point list

%first step: get all skeleton point
[skex,skey] = find(skeleton==1);

%second step:
indexendpoint = 1;
indexjunction = 1;
for i = 1:size(skex,1)
    pointx = skex(i);
    pointy = skey(i);
    [neighbours,~] = f_all_neighbors(pointx, pointy, skeleton);
    if neighbours == 1 %endpoint
        endpoints(indexendpoint,1) = pointx;
        endpoints(indexendpoint,2) = pointy;
        indexendpoint = indexendpoint + 1;
    end
    
    if neighbours > 2 %junction point
        junctionpoints(indexjunction,1) = pointx;
        junctionpoints(indexjunction,2) = pointy;
        indexjunction = indexjunction + 1;
    end
end

%third step: clean junction points.
%In 2D as well as in 3D, in some node constellations
%it can happen that in one crossing of skeleton branches, multiple skeleton
%nodes are recognized as junction nodes as they all have more than two
%neighbors. These junction nodes can than be grouped into a NodeArea.
%The NodeArea clean function will try to pick one of the nodes in a node 
%area more or less wise.
[junctionpoints] = f_clean_juntionpoints(junctionpoints);

%fourth step: recheck all junction points to avoid the situation of 
%sawtooth junction points

end

