function [ mybranch ] = f_deeper_search( myx, myy, endpoints, junctionpoints, branches )
%f_deeper_search: this function is used to search the branch that start with
%                 point(myx, myy), and end with one of the junctionpoints.
%   input:
%         myx: x axis of the start point
%         myy: y axis of the start point
%         junctionpoints: junction point list
%         branches: all branches
%   output:
%         mybranch: searched branch
for i = 1:length(branches)
    sinbranch = branches{i};
    sx = sinbranch(1,1);
    sy = sinbranch(1,2);
    if myx == sx && myy == sy
        %check the last point
        mylength = size(sinbranch,1);
        ex = sinbranch(mylength,1);
        ey = sinbranch(mylength,2);
        [bool_contain] = f_list_contains(ex, ey, junctionpoints);
        if bool_contain == 1
            mybranch{1} = sinbranch;
            return;
        else
            [end_contain] = f_list_contains(ex, ey, endpoints);
            if end_contain == 0 %not endpoint
                [deeperbrach] = f_deeperer_search(ex, ey, junctionpoints, branches);
                if deeperbrach ~= 0
                    mybranch{1} = sinbranch;
                    mybranch{2} = deeperbrach;
                    return;
                end
            end
        end
    end
end

