function [ NewNodeArea ] = f_remove_duplicate( junctionpoints, tempNodeArea )
%f_remove_duplicate: this function is used to remove the duplicate nodes in
%tempNodeArea with the help of junctionpoints.

% input:
%       junctionpoints: junction point list
%       tempNodeArea: node area point list
% output:
%        newtempNodeArea: node area point list after remove duplicate points.

%Remove duplicate data
tempindex = 1;
for mmm = 1:size(junctionpoints,1)
    myx = junctionpoints(mmm,1);
    myy = junctionpoints(mmm,2);
    [bool_contain] = f_list_contains(myx, myy, tempNodeArea);
    if bool_contain == 1
        NewNodeArea(tempindex,1) = myx;
        NewNodeArea(tempindex,2) = myy;
        tempindex = tempindex + 1;
    end
end

end

