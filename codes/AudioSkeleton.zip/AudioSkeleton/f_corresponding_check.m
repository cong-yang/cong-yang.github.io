function [ correspondingfix ] = f_corresponding_check( correspondingori, maxi1 )
%f_corresponding_check: this function is used to check and remove the 
%uncorrect matchings due to the time series surpassing
%   input:
%         correspondingori: the original correspondings
%   output:
%         correspondingfix: the fixed correspondings

correspondingfix = correspondingori;
tempindex = 1;
for m = 1:size(correspondingori,2)
    if correspondingori(1,m) <= maxi1
        tempcorres(1,tempindex)  = m;
        tempcorres(2,tempindex)  = correspondingori(1,m);
        tempindex = tempindex + 1;
        %display([num2str(Cooresponding_Points_up(1,m)),':',num2str(m)]);
    end
end

mytemp = tempcorres(2,:);
mytempsorted = sort(mytemp);
Dvalues = mytemp - mytempsorted;

for i = 1:length(Dvalues)
    if Dvalues(i) > 0
        correspondingfix(tempcorres(1,i)) = maxi1 + maxi1;
    end
end

end

