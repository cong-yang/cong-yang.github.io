function [ mysimilarity ] = f_get_point_similarity( feature1, feature2 )
%f_get_point_similarity: this function is used to generate similarity
%                        between two points based on their features

%the first method
% s1 = abs(feature1(1)-feature2(1))/abs(feature1(1)+feature2(1));
% s2 = abs(feature1(2)-feature2(2))/abs(feature1(2)+feature2(2));
% s3 = abs(feature1(3)-feature2(3))/abs(feature1(3)+feature2(3));
% s4 = abs(feature1(4)-feature2(4))/abs(feature1(4)+feature2(4));
% s5 = abs(feature1(5)-feature2(5))/abs(feature1(5)+feature2(5));
% 
% mysimilarity = s1+s2+s3+s4+s5;
% mysimilarity = -1*mysimilarity;

%the second method
%http://www.analytictech.com/mb876/handouts/distance_and_correlation.htm
%here we use the correlation between feature1 and feature2
% alpha = 10;
% 
% locat1 = feature1(1:3);
% angle1 = feature1(4:5);
% 
% locat2 = feature2(1:3);
% angle2 = feature2(4:5);
% 
% %similarity between locat1 and locat 2
% ux = mean(locat1);
% uy = mean(locat2);
% 
% ox = std(locat1);
% oy = std(locat2);
% 
% mycount = 0;
% for i = 1:3
%     mycount = mycount + (locat1(i)*locat2(i)-ux*uy)^2;
% end
% 
% mycount = mycount/3;
% simlocat = mycount/(ox*oy);
% 
% %similarity between angle1 and angle2
% fenmu = alpha*alpha;
% fenzi = 0;
% for i = 1:2
%     fenzi = fenzi+ ((angle1(i) - angle2(i)).^2);
% end
% simangle = (fenzi)/(fenmu);
% 
% mysimilarity = simlocat + simangle;
% mysimilarity = roundn(mysimilarity,-4);

%the third method
% ux = mean(feature1);
% uy = mean(feature2);
% 
% ox = std(feature1);
% oy = std(feature2);
% 
% mycount = 0;
% for i = 1:5
%     mycount = mycount + (feature1(i)*feature2(i)-ux*uy);
% end
% 
% mycount = mycount/5;
% mysimilarity = mycount/(ox*oy);
% mysimilarity = 1-mysimilarity;


% %the fourth method
% locat1 = feature1(1:2);
% angle1 = feature1(3:4);
% locat2 = feature2(1:2);
% angle2 = feature2(3:4);
% sigma = 0.2;
% alpha = pi/4;
% 
% for i = 1:2
%     fenzi = (locat1(i) - locat2(i)).^2;
%     fenmu = (sigma*max(locat1(i),locat2(i))).^2;
%     tempva = exp(-((fenzi)/(fenmu)));
%     AffMatDistance(i) = roundn(tempva,-4);
% end
% 
% sim1 = sum(AffMatDistance)/2;
% 
% for i = 1:2
%     fenmu = alpha*alpha;
%     fenzi = (angle1(i) - angle2(i)).^2;
%     tempva = exp(-((fenzi)/(fenmu)));
%     AffMatAngle(i) = roundn(tempva,-4);
% end
% 
% sim2 = sum(AffMatAngle)/2;
% 
% mysimilarity = sim1 + sim2;

%the fifth method
% mysimilarity = dot(feature1,feature2)/(norm(feature1)*norm(feature2));
% mysimilarity = roundn(mysimilarity,-4);
% mysimilarity = 1-mysimilarity;


%the sixth method

% locat1 = feature1(1:3);
% angle1 = feature1(4:5);
% 
% locat2 = feature2(1:3);
% angle2 = feature2(4:5);
% 
% %similarity between locat1 and locat 2: euclidean distance
% simlocat = norm(locat1 - locat2);
% 
% %similarity between angle1 and angle2
% simangle = norm(angle1 - angle2);
% 
% mysimilarity = (simlocat + 0.8*simangle)/2;
% mysimilarity = roundn(mysimilarity,-4);

%the seventh method
locat1 = feature1(1:2);
locat2 = feature2(1:2);
%mysimilarity = abs(locat1(1) - locat2(1));
mysimilarity = norm(locat1 - locat2);
%mysimilarity = simangle;
end

