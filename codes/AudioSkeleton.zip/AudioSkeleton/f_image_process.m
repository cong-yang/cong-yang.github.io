function [ shapecontour, newshape ] = f_image_process( orishape, smoothing, para_resize)
%f_get_contour: this function is used to resize the shape, smooth the shape contour, and
%return the smoothed contour and image
%   input:
%         orishape: the original shape
%         smoothing: the smoothing power
%         para_resize: shape resize power
%   output:
%         shapecontour: the smoothed shape contour
%         newshape: the smoothed shape

%resize shape
orishape = imresize(orishape, para_resize, 'nearest');

contour_img = f_extract_Contour(orishape);
[contour_y, contour_x] = ind2sub(size(contour_img), find(contour_img > 0));
contour = bwtraceboundary(contour_img, [contour_y(1), contour_x(1)], 'W', 8);

[ps,~] = f_dpsimplify(contour, smoothing);

% convert simplified contour polygon back to pixel image - easier to compute point to contour distances
x = [];
y = [];   
for li = 1:size(ps,1)-1
    [x1, y1] = f_bresenham(ps(li,1),ps(li,2),ps(li+1,1),ps(li+1,2));
    x = [x1;x];
    y = [y1;y];
end

x = x-min(x)+1;
y = y-min(y)+1;
simp_img = zeros(max(x),max(y));
idxs = sub2ind([max(x),max(y)],x,y);
simp_img(idxs) = 1;

% update information
myshape = imfill(simp_img);


%extend the background of new shape to make sure boundary of its background
%is bigger than the shape's contour.
[x,y] = size(myshape);
x = x+40;
y = y+40;
[shax,shay] = find(myshape==1);
newshape = zeros(x,y);

for i = 1:length(shax)
    newshape(shax(i)+20,shay(i)+20) = 1;
end
shapecontour = f_extract_Contour(newshape);
end

