function [ myskeleton, endpointlist ] = f_update_skeleton( myskeleton, branch, endpointlist )
%f_update_skeleton: this function is used to remove the branch from
%                   myskeleton.
%   input:
%          myskeleton: the original skeleton
%          branch: the branch point list that to be removed
%          endpointlist: the skeleton endpoint list, this input is used to
%                        ensure the branch point list is started with
%                        skeleton endpoint.
%   output:
%          myskeleton: the pruned skeleton
%          endpointlist: the renewed endpointlist

%1. ensure the branch point list is started with skeleton endpoint
stx = branch(1,1);
sty = branch(1,2);
[bool_contain] = f_list_contains(stx, sty, endpointlist);
if bool_contain == 0
    mybranch = flipud(branch);
    stx = mybranch(1,1);
    sty = mybranch(1,2);
    [mycontain] = f_list_contains(stx, sty, endpointlist);
    if mycontain == 1
        branch = mybranch;
    else
        display('branch error!');
        return;
    end
end

%2. remove the branch from skeleton
for i = 1:(size(branch,1)-1)
    myx = branch(i,1);
    myy = branch(i,2);
    myskeleton(myx,myy) = 0;
end

%3. renew the endpoint list
stx = branch(1,1);
sty = branch(1,2);
[endpointlist] = f_update_pointlist(stx, sty, endpointlist);



end

