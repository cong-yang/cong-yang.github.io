function [ m_contour ] = f_extract_Contour( m_image )
%EXTRACTCONTOUR Summary of this function goes here
%   Detailed explanation goes here

% contour_img = edge(img, 'canny');
% contour_img = bwmorph(contour_img, 'dilate');
% contour_img = bwmorph(contour_img, 'bridge');
% contour_img = bwmorph(contour_img, 'thin', 'inf'); 

m_contour = bwmorph(m_image, 'remove');

end

