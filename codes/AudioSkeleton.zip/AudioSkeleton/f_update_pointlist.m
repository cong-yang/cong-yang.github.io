function [ pointlist ] = f_update_pointlist( px, py, pointlist )
%f_update_pointlist:  this function is used to remove the point(px,py)
%                     from the pointlist.
%   input:
%          (px, py): the point to be removed
%          pointlist: all point list
%   output:
%          pointlist: the updated pointlist

%1. find position in the pointlist
myposition = 0;
for i = 1:size(pointlist,1)
    if px == pointlist(i,1) && py ==  pointlist(i,2)
        myposition = i;
        break;
    end
end

%2. remove the point
if myposition == 0 %this point is not exist in the pointlist
    display(['can not find this point [',num2str(px),',',num2str(py),'] in the pointlist!!!']);
    return;
else
    pointlist = setdiff(pointlist,[px,py],'rows','stable');
end

end

