function [ junctionstay, junctionremove ] = f_get_middle_junctions( junctionpoints, para_area )
%f_get_middle_junctions: this function is used to remove the junction
%points which are located far from the middle axis of the skeleton.
%   input: 
%         junctionpoints: the original list of junction points.
%         para_area: the area that junction point will be chosen.
%   output:
%         newjunctionpoints: the new list of selected junction points

%this is used for the baseline
xasix = mean(junctionpoints(:,1));

%this is the area we want
mytop = xasix - para_area;
mybottom = xasix + para_area;

myindex = 1;
reindex = 1;
for i = 1:length(junctionpoints)
    if junctionpoints(i,1) > mytop && junctionpoints(i,1) < mybottom
        junctionstay(myindex,1) = junctionpoints(i,1);
        junctionstay(myindex,2) = junctionpoints(i,2);
        myindex = myindex + 1;
    else
        junctionremove(reindex,1) = junctionpoints(i,1);
        junctionremove(reindex,2) = junctionpoints(i,2);
        reindex = reindex + 1;
    end
end

end

