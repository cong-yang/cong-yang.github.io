function [ bool_stay ] = f_is_junctionstay( sinbranche, junctionstay )
%f_is_junctionstay: this function is used to return whether the endpoints 
%                   of sinbranche belong to the junctionstay point list.
%   input:
%          sinbranche: a single branches
%          junctionstay: staying junction point list
%   output:
%          bool_stay: 0 not belongs, 1 belongs

bool_stay = 0;
mylength = size(sinbranche,1);

enx1 = sinbranche(1,1);
eny1 = sinbranche(1,2);

enx2 = sinbranche(mylength,1);
eny2 = sinbranche(mylength,2);

for i=1:size(junctionstay,1)
    jx = junctionstay(i,1);
    jy = junctionstay(i,2);
    if enx1 == jx && eny1 == jy
        bool_stay = 1;
        return;
    end
    if enx2 == jx && eny2 == jy
        bool_stay = 1;
        return;
    end
end

end

