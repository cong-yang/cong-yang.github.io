function [ similaritymatrix ] = f_get_similarity_matrix( object1, object2 )
%f_get_similarity_matrix: to generate the similarity matrix between each
%                         endpoints in two objects.
%   input:
%         object1: the first object feature
%         object2: the second object feature
%   output:
%         similaritymatrix: similarity matrix

pnum1 = size(object1,1);
pnum2 = size(object2,1);
similaritymatrix = zeros(pnum1, pnum2);

for i = 1:pnum1
    feature1 = object1{i,3};
    for j = 1:pnum2
        feature2 = object2{j,3};
        [mysimilarity] = f_get_point_similarity(feature1, feature2);
        similaritymatrix(i,j) = mysimilarity;
    end
end

% norfac = min(min(similaritymatrix));
% similaritymatrix = similaritymatrix - norfac;

end

