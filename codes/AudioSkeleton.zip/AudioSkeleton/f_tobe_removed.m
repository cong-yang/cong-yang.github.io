function [ toberemoved, tobekept ] = f_tobe_removed( juncbranches )
%f_tobe_removed: this function is used to find the longest branches from
%                juncbranches, and then put the rest branches to the
%                toberemoved.
%   input:
%         juncbranches: the branches
%   output:
%         toberemoved: branches to be removed
%         tobekept: the branch to be kept

keptposibiton = 0;
maxlength = 0;
for i = 1:length(juncbranches)
    sinbranch = juncbranches{i};
    mylength = size(sinbranch,1);
    if mylength >= maxlength
        keptposibiton = i;
        maxlength = mylength;
    end
end

tobekept = juncbranches{keptposibiton};

myindex = 1;
for i = 1:length(juncbranches)
    if i ~= keptposibiton
        toberemoved{myindex} = juncbranches{i};
        myindex = myindex + 1;
    end
end

end

