function [ meanangle ] = f_get_mean_angle( ex,ey, pointlist )
%f_get_mean_angle: this function is used to generate the mean angle between
%                  point(ex,ey) to all other points in pointlist.
%   input:
%         ex: x axis of the endpoint
%         ey: y axis of the endpoint
%         pointlist: all point list
%   output:
%         meanangle: the mean angle

p1 = [ex,ey];
myangle = 0;
mylength = size(pointlist,1);
for i = 1:mylength
    px = pointlist(i,1);
    py = pointlist(i,2);
    p2 = [px,py];
    p3 = p1 - p2;
    myangle = myangle + atan2(p3(1),p3(2));
end

meanangle = myangle/mylength;

end

