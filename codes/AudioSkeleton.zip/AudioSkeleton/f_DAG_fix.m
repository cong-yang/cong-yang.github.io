function [ starts, ends, weights, newSkeletonBranches ] = f_DAG_fix( starts, ends, weights, newSkeletonBranches )
%f_DAG_fix: this function is used to check and correct all graph path to
%ensure all single path have a return path.
%   input:
%        starts: all start id
%        ends: all end id
%        weights: weight between start and end id
%        newSkeletonBranches: all skeleton branches
%   output:
%        new_starts: corrected starts
%        new_ends: corrected ends
%        new_weights: corrected weights
%        new_newSkeletonBranches: corrected skeletonbranches

mylenght = length(starts);

for i = 1:mylenght
    sid = starts(i);
    eid = ends(i);
    weight = weights(i);
    [bool_exit] = f_check_exist(sid,eid,starts,ends);
    if bool_exit == 0 %not exist, add a return path between two ids
        [path] = f_get_single_path( sid,eid,newSkeletonBranches );
        starts(length(starts)+1) = eid;
        ends(length(ends)+1) = sid;
        weights(length(weights)+1) = weight;
        newSkeletonBranches{length(newSkeletonBranches)+1,1} = eid;
        newSkeletonBranches{length(newSkeletonBranches),2} = sid;
        newSkeletonBranches{length(newSkeletonBranches),3} = flipud(path);
    end
end


end

