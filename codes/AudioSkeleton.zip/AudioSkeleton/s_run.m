clear all;
close all;

myimage1 = imread('21-s.png');
myimage2 = imread('32-s.png');

myimage1 = im2bw(myimage1);
myimage1 = 1- myimage1;
mycontour1 = f_extract_Contour(myimage1);
myskeleton1 = bwmorph(myimage1,'skel',Inf);

myimage2 = im2bw(myimage2);
myimage2 = 1- myimage2;
mycontour2 = f_extract_Contour(myimage2);
myskeleton2 = bwmorph(myimage2,'skel',Inf);


[oriskeleton, ~, junctionpoints] = f_skeleton_pruning(myskeleton1);
[oriskeleton] = f_skeleton_fix(oriskeleton);
[SkeletonBranchs, endpoints, ~] = f_skeleton_branches(oriskeleton);
myskeleton1 = oriskeleton;
endpoints1 = endpoints;
junctionpoints1 = junctionpoints;
SkeletonBranchs1 = SkeletonBranchs;

[oriskeleton, ~, junctionpoints] = f_skeleton_pruning(myskeleton2);
[oriskeleton] = f_skeleton_fix(oriskeleton);
[SkeletonBranchs, endpoints, ~] = f_skeleton_branches(oriskeleton);
myskeleton2 = oriskeleton;
endpoints2 = endpoints;
junctionpoints2 = junctionpoints;
SkeletonBranchs2 = SkeletonBranchs;

clear oriskeleton;
clear endpoints;
clear junctionpoints;
clear SkeletonBranchs;

%%

imshow(myskeleton1);
hold on;
xasix1 = mean(junctionpoints1(:,1));
[endpointsup1, endpointsunder1] = f_split_endpoints(endpoints1, xasix1);
for i = 1:size(endpointsup1,1)
    ex = endpointsup1(i,1);
    ey = endpointsup1(i,2);
    [myfeature] = f_get_context_feature(ex, ey, endpointsup1, junctionpoints1, SkeletonBranchs1);
    featureup1{i,1} = ex;
    featureup1{i,2} = ey;
    featureup1{i,3} = myfeature;
end

for i = 1:size(endpointsunder1,1)
    ex = endpointsunder1(i,1);
    ey = endpointsunder1(i,2);
    [myfeature] = f_get_context_feature(ex, ey, endpointsunder1, junctionpoints1, SkeletonBranchs1);
    featureunder1{i,1} = ex;
    featureunder1{i,2} = ey;
    featureunder1{i,3} = myfeature;
end

close all;
imshow(myskeleton2);
hold on;
xasix2 = mean(junctionpoints2(:,1));
[endpointsup2, endpointsunder2] = f_split_endpoints(endpoints2, xasix2);
for i = 1:size(endpointsup2,1)
    ex = endpointsup2(i,1);
    ey = endpointsup2(i,2);
    [myfeature] = f_get_context_feature(ex, ey, endpointsup2, junctionpoints2, SkeletonBranchs2);
    featureup2{i,1} = ex;
    featureup2{i,2} = ey;
    featureup2{i,3} = myfeature;
end

for i = 1:size(endpointsunder2,1)
    ex = endpointsunder2(i,1);
    ey = endpointsunder2(i,2);
    [myfeature] = f_get_context_feature(ex, ey, endpointsunder2, junctionpoints2, SkeletonBranchs2);
    featureunder2{i,1} = ex;
    featureunder2{i,2} = ey;
    featureunder2{i,3} = myfeature;
end

clear ex;
clear ey;
clear i;


%%
close all;
[CostMatrixup] = f_get_similarity_matrix(featureup1, featureup2);
%CostMatrixup = -1*CostMatrixup;
[NewCostMatrix] = f_Adding_Dummy(CostMatrixup);
[Cooresponding_Points_up, ~] = f_Hungarian_Corresponding(NewCostMatrix);


[CostMatrixunder] = f_get_similarity_matrix(featureunder1, featureunder2);
%CostMatrixunder = -1*CostMatrixunder;
[NewCostMatrix] = f_Adding_Dummy(CostMatrixunder);
[Cooresponding_Points_under, ~] = f_Hungarian_Corresponding(NewCostMatrix);
%%
offset = 20; %to control the distance between two objects
%new img
[h1,w1] = size(myskeleton1);
[h2,w2] = size(myskeleton2);

newimgheight = h1 + h2 + offset;
newimgwidth = max(w1,w2);
[h,c] = find(myskeleton1==1);
startpointX = max(h);

img = zeros(newimgheight,newimgwidth);

[w1,c1] = find(myskeleton1 == 1);
for i = 1:length(w1)
    img(w1(i),c1(i)) = 1;
end

[w2,c2] = find(myskeleton2 == 1);
for i = 1:length(w2)
    img(w2(i)+startpointX+offset,c2(i)) = 1;
end
img = 1-img;
imshow(img);

%%
%plot up
hold on;

plot(junctionpoints1(:,2),junctionpoints1(:,1),'*g');
newjunctionpoints2 = zeros(size(junctionpoints2));
for m = 1: size(junctionpoints2,1)
    newjunctionpoints2(m,1) = junctionpoints2(m,1)+startpointX+offset;
    newjunctionpoints2(m,2) = junctionpoints2(m,2);
end
plot(newjunctionpoints2(:,2),newjunctionpoints2(:,1),'*g');

plot(endpointsup1(:,2), endpointsup1(:,1),'b*');
newinteretpointlist2 = zeros(size(endpointsup2));
for m = 1: size(endpointsup2,1)
    newinteretpointlist2(m,1) = endpointsup2(m,1)+startpointX+offset;
    newinteretpointlist2(m,2) = endpointsup2(m,2);
end
plot(newinteretpointlist2(:,2), newinteretpointlist2(:,1),'r+');

%plot upper corresponding
% maxlength2 = size(endpointsup2,1);
% maxlength1 = size(endpointsup1,1);
% for m = 1:maxlength1
%     if Cooresponding_Points_up(1,m) <= maxlength2
%         x1 = endpointsup1(m,1);
%         y1 = endpointsup1(m,2);
%     
%         x2 = newinteretpointlist2(Cooresponding_Points_up(1,m),1);
%         y2 = newinteretpointlist2(Cooresponding_Points_up(1,m),2);
%     
%         line([y1,y2],[x1,x2],'LineWidth',1,'Color',[0 0 0]);
%     end
% end

%maxlength2 = size(endpointsup2,1);
maxlength1 = size(endpointsup1,1);
[Cooresponding_Points_up] = f_corresponding_check(Cooresponding_Points_up, maxlength1);
for m = 1:size(Cooresponding_Points_up,2)
    if Cooresponding_Points_up(1,m) <= maxlength1
        %display([num2str(Cooresponding_Points_up(1,m)),':',num2str(m)]);
        x1 = endpointsup1(Cooresponding_Points_up(1,m),1);
        y1 = endpointsup1(Cooresponding_Points_up(1,m),2);
    
        x2 = newinteretpointlist2(m,1);
        y2 = newinteretpointlist2(m,2);
    
        line([y1,y2],[x1,x2],'LineWidth',1,'Color',[0 0 0]);
    end
end

%%
%plot under
plot(endpointsunder1(:,2), endpointsunder1(:,1),'b*');
newinteretpointlist2 = zeros(size(endpointsunder2));

for m = 1: size(endpointsunder2,1)
    newinteretpointlist2(m,1) = endpointsunder2(m,1)+startpointX+offset;
    newinteretpointlist2(m,2) = endpointsunder2(m,2);
end
plot(newinteretpointlist2(:,2), newinteretpointlist2(:,1),'r+');

%plot under corresponding
maxlength1 = size(endpointsunder1,1);
[Cooresponding_Points_under] = f_corresponding_check(Cooresponding_Points_under, maxlength1);
for m = 1:size(Cooresponding_Points_under,2)
    if Cooresponding_Points_under(1,m) <= maxlength1
        
        x1 = endpointsunder1(Cooresponding_Points_under(1,m),1);
        y1 = endpointsunder1(Cooresponding_Points_under(1,m),2);
    
        x2 = newinteretpointlist2(m,1);
        y2 = newinteretpointlist2(m,2);
    
        line([y1,y2],[x1,x2],'LineWidth',1,'Color',[0 0 0]);
    end
end

hold off;




