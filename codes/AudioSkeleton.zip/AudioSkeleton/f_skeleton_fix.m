function [ oriskeleton ] = f_skeleton_fix( oriskeleton )
%f_skeleton_fix: this function is used to fix the hold in skeleton
%   input:
%         oriskeleton: original skeleton
%   output:
%         oriskeleton: the fixed skeleton

[skex,skey] = find(oriskeleton==1);

for i = 1:size(skex,1)
    x = skex(i);
    y = skey(i);
    if oriskeleton(x+0,y-1) == 0 && oriskeleton(x+0,y-0) == 1 && oriskeleton(x+0,y+1) == 0 && ...
       oriskeleton(x+1,y-1) == 0 && oriskeleton(x+1,y-0) == 0 && oriskeleton(x+1,y+1) == 0 && ...
       oriskeleton(x+2,y-1) == 0 && oriskeleton(x+2,y-0) == 1 && oriskeleton(x+2,y+1) == 0
        display(['plot(',num2str(y),',',num2str(x),',','''','*y','''',')',';']);
        oriskeleton(x+1,y-0) = 1;
    end
    
    if oriskeleton(x+0,y-1) == 0 && oriskeleton(x+0,y-0) == 1 && oriskeleton(x+0,y+1) == 0 && ...
       oriskeleton(x+1,y-1) == 0 && oriskeleton(x+1,y-0) == 0 && oriskeleton(x+1,y+1) == 0 && ...
       oriskeleton(x+2,y-1) == 1 && oriskeleton(x+2,y-0) == 1 && oriskeleton(x+2,y+1) == 0
        display(['plot(',num2str(y),',',num2str(x),',','''','*y','''',')',';']);
        oriskeleton(x+1,y-0) = 1;
    end
    
    if oriskeleton(x+0,y-1) == 0 && oriskeleton(x+0,y-0) == 1 && oriskeleton(x+0,y+1) == 0 && ...
       oriskeleton(x+1,y-1) == 0 && oriskeleton(x+1,y-0) == 0 && oriskeleton(x+1,y+1) == 0 && ...
       oriskeleton(x+2,y-1) == 0 && oriskeleton(x+2,y-0) == 1 && oriskeleton(x+2,y+1) == 1
        display(['plot(',num2str(y),',',num2str(x),',','''','*y','''',')',';']);
        oriskeleton(x+1,y-0) = 1;
    end
    
    if oriskeleton(x+0,y+0) == 1 && oriskeleton(x+0,y+1) == 0 && oriskeleton(x+0,y+2) == 0 && ...
       oriskeleton(x+1,y+0) == 0 && oriskeleton(x+1,y+1) == 0 && oriskeleton(x+1,y+2) == 0 && ...
       oriskeleton(x+2,y+0) == 0 && oriskeleton(x+2,y+1) == 1 && oriskeleton(x+2,y+2) == 0
        display(['plot(',num2str(y),',',num2str(x),',','''','*y','''',')',';']);
        oriskeleton(x+1,y+0) = 1;
    end
    
    if oriskeleton(x-1,y-2) == 0 && oriskeleton(x-1,y-1) == 0 && oriskeleton(x-1,y+0) == 0 && ...
       oriskeleton(x+0,y-2) == 1 && oriskeleton(x+0,y-1) == 0 && oriskeleton(x+0,y+0) == 1 && ...
       oriskeleton(x+1,y-2) == 0 && oriskeleton(x+1,y-1) == 0 && oriskeleton(x+1,y+0) == 0
        display(['plot(',num2str(y),',',num2str(x),',','''','*y','''',')',';']);
        oriskeleton(x+0,y-1) = 1;
    end
    
    if oriskeleton(x-1,y-2) == 0 && oriskeleton(x-1,y-1) == 0 && oriskeleton(x-1,y+0) == 0 && ...
       oriskeleton(x+0,y-2) == 1 && oriskeleton(x+0,y-1) == 0 && oriskeleton(x+0,y+0) == 1 && ...
       oriskeleton(x+1,y-2) == 0 && oriskeleton(x+1,y-1) == 0 && oriskeleton(x+1,y+0) == 1
        display(['plot(',num2str(y),',',num2str(x),',','''','*y','''',')',';']);
        oriskeleton(x+0,y-1) = 1;
    end
    
    if oriskeleton(x-1,y-2) == 0 && oriskeleton(x-1,y-1) == 0 && oriskeleton(x-1,y+0) == 1 && ...
       oriskeleton(x+0,y-2) == 1 && oriskeleton(x+0,y-1) == 0 && oriskeleton(x+0,y+0) == 1 && ...
       oriskeleton(x+1,y-2) == 0 && oriskeleton(x+1,y-1) == 0 && oriskeleton(x+1,y+0) == 0
        display(['plot(',num2str(y),',',num2str(x),',','''','*y','''',')',';']);
        oriskeleton(x+0,y-1) = 1;
    end
end

[~, endpoints, ~] = f_skeleton_branches(oriskeleton);
for i = 1:size(endpoints,1)
    p1x = endpoints(i,1);
    p1y = endpoints(i,2);
    ep1 = [p1x,p1y];
    for j = 1:size(endpoints,1)
        p2x = endpoints(j,1);
        p2y = endpoints(j,2);
        ep2 = [p2x,p2y];
        D  = sqrt(sum((ep1 - ep2) .^ 2));
        if D < 3 && D > 0
            display('there is a gap!');
        end
    end
end

end

