function [ SkeletonBranchs ] = f_get_branches( pointx, pointy, endpoints, junctionpoints, skeleton )
%A skeleton branch is defined as the set of skeleton nodes between two
%junction nodes or between an end node and a junction node in that way
%f_get_branch: this function is used to collect all skeleton branches 
%              emanating from the specified startnode..
%   input:
%         [pointx, pointy]: a startnode for which the emanating parts will be sampled
%         endpoints: ordered all endpoints.
%         junctionpoints: all junction points.
%         skeleton: object skeleton
%   output:
%          SkeletonBranchs: a list of all skeleton branches emanating from the specified start node

%make sure that [pointx, pointy] is one of the junction or end point.
[bool_contain_endpoints] = f_list_contains(pointx, pointy, endpoints);
[bool_contain_junctionpoints] = f_list_contains(pointx, pointy, junctionpoints);

if bool_contain_endpoints == 0 && bool_contain_junctionpoints == 0
    SkeletonBranchs = null;
    return;
end

%structure of skeletonpointlist:
%[1]: x axis of the skeleton
%[2]: y axis of the skeleton
%[3]: is visiteds(1) or not(0)
[skex,skey] = find(skeleton==1);
skeletonpointlist = zeros(size(skex,1),3);
skeletonpointlist(:,1) = skex;
skeletonpointlist(:,2) = skey;

[~, toBeFollowed] = f_all_neighbors(pointx, pointy, skeleton);

%mark start node as visited
[skeletonpointlist] = f_mark_as_visited(pointx, pointy, skeletonpointlist);

% mark all nodes to be followed as visited.
for i = 1:size(toBeFollowed,1)
    [skeletonpointlist] = f_mark_as_visited(toBeFollowed(i,1), toBeFollowed(i,2), skeletonpointlist);
end

%follow each neighbor node of the startnode
parts = {};
for i = 1:size(toBeFollowed,1)
    nodesOnPart = [];
    followedx = toBeFollowed(i,1);
    followedy = toBeFollowed(i,2);
    
    Previousx = pointx;
    Previousy = pointy;
    
    currentx = followedx;
    currenty = followedy;
    
    %checking if all the neighbours of currect points are visited
    allvisited = 0;
    [neisize, neighbors] = f_all_neighbors(currentx, currenty, skeleton);
    if neisize >= 2
        for mmm = 1:neisize
            [myvisited] = f_is_visited(neighbors(mmm,1), neighbors(mmm,2), skeletonpointlist);
            if myvisited == 1 %visited
                allvisited = allvisited + 1;
            end
        end
    end
    % all neighbours are visited
    if allvisited == neisize
        running = false;
    else
        nodesOnPart = f_add_nodesOnPart(followedx, followedy, nodesOnPart);
        running = true;
    end
    
%     mytest = 0;
    while running
        
        %just to avoid the dead loop
%         mytest = mytest + 1;
%         if mytest > 100000
%             running = false;
%         end
        
        %marked current node as visited
        [bool_contain] = f_list_contains(currentx, currenty, junctionpoints);
        if bool_contain == 0
            [skeletonpointlist] = f_mark_as_visited(currentx, currenty, skeletonpointlist);
        end
        
        %check surroundings to see whther they are visited.
        allvisited = 0;
        [neisize, neighbors] = f_all_neighbors(currentx, currenty, skeleton);
        if neisize >= 2
            for mmm = 1:neisize
                [myvisited] = f_is_visited(neighbors(mmm,1), neighbors(mmm,2), skeletonpointlist);
                if myvisited == 1 %visited
                    allvisited = allvisited + 1;
                end
            end
        end
        
        if allvisited == neisize
            break;
        end
        
        %check if the current node is an end node
        [bool_contain] = f_list_contains(currentx, currenty, endpoints);
        if bool_contain == 1 %if current point is an endpoint
            for en = 1:size(endpoints,1)
                if currentx == endpoints(en,1) && currenty == endpoints(en,2)
                    currentx = endpoints(en,1);
                    currenty = endpoints(en,2);
                end
            end
            [part] = f_create_part(pointx,pointy,currentx,currenty,nodesOnPart);
            parts{length(parts)+1} = part;
			running = false;
        else %end if current is EndNode
            % check if the current node is a junction node
            [bool_contain] = f_list_contains(currentx, currenty, junctionpoints);
            if bool_contain == 1
                for jn = 1:size(junctionpoints,1)
                    if currentx == junctionpoints(jn,1) && currenty == junctionpoints(jn,2)
                        currentx = junctionpoints(jn,1);
                        currenty = junctionpoints(jn,2);
                    end
                end
                [part] = f_create_part(pointx,pointy,currentx,currenty,nodesOnPart);
                parts{length(parts)+1} = part;
				running = false;
            else %end this node is a junction node
                %current node is neither junction nor end node.
				%thus, we are not done yet.
				%look for the next node on the path
                [neisize, neighbors] = f_all_neighbors(currentx, currenty, skeleton);
                %this is the usual case for an inner node
                if neisize == 2
                    for n = 1:neisize
                        nx = neighbors(n,1);
                        ny = neighbors(n,2);
                        [bool_visited] = f_is_visited(nx, ny, skeletonpointlist);
                        if bool_visited == 0 %not visited
                            [my_contain] = f_list_contains(currentx, currenty, nodesOnPart);
                            if my_contain == 0
                                nodesOnPart = f_add_nodesOnPart(currentx, currenty, nodesOnPart);
                            end
                            currentx = nx;
                            currenty = ny;
                        end
                    end
                else
                    %this is the case in "NodeAreas"
                    bestFit = [];
                    edgeNeighbors = [];
                    vettexNeighbours = [];
                    for n = 1:neisize
                        nx = neighbors(n,1);
                        ny = neighbors(n,2);
                        [bool_visited] = f_is_visited(nx, ny, skeletonpointlist);
                        if bool_visited == 0 %not visited
                            %priorise connections to the real junction
							%node in this node area.
							%We can't just check for a real junction
							%node here and just assume this as next
							%node as this would lead to problem when
							%we are just leaving a node area
                             [bool_contain] = f_list_contains(nx, ny, junctionpoints);
                             if bool_contain == 1
                                 bestFit(1,1) = nx;
                                 bestFit(1,2) = ny;
                             else
                                 %this is to detect whether all its
                                 %surroundings are visited. if it is, then
                                 %ignor this point, and mark it as visited.
                                 [allmysize, allmyneighbors] = f_all_neighbors(nx, ny, skeleton);
                                 totalvisited = 0;
                                 for jjj = 1:allmysize
                                     [allmyvisited] = f_is_visited(allmyneighbors(jjj,1), allmyneighbors(jjj,2), skeletonpointlist);
                                     totalvisited = totalvisited + allmyvisited;
                                 end
                                 if totalvisited ~= allmysize
                                     [bool_edgeneibhgour] = f_is_edge_neighbor(nx, ny, currentx, currenty);
                                     if bool_edgeneibhgour == 1
                                        edgeNeighbors(size(edgeNeighbors,1)+1,1) = nx;
                                        edgeNeighbors(size(edgeNeighbors,1),2) = ny; 
                                     else
                                        vettexNeighbours(size(vettexNeighbours,1)+1,1) = nx;
                                        vettexNeighbours(size(vettexNeighbours,1),2) = ny; 
                                    end
                                 end
                             end
                             [my_contain] = f_list_contains(currentx, currenty, nodesOnPart);
                             if my_contain == 0
                                 nodesOnPart = f_add_nodesOnPart(currentx, currenty, nodesOnPart);
                             end
							 currentx = nx;
                             currenty = ny;
                             [tempcontain] = f_list_contains(currentx, currenty, junctionpoints);
                             if tempcontain == 1 && size(bestFit,1) > 0
                                 break;
                             end
                        end
                    end
                    %try to find a directly connected neighbor
                    if size(bestFit,1) == 0
                        if size(edgeNeighbors,1) > 0
                            bestFit = edgeNeighbors(1,:);
                        else
                            if size(vettexNeighbours,1) > 0
                                bestFit = vettexNeighbours(1,:);
                            end
                        end
                    end
                    
                    if size(bestFit,1) > 0
                        %if there is a junction node directly
						%connected, always prefer this connection
                        currentx = bestFit(1,1);
                        currenty = bestFit(1,2);
                    end
                end     
            end
        end
    end
end

SkeletonBranchs = parts;

end

