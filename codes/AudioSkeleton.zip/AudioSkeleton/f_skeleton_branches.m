function [SkeletonBranchs, endpoints, junctionpoints] = f_skeleton_branches(skeleton)
%f_skeleton_pathP: this function is used to generate skeleton branches beween 
                   %any enpoints along the shape contour in a clockwise direction.
% input:
%       skeleton: skeleton graph
%       shape: object shape
%       shapecontourpointlist:
% output:
%       SkeletonBranchs: contain all skeleton path, from any pair of
%                           skeleton endpoints and endpoints to junction points.
%       endpoints: stall all endpoints in a clock wise direction along the
%                  shape contour.

% calculation: 
%(1) Both images should be binary images, with black background and white foreground.
%(2) Distance Transform with Euclidean Distance

%first step: get all end notes and junction notes
[endpoints, junctionpoints] = f_point_detection(skeleton);
%endpointnumber = size(endpoints,1);
% imshow(skeleton);
% hold on;
% plot(endpoints(:,2),endpoints(:,1),'+g');
% plot(junctionpoints(:,2),junctionpoints(:,1),'*r');

%second step: 
%sort a list of end nodes by traversing an object's contour in clockwise
%direction and checking for each contour point if there is a skeleton node
%in the 3x3 neighborhood.
% templist = bwboundaries(shapecontour);
% contourpointlist = templist{1};
% [endpoints] = f_sort_endpoints(endpoints, contourpointlist);

%third step:
%sample all parts emanating from each end node
SkeletonBranchs = {};
for i = 1:size(endpoints,1)
    pointx = endpoints(i,1);
    pointy = endpoints(i,2);
    [branch] = f_get_branches(pointx, pointy, endpoints, junctionpoints, skeleton);
    SkeletonBranchs{length(SkeletonBranchs)+1} = branch{1};
end

%sample all parts emanating from each junction node
for i = 1:size(junctionpoints,1)
    pointx = junctionpoints(i,1);
    pointy = junctionpoints(i,2);
    [branchs] = f_get_branches(pointx, pointy, endpoints, junctionpoints, skeleton);
    for j = 1:length(branchs)
        branch = branchs{j};
        SkeletonBranchs{length(SkeletonBranchs)+1} = branch;
    end
end

end

