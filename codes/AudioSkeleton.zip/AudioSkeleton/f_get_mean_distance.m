function [ meandistance ] = f_get_mean_distance( ex, ey, pointlist )
%f_get_mean_distance: this function is used to generate mean distance from
%                     point(ex,ey) to all other points in the pointlist
%   input:
%         ex: x axis of one point
%         ey: y axis of one point
%         pointlist: all point list
%   output:
%         meandistance: the mean distance
p1 = [ex,ey];
mydis = 0;
mylength = size(pointlist,1);
for i = 1:mylength
    px = pointlist(i,1);
    py = pointlist(i,2);
    p2 = [px,py];
    mydis = mydis + sqrt(sum((p1 - p2) .^ 2));
    %mydis = mydis + log((sqrt(sum((p1 - p2).^2))) + 1);
end

meandistance = mydis/mylength;


end

