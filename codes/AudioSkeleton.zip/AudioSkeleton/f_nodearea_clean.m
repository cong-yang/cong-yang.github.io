function [ pointx, pointy ] = f_nodearea_clean( NodeArea )
%f_nodearea_clean: this function is used to clean a node area. The junction 
%                  node with highest number of adjacencies is priorised.
%   input:
%         NodeArea: node area. A list of some neighbourhood points.
%   output:
%         [pointx, pointy]: selected point with hightest number of
%         adjacencies.

areasize = size(NodeArea,1);

if areasize == 1
    pointx = NodeArea(1,1);
    pointy = NodeArea(1,2);
    return;
end

%The first dimension is the index in the NodeArea list.
%[1] = number of edge neighborhoods
%[2] = number of vertex neighborhoods
adjacencies = zeros(areasize,2);

for i = 1:areasize
    x1 = NodeArea(i,1);
    y1 = NodeArea(i,2);
    for j = 1:areasize
        x2 = NodeArea(j,1);
        y2 = NodeArea(j,2);
        if x1 ~= x2 || y1 ~= y2
            [bool_edgeneibhgour] = f_is_edge_neighbor(x1, y1, x2, y2);
            [bool_vertexneibhgour] = f_is_vertex_neighbour(x1, y1, x2, y2);
            if bool_edgeneibhgour == 1
                adjacencies(i,1) = adjacencies(i,1) + 1;
            else
                %no edge neighbor,
			    %check whether this is a vertex neighbor
                if bool_vertexneibhgour == 1
                    adjacencies(i,2) = adjacencies(i,2) + 1;
                end
            end
        end
    end
end

%find the junction node with the most edge neighbors
equal = false;
maxEdgeNeighbors = 0;
tempindex = 2;
for index = 1:size(adjacencies,1)
    if adjacencies(index,1) > maxEdgeNeighbors
        equal = false;
        maxEdgeNeighbors = adjacencies(index,1);
        maxEdgeNeighborsIndices = [];
		maxEdgeNeighborsIndices(1,1) = index;
        tempindex = 2;
    else
        if adjacencies(index,1) == maxEdgeNeighbors
            equal = true;
            if index == 1
                maxEdgeNeighborsIndices(1,1) = index;
            else
                maxEdgeNeighborsIndices(tempindex,1) = index;
                tempindex = tempindex + 1;
            end
        end
    end
end

%if there were multiple junction nodes with the same amount of edge
%neighbors, the one with most vertex neighbors will win.
if equal
    myequal = false;
    maxVertexNeighbors = 0;
    maxVertexNeighborsIndices = [];
    myindex = 2;
    for index = 1:size(maxEdgeNeighborsIndices,1)
        tempindex = maxEdgeNeighborsIndices(index,1);
        if adjacencies(tempindex,2) > maxVertexNeighbors
            myequal = false;
            maxVertexNeighbors = adjacencies(tempindex,2);
            maxVertexNeighborsIndices = [];
            maxVertexNeighborsIndices(1,1) = tempindex;
            myindex = 2;
        else
            if adjacencies(tempindex,2) == maxVertexNeighbors
                myequal = true;
                if index == 1
                    maxVertexNeighborsIndices(1,1) = tempindex;
                else
                    maxVertexNeighborsIndices(myindex,1) = tempindex;
                    myindex = myindex + 1;
                end
            end
        end
    end
    
    if myequal %multi equal edge, multi equal vertex, choose one random node
        choseindex = maxVertexNeighborsIndices(1,1);
        pointx = NodeArea(choseindex,1);
        pointy = NodeArea(choseindex,2);
    else
        %multi equal edge, one max vertex, choose one max vertex
        if size(maxVertexNeighborsIndices,1) > 0
            choseindex = maxVertexNeighborsIndices(1,1);
            pointx = NodeArea(choseindex,1);
            pointy = NodeArea(choseindex,2);
        else
            pointx = NodeArea(1,1);
            pointy = NodeArea(1,2);
        end
    end
else
    %one max edge
    choseindex = maxEdgeNeighborsIndices(1,1);
    pointx = NodeArea(choseindex,1);
    pointy = NodeArea(choseindex,2);
end

end

