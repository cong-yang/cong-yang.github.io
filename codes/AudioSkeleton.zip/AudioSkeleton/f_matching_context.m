function [ OrderedMatchingResults ] = f_matching_context( object1, alldata, featuredir )
%f_matching_context: do the matching with context algorithm and out out the
%                    final ranked result.
%   input:
%         object1: the query object features
%         alldata: all obejct name list
%         featuredir: the path to all features
%   output: 
%          OrderedMatchingResults: ordered matching results

N = size(alldata,1);
for indexob = 1:N
    object = alldata(indexob,1).name;
    tempname =  regexp(object,'.mat','split');
    objectname2 = tempname{1};
    display(['---->',objectname2]);
    
    load([featuredir,object]);
    object2 = features;
    clear features;
    
    [CostMatrix] = f_get_similarity_matrix(object1, object2);
    [NewCostMatrix] = f_Adding_Dummy(CostMatrix);
    %NewCostMatrix = -1*NewCostMatrix;
    [correspoinding, Similarity] = f_Hungarian_Corresponding(NewCostMatrix);
    Similarity = 1-Similarity;
    MatchingResult{indexob} = {objectname2, Similarity, correspoinding};
end

[OrderedMatchingResults] = f_result_ranking(MatchingResult,N);


end

