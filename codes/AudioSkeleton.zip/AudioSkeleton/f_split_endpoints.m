function [ endpointsup, endpointsunder ] = f_split_endpoints( endpoints, xasix )
%f_split_endpoints: this function is used to split the endpoints into two
%groups based on whether they are above or below the xasix.
%   input:
%         endpoints: all endpoints
%         xasix: the middle line of image
%   output:
%         endpointsup: the upper endpoints
%         endpointsdown: the under endpoints

myindexup = 1;
myindexdown = 1;
for i = 1:size(endpoints,1)
    myx = endpoints(i,1);
    if myx <= xasix %upper
        endpointsup(myindexup,1) = endpoints(i,1);
        endpointsup(myindexup,2) = endpoints(i,2);
        myindexup = myindexup + 1;
    else %lower
        endpointsunder(myindexdown,1) = endpoints(i,1);
        endpointsunder(myindexdown,2) = endpoints(i,2);
        myindexdown = myindexdown + 1;
    end
end



end

