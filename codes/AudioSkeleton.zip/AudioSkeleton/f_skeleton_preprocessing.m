function [ oriskeleton ] = f_skeleton_preprocessing( oriskeleton)
%f_skeleton_preprocessing: this function is used to remove some one-pixel
%                          branches
%   input:
%          oriskeleton: original skeleton
%   output:
%          oriskeleton: the processed skeleton

[~, junctionpoints] = f_point_detection(oriskeleton);
for i = 1:size(junctionpoints,1)
    jx = junctionpoints(i,1);
    jy = junctionpoints(i,2);
    
    % 1000
    % 0110
    % 0100
    if oriskeleton(jx-1,jy-1) == 1 && oriskeleton(jx-1,jy) == 0 && oriskeleton(jx-1,jy+1) == 0 && oriskeleton(jx-1,jy+2) == 0 && ...
       oriskeleton(jx,jy-1) == 0 && oriskeleton(jx,jy+1) == 1 && oriskeleton(jx,jy+2) == 0 && ...
       oriskeleton(jx+1,jy-1) == 0 && oriskeleton(jx+1,jy) == 1 && oriskeleton(jx+1,jy+1) == 0 && oriskeleton(jx+1,jy+2) == 0
        display(['plot(',num2str(jy),',',num2str(jx),',','''','*r','''',')',';']);
        oriskeleton(jx,jy+1) = 0;
    end
    
    %10000
    % 1000
    % 1110
    % 0100
    if oriskeleton(jx-2,jy-2) == 1 && ...
       oriskeleton(jx-1,jy-1) == 0 && oriskeleton(jx-1,jy) == 0 && oriskeleton(jx-1,jy+1) == 0 && oriskeleton(jx-1,jy+2) == 0 && ...
       oriskeleton(jx,jy-1) == 1 && oriskeleton(jx,jy+1) == 1 && oriskeleton(jx,jy+2) == 0 && ...
       oriskeleton(jx+1,jy-1) == 0 && oriskeleton(jx+1,jy) == 1 && oriskeleton(jx+1,jy+1) == 0 && oriskeleton(jx+1,jy+2) == 0
            display(['plot(',num2str(jy),',',num2str(jx),',','''','*r','''',')',';']);
            oriskeleton(jx,jy) = 0;
            oriskeleton(jx,jy+1) = 0;
    end
    
    %10000
    %10000
    %01110
    %01000
    if oriskeleton(jx-2,jy-1) == 1 && oriskeleton(jx-2,jy) == 0 && oriskeleton(jx-2,jy+1) == 0 && oriskeleton(jx-2,jy+2) == 0 && oriskeleton(jx-2,jy+3) == 0 && ...
       oriskeleton(jx-1,jy-1) == 1 && oriskeleton(jx-1,jy) == 0 && oriskeleton(jx-1,jy+1) == 0 && oriskeleton(jx-1,jy+2) == 0 && oriskeleton(jx-1,jy+3) == 0 && ...
       oriskeleton(jx,jy-1) == 0 && oriskeleton(jx,jy+1) == 1 && oriskeleton(jx,jy+2) == 1 && oriskeleton(jx,jy+3) == 0 && ...
       oriskeleton(jx+1,jy-1) == 0 && oriskeleton(jx+1,jy) == 1 && oriskeleton(jx+1,jy+1) == 0 && oriskeleton(jx+1,jy+2) == 0 && oriskeleton(jx+1,jy+3) == 0
            display(['plot(',num2str(jy),',',num2str(jx),',','''','*r','''',')',';']);
            oriskeleton(jx,jy+1) = 0;
            oriskeleton(jx,jy+2) = 0;
    end
    
    %01000
    %01110
    %10000
    %10000
    if oriskeleton(jx-2,jy) == 1 && ...
       oriskeleton(jx-1,jy-1) == 0 && oriskeleton(jx-1,jy) == 1 && oriskeleton(jx-1,jy+1) == 0 && oriskeleton(jx-1,jy+2) == 0 && oriskeleton(jx-1,jy+3) == 0 && ...
       oriskeleton(jx,jy-1) == 0 && oriskeleton(jx,jy+1) == 1 && oriskeleton(jx,jy+2) == 1 && oriskeleton(jx,jy+3) == 0 && ...
       oriskeleton(jx+1,jy-1) == 1 && oriskeleton(jx+1,jy) == 0 && oriskeleton(jx+1,jy+1) == 0 && oriskeleton(jx+1,jy+2) == 0 && oriskeleton(jx+1,jy+3) == 0 && ...
       oriskeleton(jx+2,jy-1) == 1 && oriskeleton(jx+2,jy) == 0 && oriskeleton(jx+2,jy+1) == 0 && oriskeleton(jx+2,jy+2) == 0 && oriskeleton(jx+2,jy+3) == 0
            display(['plot(',num2str(jy),',',num2str(jx),',','''','*r','''',')',';']);
            oriskeleton(jx,jy+1) = 0;
            oriskeleton(jx,jy+2) = 0;
    end
    
    %10000
    %01110
    %01000
    %01000
    if oriskeleton(jx-1,jy-1) == 1 && oriskeleton(jx-1,jy) == 0 && oriskeleton(jx-1,jy+1) == 0 && oriskeleton(jx-1,jy+2) == 0 && oriskeleton(jx-1,jy+3) == 0 && ...
       oriskeleton(jx,jy-1) == 0 && oriskeleton(jx,jy+1) == 1 && oriskeleton(jx,jy+2) == 1 && oriskeleton(jx,jy+3) == 0 && ...
       oriskeleton(jx+1,jy-1) == 0 && oriskeleton(jx+1,jy) == 1 && oriskeleton(jx+1,jy+1) == 0 && oriskeleton(jx+1,jy+2) == 0 && oriskeleton(jx+1,jy+3) == 0 && ...
       oriskeleton(jx+2,jy-1) == 0 && oriskeleton(jx+2,jy) == 1 && oriskeleton(jx+2,jy+1) == 0 && oriskeleton(jx+2,jy+2) == 0 && oriskeleton(jx+2,jy+3) == 0
            display(['plot(',num2str(jy),',',num2str(jx),',','''','*r','''',')',';']);
            oriskeleton(jx,jy+1) = 0;
            oriskeleton(jx,jy+2) = 0;
    end
    
    %00100
    %00100
    %00100
    %00110
    %01000
    %10000
    if oriskeleton(jx-2,jy-2) == 0 && oriskeleton(jx-2,jy-1) == 0 && oriskeleton(jx-2,jy) == 1 && oriskeleton(jx-2,jy+1) == 0 && oriskeleton(jx-2,jy+2) == 0 && ...
       oriskeleton(jx-1,jy-2) == 0 && oriskeleton(jx-1,jy-1) == 0 && oriskeleton(jx-1,jy) == 1 && oriskeleton(jx-1,jy+1) == 0 && oriskeleton(jx-1,jy+2) == 0 && ...
       oriskeleton(jx-0,jy-2) == 0 && oriskeleton(jx-0,jy-1) == 0 && oriskeleton(jx-0,jy) == 1 && oriskeleton(jx-0,jy+1) == 0 && oriskeleton(jx-0,jy+2) == 0 && ...
       oriskeleton(jx+1,jy-2) == 0 && oriskeleton(jx+1,jy-1) == 0 && oriskeleton(jx+1,jy) == 1 && oriskeleton(jx+1,jy+1) == 1 && oriskeleton(jx+1,jy+2) == 0 && ...
       oriskeleton(jx+2,jy-2) == 0 && oriskeleton(jx+2,jy-1) == 1 && oriskeleton(jx+2,jy) == 0 && oriskeleton(jx+2,jy+1) == 0 && oriskeleton(jx+2,jy+2) == 0 && ...
       oriskeleton(jx+3,jy-2) == 1 && oriskeleton(jx+3,jy-1) == 0 && oriskeleton(jx+3,jy) == 0 && oriskeleton(jx+3,jy+1) == 0 && oriskeleton(jx+3,jy+2) == 0
            display(['plot(',num2str(jy),',',num2str(jx),',','''','*r','''',')',';']);
            oriskeleton(jx+1,jy+1) = 0;
    end
    
    %0001000
    %0011100
    %0100010
    %0100000
    %0100000
    %0000000
    if oriskeleton(jx-1,jy-3) == 0 && oriskeleton(jx-1,jy-2) == 0 && oriskeleton(jx-1,jy-1) == 0 && oriskeleton(jx-1,jy+0) == 1 && oriskeleton(jx-1,jy+1) == 0 && oriskeleton(jx-1,jy+2) == 0 && oriskeleton(jx-2,jy+3) == 0 && ...
       oriskeleton(jx+0,jy-3) == 0 && oriskeleton(jx-0,jy-2) == 0 && oriskeleton(jx-0,jy-1) == 1 && oriskeleton(jx-0,jy+0) == 1 && oriskeleton(jx-0,jy+1) == 1 && oriskeleton(jx-0,jy+2) == 0 && oriskeleton(jx-1,jy+3) == 0 && ...
       oriskeleton(jx+1,jy-3) == 0 && oriskeleton(jx+1,jy-2) == 1 && oriskeleton(jx+1,jy-1) == 0 && oriskeleton(jx+1,jy+0) == 0 && oriskeleton(jx+1,jy+1) == 0 && oriskeleton(jx+1,jy+2) == 1 && oriskeleton(jx-0,jy+3) == 0 && ...
       oriskeleton(jx+2,jy-3) == 0 && oriskeleton(jx+2,jy-2) == 1 && oriskeleton(jx+2,jy-1) == 0 && oriskeleton(jx+2,jy+0) == 0 && oriskeleton(jx+2,jy+1) == 0 && oriskeleton(jx+2,jy+2) == 0 && oriskeleton(jx+1,jy+3) == 0 && ...
       oriskeleton(jx+3,jy-3) == 0 && oriskeleton(jx+3,jy-2) == 1 && oriskeleton(jx+3,jy-1) == 0 && oriskeleton(jx+3,jy+0) == 0 && oriskeleton(jx+3,jy+1) == 0 && oriskeleton(jx+3,jy+2) == 0 && oriskeleton(jx+2,jy+3) == 0 && ...
       oriskeleton(jx+4,jy-3) == 0 && oriskeleton(jx+4,jy-2) == 0 && oriskeleton(jx+4,jy-1) == 0 && oriskeleton(jx+4,jy+0) == 0 && oriskeleton(jx+4,jy+1) == 0 && oriskeleton(jx+4,jy+2) == 0 && oriskeleton(jx+3,jy+3) == 0
            display(['plot(',num2str(jy),',',num2str(jx),',','''','*r','''',')',';']);
            oriskeleton(jx,jy+1) = 0;
            oriskeleton(jx,jy) = 0;
            oriskeleton(jx+1,jy+2) = 0;
    end
    
    %0001000
    %0011100
    %0100000
    %0100000
    %0000000
    %0000000
    if oriskeleton(jx-1,jy-3) == 0 && oriskeleton(jx-1,jy-2) == 0 && oriskeleton(jx-1,jy-1) == 0 && oriskeleton(jx-1,jy+0) == 1 && oriskeleton(jx-1,jy+1) == 0 && oriskeleton(jx-1,jy+2) == 0 && oriskeleton(jx-2,jy+3) == 0 && ...
       oriskeleton(jx+0,jy-3) == 0 && oriskeleton(jx-0,jy-2) == 0 && oriskeleton(jx-0,jy-1) == 1 && oriskeleton(jx-0,jy+0) == 1 && oriskeleton(jx-0,jy+1) == 1 && oriskeleton(jx-0,jy+2) == 0 && oriskeleton(jx-1,jy+3) == 0 && ...
       oriskeleton(jx+1,jy-3) == 0 && oriskeleton(jx+1,jy-2) == 1 && oriskeleton(jx+1,jy-1) == 0 && oriskeleton(jx+1,jy+0) == 0 && oriskeleton(jx+1,jy+1) == 0 && oriskeleton(jx+1,jy+2) == 0 && oriskeleton(jx-0,jy+3) == 0 && ...
       oriskeleton(jx+2,jy-3) == 0 && oriskeleton(jx+2,jy-2) == 1 && oriskeleton(jx+2,jy-1) == 0 && oriskeleton(jx+2,jy+0) == 0 && oriskeleton(jx+2,jy+1) == 0 && oriskeleton(jx+2,jy+2) == 0 && oriskeleton(jx+1,jy+3) == 0 && ...
       oriskeleton(jx+3,jy-3) == 0 && oriskeleton(jx+3,jy-2) == 0 && oriskeleton(jx+3,jy-1) == 0 && oriskeleton(jx+3,jy+0) == 0 && oriskeleton(jx+3,jy+1) == 0 && oriskeleton(jx+3,jy+2) == 0 && oriskeleton(jx+2,jy+3) == 0 && ...
       oriskeleton(jx+4,jy-3) == 0 && oriskeleton(jx+4,jy-2) == 0 && oriskeleton(jx+4,jy-1) == 0 && oriskeleton(jx+4,jy+0) == 0 && oriskeleton(jx+4,jy+1) == 0 && oriskeleton(jx+4,jy+2) == 0 && oriskeleton(jx+3,jy+3) == 0
            display(['plot(',num2str(jy),',',num2str(jx),',','''','*r','''',')',';']);
            oriskeleton(jx,jy) = 0;
            oriskeleton(jx,jy+1) = 0;
    end
    
    %00100
    %00100
    %01110
    %10000
    %10000
    if oriskeleton(jx-2,jy-2) == 0 && oriskeleton(jx-2,jy-1) == 0 && oriskeleton(jx-2,jy+0) == 1 && oriskeleton(jx-2,jy+1) == 0 && oriskeleton(jx-2,jy+2) == 0 && ...
       oriskeleton(jx-1,jy-2) == 0 && oriskeleton(jx-1,jy-1) == 0 && oriskeleton(jx-1,jy+0) == 1 && oriskeleton(jx-1,jy+1) == 0 && oriskeleton(jx-1,jy+2) == 0 && ...
       oriskeleton(jx+0,jy-2) == 0 && oriskeleton(jx+0,jy-1) == 1 && oriskeleton(jx+0,jy+0) == 1 && oriskeleton(jx+0,jy+1) == 1 && oriskeleton(jx+0,jy+2) == 0 && ...
       oriskeleton(jx+1,jy-2) == 1 && oriskeleton(jx+1,jy-1) == 0 && oriskeleton(jx+1,jy+0) == 0 && oriskeleton(jx+1,jy+1) == 0 && oriskeleton(jx+1,jy+2) == 0 && ...
       oriskeleton(jx+2,jy-2) == 1 && oriskeleton(jx+2,jy-1) == 0 && oriskeleton(jx+2,jy+0) == 0 && oriskeleton(jx+2,jy+1) == 0 && oriskeleton(jx+2,jy+2) == 0
            display(['plot(',num2str(jy),',',num2str(jx),',','''','*r','''',')',';']);
            oriskeleton(jx,jy) = 0;
            oriskeleton(jx,jy+1) = 0;
    end
    
    %0100
    %0100
    %0111
    %0100
    %0000
    if oriskeleton(jx-2,jy-1) == 0 && oriskeleton(jx-2,jy+0) == 1 && oriskeleton(jx-2,jy+1) == 0 && oriskeleton(jx-2,jy+2) == 0 && ...
       oriskeleton(jx-1,jy-1) == 0 && oriskeleton(jx-1,jy+0) == 1 && oriskeleton(jx-1,jy+1) == 0 && oriskeleton(jx-1,jy+2) == 0 && ...
       oriskeleton(jx+0,jy-1) == 0 && oriskeleton(jx+0,jy+0) == 1 && oriskeleton(jx+0,jy+1) == 1 && oriskeleton(jx+0,jy+2) == 1 && ...
       oriskeleton(jx+1,jy-1) == 0 && oriskeleton(jx+1,jy+0) == 1 && oriskeleton(jx+1,jy+1) == 0 && oriskeleton(jx+1,jy+2) == 0 && ...
       oriskeleton(jx+2,jy-1) == 0 && oriskeleton(jx+2,jy+0) == 0 && oriskeleton(jx+2,jy+1) == 0 && oriskeleton(jx+2,jy+2) == 0
            display(['plot(',num2str(jy),',',num2str(jx),',','''','*r','''',')',';']);
            oriskeleton(jx,jy) = 0;
            oriskeleton(jx+1,jy) = 0;
    end
    
    %0000
    %0100
    %0111
    %0100
    %0100
    if oriskeleton(jx-2,jy-1) == 0 && oriskeleton(jx-2,jy+0) == 0 && oriskeleton(jx-2,jy+1) == 0 && oriskeleton(jx-2,jy+2) == 0 && ...
       oriskeleton(jx-1,jy-1) == 0 && oriskeleton(jx-1,jy+0) == 1 && oriskeleton(jx-1,jy+1) == 0 && oriskeleton(jx-1,jy+2) == 0 && ...
       oriskeleton(jx+0,jy-1) == 0 && oriskeleton(jx+0,jy+0) == 1 && oriskeleton(jx+0,jy+1) == 1 && oriskeleton(jx+0,jy+2) == 1 && ...
       oriskeleton(jx+1,jy-1) == 0 && oriskeleton(jx+1,jy+0) == 1 && oriskeleton(jx+1,jy+1) == 0 && oriskeleton(jx+1,jy+2) == 0 && ...
       oriskeleton(jx+2,jy-1) == 0 && oriskeleton(jx+2,jy+0) == 1 && oriskeleton(jx+2,jy+1) == 0 && oriskeleton(jx+2,jy+2) == 0
            display(['plot(',num2str(jy),',',num2str(jx),',','''','*r','''',')',';']);
            oriskeleton(jx-1,jy) = 0;
            oriskeleton(jx,jy) = 0;
    end
    
end

end

