function [ oriskeleton, endpoints, junctionstay ] = f_skeleton_pruning( oriskeleton )
%f_skeleton_pruning: this function is used to prun skeleton based on the 
%                    pruning_weight.
%input:
%      oriskeleton: the original skeleton
%      pruning_weight: the weight for skeleton pruning.
%output:
%      prunedskeleton: the pruned skeleton
%      endpoints: the point list of endpoints
%      junctionpoints: the point list of junction points

para_area = 25;

%skeleton preprocessing
[oriskeleton] = f_skeleton_preprocessing(oriskeleton);

%first step: detect endpoings, junction points and skeleton branches
[SkeletonBranchs, endpoints, junctionpoints] = f_skeleton_branches(oriskeleton);

%second step: all pathes between skeleton endpoints and junction points
%[pathes] = f_skeleton_path(SkeletonBranchs, endpoints, junctionpoints);

%third step: detect the region where most skeleton junction points locates
[junctionstay, junctionremove] = f_get_middle_junctions(junctionpoints, para_area);
% imshow(oriskeleton);
% hold on;
%fourth step: try to remove the small branches with junctionremove
for i = 1:size(junctionremove,1)
    jx = junctionremove(i,1);
    jy = junctionremove(i,2);
    [juncbranches] = f_get_junc_branches(jx, jy, junctionstay, SkeletonBranchs);
    numbranch = length(juncbranches);
    %if there are only one junction branches, just remove it
    if numbranch == 1
        mybranch = juncbranches{1};
        [oriskeleton, endpoints] = f_update_skeleton(oriskeleton, mybranch, endpoints);
        %plot(mybranch(:,2),mybranch(:,1),'*b');
    end
    %if there are more than one junction branches, keep the longest one,
    %and remove the rest
    if numbranch > 1
        [toberemoved, ~] = f_tobe_removed(juncbranches);
        for j = 1:length(toberemoved)
            mybranch = toberemoved{j};
            [oriskeleton, endpoints] = f_update_skeleton(oriskeleton, mybranch, endpoints);
            %plot(mybranch(:,2),mybranch(:,1),'*b');
        end
    end
end


end

