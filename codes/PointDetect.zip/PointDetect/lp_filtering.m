function v_smoothed_signal = lp_filtering( v_signal, p )
%LP_FILTERING Summary of this function goes here
%   Detailed explanation goes here

range = p.para_range;
sigma = p.para_sigma;
power = p.para_filterpower;
times = p.para_filtertimes;

Xf = v_signal';
Xf = fft(Xf);
Xf = fftshift(Xf);

% generate gaussian filter function
Nf = numel(v_signal);
% xAxisf = linspace(-5,5,Nf);
xAxisf = linspace(-range,range,Nf);
% widthfilter = 0.1;
% filterpower = 1;
% filter = exp(-(xAxisf./widthfilter).^filterpower);
filter = exp(-(xAxisf./sigma).^power);

% filter
% filtertimes = 1;
Xf = Xf .* filter.^times;

% plot
% Xfa = abs(Xf); plot(Xfa);

% iFFt
Xfs = ifftshift(Xf);
Xif = ifft(Xfs);
v_smoothed_signal = abs(Xif);

end

