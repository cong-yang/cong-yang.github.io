function [ rotList ] = compute_rotation( T, pois )


    [gy,gx] = gradient(T);
    rotList = zeros(size(pois,1),1);

    for idx = 1:size(pois,1)

        grads = zeros(4,2);
        cnt = 1;
        for x = max(pois(idx,2)-1,1):min(pois(idx,2)+1,size(gx,2))
           for y = max(pois(idx,1)-1,1):min(pois(idx,1)+1,size(gy,1))

               if y == pois(idx,1) || x == pois(idx,2)
                   continue;
               end

               grads(cnt,1) = gy(y);
               grads(cnt,2) = gx(x);

               cnt = cnt + 1;
           end
        end

        tmpugx = grads(1,:) + (abs(norm(grads(1,:)-grads(3,:)))/2);
        tmplgx = grads(2,:) + (abs(norm(grads(2,:)-grads(4,:)))/2);
        fgrad = tmpugx + abs(norm(tmpugx-tmplgx)/2);

        rotList(idx) = atan2(fgrad(2), fgrad(1)) + pi/2;

    end


end

%rotList = atan2(gy(pois(:,1)), gx(pois(:,2))) + pi/2;