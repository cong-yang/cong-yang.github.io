clear all;
close all;

OriShape = imread('butterfly08.png');
OriShape = imresize(OriShape,0.5);
[ShapeContour, ShapeContourPointList, InterestPointLists, ContourSegment, TangentValue] = f_Contour_Segement(OriShape,'all');

myshapecontour = 1 - ShapeContour;
imshow(myshapecontour);

hold on;
for i = 1:size(InterestPointLists,1)
    plot(InterestPointLists(i,2),InterestPointLists(i,1),'*r');
end
hold off;