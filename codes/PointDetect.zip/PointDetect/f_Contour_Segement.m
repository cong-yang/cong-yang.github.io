function [contour_img, contour, poi_list, ContourSegments, rot_list] = f_Contour_Segement(OriShape, para_type)
    %version3.3 by christian   
    ContourSegments = '';
    DEBUG                   = 'off';
    SHOW_RESULT             = 'off';
    PAUSE                   = 'off';
    VERBOSE                 = 'off';
    SAVE_RESULT             = 'off';
    SAVE_SEGS               = 'on';
    SAVE_POIS               = 'off';
    SAVE_ROTANG             = 'on';
    %% set up directories
    INPUT                   = 'KIMIA216/';
    OUTPUT                  = 'test/'; % root directory
    POIDIR                  = 'poi/';
    CONSEGSDIR              = 'contour_segs/';
    FIGDIR                  = 'figs/';
    
    %% image reading
    stepwidth               = 4;
    
    %% image preprocessing parameters
    preprocessing           = 'on';
    imgpara_expand          = 2;
    imgpara_shrink          = 1; %1/imgpara_expand;

    %% smooth contour
    smoothing               = 'on';
    para_smooth             = 6;

    %% seed point detection
    para_dilatetimes        = 10;
    cog2maxdist             = 25;
    backthres               = @(x) max(x(x>1)) - 2*std(x(x>1)); % @(x) mean(x(x>1)) + std(x(x>1)); %@(x) mean(x(x>mean(x(x>1)))) + std(x(x>mean(x(x>1))));
    usesecond               = false;
    usecross                = true;
    
    %% signal processing
    prefiltering            = 'off';
    para_size               = 30;
    % create gaussian filter
    single.para_range       = 30; % 3 => [-3,3]
    single.para_sigma       = 1;
    single.para_filterpower = 2;
    single.para_filtertimes = 1;
    
    multi.para_range       = 30; % 3 => [-3,3]
    multi.para_sigma       = 0.5;
    multi.para_filterpower = 2;
    multi.para_filtertimes = 1;
    
    % single seed point
    para_lpf_single         = single;
    % multi seed points
    para_lpf_multi          = single; %multi;
    
    %% signal peak detection
    %para_type = 'all'; % 'max', 'min', 'all'
    
    %% poi post processing
    % removal of point of interest which are to close to each other
    postprocessing          = 'on';
    para_p2p_mindist        = @(x) length(x) * 0.08; % 30;
    para_remove_criteria    = 'addmidpt';
    
    %% start procedure
    % don't create output directories
    %mkdir(OUTPUT);
    %mkdir([OUTPUT, POIDIR]);
    %mkdir([OUTPUT, CONSEGSDIR]);
    %mkdir([OUTPUT, FIGDIR]);
    
    % load directory
    %c = dir(fullfile([INPUT, '*.png']));
    
    % loop not needed anymore -> just look at the input image: OriShape
    %for i = 1:length(c) % [73:84,121:132] %
        try
            
%             i = 76, DEBUG = 'on', close all
            
            %% extract shape contour
            %fprintf('%s\n', c(i).name)

            %%%%%%%%
            %%%%%%%% load image
            %%%%%%%%    
            
            %%%%%sc('Perform Image Preprocessing...', VERBOSE);
            %img = imread([INPUT, c(i).name]);
            img = im2bw(OriShape);
            %img = OriShape;
            if strcmp(preprocessing,'on')
                img = imresize(img, imgpara_expand, 'nearest');
                img = bwmorph(bwmorph(img,'erode'), 'dilate');
                img = imresize(img, imgpara_shrink, 'nearest');
            end
            sc('DONE', VERBOSE, true);

            %%%%%%%%
            %%%%%%%% extract contour
            %%%%%%%%
            sc('Contour Extracting and Smoothing...', VERBOSE);
            contour_img = extractContour(img);
            [contour_y, contour_x] = ind2sub(size(contour_img), find(contour_img > 0));
            contour = bwtraceboundary(contour_img, [contour_y(1), contour_x(1)], 'W', 8);

            %%%%%%%%
            %%%%%%%% smoothing 
            %%%%%%%%
            if strcmp(smoothing,'on')
                [ps,~] = dpsimplify(contour, para_smooth);

                %% convert simplified contour polygon back to pixel image - easier to compute point to contour distances
                x = [];
                y = [];   
                for li = 1:size(ps,1)-1

                    [x1, y1] = bresenham(ps(li,1),ps(li,2),ps(li+1,1),ps(li+1,2));
                    x = [x1;x];
                    y = [y1;y];

                end

                x = x-min(x)+1;
                y = y-min(y)+1;
                simp_img = zeros(max(x),max(y));
                idxs = sub2ind([max(x),max(y)],x,y);
                simp_img(idxs) = 1;

                %%% update information
                img = imfill(simp_img);
                contour_img = extractContour(img);
                [contour_y, contour_x] = ind2sub(size(contour_img), find(contour_img > 0));
                contour = bwtraceboundary(contour_img, [contour_y(1), contour_x(1)], 'W', 8);
            end
            sc('DONE', VERBOSE, true);

            %%%%%%%%
            %%%%%%%% estimate center of gravity (cog)
            %%%%%%%%
            sc('Computing Seed Points...', VERBOSE);
            img_props = regionprops(img,'Centroid');
            cog = fliplr(img_props.Centroid)';

            % Fast Marching Method to detect most proper seed points 
            velocity = ones(size(img));
            [y,x] = ind2sub(size(img),find(contour_img > 0));
            T = msfm2d(velocity, [y,x]', usesecond, usecross);
            TTangle = T; % hold original information for further process
            T = T .* img; % consider only the interior of the object

%             src = FastPeakFind(T,backthres(T),1,0,2);
%             x = src(1:2:end);
%             y = src(2:2:end);
%             src = [y,x]';

            src = [];
            srcidx = [];
            
            [lbs,nlbs] = bwlabel(bwmorph(T>backthres(T),'dilate',para_dilatetimes));
            
            stats = regionprops(lbs,T,'WeightedCentroid');
            wc = [stats.WeightedCentroid];
            x = wc(1:2:end);
            y = wc(2:2:end);
            srcidx = sub2ind(size(T),round(y),round(x));
            it = 1:nlbs;
            
            while ~isempty(it)
                for li = it; 
    %                 idxset = find(lbs == li);
                    T1 = msfm2d(velocity, [y(li),x(li)]', usesecond, usecross);
                    T2 = T1.*T;
                    [slbs,snlbs] = bwlabel(bwmorph(T2>backthres(T2),'dilate',para_dilatetimes));

                    for sli = 1:snlbs

                        sidxset = find(slbs == sli);
                        toAdd = true;
                        for ss = 1:length(srcidx)

                            idxset = find(lbs == ss);
                            if any(ismember(idxset,sidxset))
                                toAdd = false;
                                break;
                            end

                        end

                        if toAdd
                            stats = regionprops(slbs == sli,T2,'WeightedCentroid');
                            wc = [stats.WeightedCentroid];
                            x1 = wc(1:2:end);
                            y1 = wc(2:2:end);
                            tmpidx = sub2ind(size(T),round(y1),round(x1));
                            srcidx = unique([srcidx, tmpidx],'stable');
                            lbs(slbs == sli) = length(srcidx);
                        end
                    end
                end
                
                it = (it(end)+1):length(srcidx);
                [y,x] = ind2sub(size(T), srcidx);
                src = [y;x];
                
            end
            
            [y,x] = ind2sub(size(T), srcidx);
            src = [y;x];

%                [~, ml] = max(T(:));
%                [y,x] = ind2sub(size(T), ml);
% %                T = T2 .* area2check;
%                [lbs,~] = bwlabel(T>backthres(T));
%                [~, ml] = max(T(:));
%                [y,x] = ind2sub(size(T), ml);
%                area2check(lbs == lbs(y,x)) = 0;
%                area2check = bwmorph(area2check,'dilate');
%                src = [src, [y,x]'];
%                T1 = msfm2d(velocity, [y,x]', usesecond, usecross);
%                T = T1.*T2;
%                figure, imagesc(T);
            
            if strcmp(DEBUG,'on')
                figure, imagesc(T);
                hold on, plot(x,y,'g+')
            end
            sc('DONE', VERBOSE, true);
            sc('Validating...', VERBOSE);
            
%             for ki = 1:length(x)
%                 if norm(src(:,ki) - cog) < cog2maxdist
%                     
%                     img_props = regionprops(contour_img,'Centroid');
%                     src = fliplr(img_props.Centroid)';
%                     tmpidx = sub2ind(size(T),round(src(1)),round(src(2)));
%                     srcidx = tmpidx;
% 
%                     src = cog;
% 
%                     break;
%                 end
%             end

            dv = sqrt(sum(power(src'-repmat(cog',[size(src',1),1]),2),2));
            if any(dv < cog2maxdist)
               [~, ml] = min(dv);
               src = src(:,ml);
            end
            
            if false
               exseed = zeros(size(T));
               exseed(srcidx) = 1;
               exseed = bwmorph(exseed,'dilate',2);
               [y,x] = ind2sub(size(T),find(exseed==1));
               src = [y,x]'; 
            end
            
            
            T = msfm2d(velocity, src, usesecond, usecross);
            T = T .* img; % consider only the interior of the object
            
            
            if strcmp(DEBUG,'on')
                figure, imagesc(T);
            end
            
%             h=figure('visible','off'); imagesc(T);
%             saveas(h, [OUTPUT, FIGDIR, [c(i).name(1:end-4),'_T']], 'png');

            if size(src,2) == 1
                assignments = ones(size(contour,1),1);
            else
                ill_posed = true;
                while ill_posed && size(src,2) > 1;

                    ill_posed = false;

                    %% assign contour points to closest seed point
                    c2cdist = nan(size(src,2),size(contour,1));
                    for src_it = 1:size(src,2)
                        c2cdist(src_it,:) = sqrt(sum(power(contour-repmat(src(:,src_it)',[size(contour,1),1]),2),2));
                    end

                    [~, assignments] = min(c2cdist,[],1);

                    % check of connectness
                    for src_it = 1:size(src,2)
                       tmp_assignments = assignments;
                       idx = tmp_assignments==src_it;
                       tmp_assignments(idx) = 1;
                       tmp_assignments(~idx) = 0;

                       % cluster occurrences
                       [~, nlbs] = bwlabel(tmp_assignments);

                       if nlbs == 1 || (nlbs == 2 && tmp_assignments(1) == tmp_assignments(end))
                          continue;
                       else
                           src = src(:,~ismember(1:size(src,2),src_it)); % HAS TO BE IMPROVED, remove THE ONE that has the lowest number of points
                           ill_posed = true;
                           break;
                       end
                    end  
                end
            end
            
            % ill behavior, CHECK LINES ABOVE
            if isempty(src)
                error('Error: Ill Behavior!');
                return;
            end
            
            sc('DONE', VERBOSE, true);
            sc('Arranging Contour...', VERBOSE);
             % arrange values in a line-ordered style
            bin_mask = assignments == assignments(1);
            first_idx = find(bin_mask == 0, 1, 'first');
            assignments = circshift(assignments, [0, -(first_idx-1)]);
            contour = circshift(contour', [0, -(first_idx-1)])';
            sc('DONE', VERBOSE, true);
            sc('Computing Breaking Points...', VERBOSE);
            %% computer second order derivatives
            poi_list = [];
            for src_it = 1:size(src,2)
                
                idx = sub2ind(size(T), contour(assignments == src_it,1), contour(assignments == src_it,2));
                values = T(idx);
                
                values = values/max(values);
                
                if strcmp(prefiltering,'on');
                    values = smooth(values,para_size);
                end
                
                if strcmp(DEBUG,'on')
                    figure, plot(1:length(values), values);
                end
                
                n = length(values);
%                 padvalues = flipud(-values)+2*values(1);
                values = [values; values; values];
                 
                %%%%%%%%
                %%%%%%%% smooth signal by using the fourier transform
                %%%%%%%%
                
                if size(src,2) > 1
                    smoothed_values = lp_filtering(values, para_lpf_multi);
                    tmp_sconf = para_lpf_multi;
                else
                    smoothed_values = lp_filtering(values, para_lpf_single);
                    tmp_sconf = para_lpf_single;
                end

                if size(src,2) > 1    
                    m = 10;
                else
                    m = 0;
                end

                smoothing_required = true;
                while smoothing_required
                    smoothing_required = false;
                    diffval = diff(smoothed_values(m+n+2:end-n-m+1));

                    % THIS IS PRETTY COOL !! :)
                    binSecondOrderDiff = diff(sign(diffval));
                    
                    tmp_loc = find(binSecondOrderDiff ~= 0);
                    
                    if size(src,2) == 1
                        tmp_loc = [tmp_loc, tmp_loc(end)+(n-tmp_loc(end))+tmp_loc(1)];
                    end
                    
                    pairdist = abs(tmp_loc(1:end-1) - tmp_loc(2:end));
                    
                    if any(pairdist < 0.5*std(pairdist))
                        tmp_ph = smoothed_values(tmp_loc(1:end-1));
                        tmp_ph = [tmp_ph, tmp_ph(1)];
                        pairheight = abs(tmp_ph(1:end-1) - tmp_ph(2:end));
                    
                        if any(pairheight < 0.2*std(pairheight))
                            tmp_sconf.para_sigma = tmp_sconf.para_sigma-0.1;
                            smoothed_values = lp_filtering(values, tmp_sconf);
                            smoothing_required = true;
                        end
                    end
                end
                
                if strcmp(DEBUG,'on')
                    figure, plot(1:length(smoothed_values), real(smoothed_values));
                    figure, plot(1:length(diffval), real(diffval));
                    figure, plot(1:length(binSecondOrderDiff), real(binSecondOrderDiff));
                end
                
                switch para_type
                    case 'min'
                        peaks_loc = find(binSecondOrderDiff > 0);
                    case 'max'
                        peaks_loc = find(binSecondOrderDiff < 0);
                    case 'all'
                        peaks_loc = find(binSecondOrderDiff ~= 0);
                    otherwise
                        error('Unknown parameter type: Please select amoung min,max or all... abort...')
                        return;
                end
                
                % offset that has to be considered, if the signal is cutted
                % above
                peaks_loc = peaks_loc + m;
                
                tmp_contour = contour(assignments == src_it,:);
                poi = tmp_contour(peaks_loc,:);
                
                if strcmp(DEBUG,'on')
                    figure, plot(contour(:,1), contour(:,2), '.');
                    hold on
                    plot(poi(:,1), poi(:,2), 'ro', 'Markersize', 20);
                end
                
                 %% post processing
                if false && strcmp(postprocessing,'on')
                    mask = zeros(size(poi,1),1);
                    contour_idx = zeros(length(poi),1);

                    for jk = 1:length(poi)
                        tmpci = find(all(contour == repmat(poi(jk,:), [length(contour),1]),2));
                        contour_idx(jk) = tmpci(1);
                    end


                    [~,mincidx] = min(contour_idx);
                    [~,maxcidx] = max(contour_idx);
                    new_pois = [];
                    
                    alldists = [];
                    for pk = 1:size(poi,1)-1
                            alldists = [alldists; abs(contour_idx(pk)-contour_idx(pk+1))];
                    end
                    
                    if size(src,2) == 1
                        alldists = [alldists; abs(length(contour)-contour_idx(end)+contour_idx(1))];
                    end
                    
%                     mean(alldists)
%                     std(alldists)
                    
                    thres = round(mean(alldists));
                    
                    for pk = 1:size(poi,1)

                        tmp = repmat(contour_idx(pk),[size(poi,1),1]);
                        pds = abs(contour_idx-tmp);

                        if mincidx == pk || maxcidx == pk 
                            tmp_dist1 = length(contour) - contour_idx(maxcidx) + contour_idx(mincidx);
                            tmp_dist2 = abs(contour_idx(maxcidx) - contour_idx(mincidx));
                            if tmp_dist2 > tmp_dist1;
                                pds(pds == tmp_dist2) = tmp_dist1;
                            end
                        end

%                         if sum(pds < para_p2p_mindist(contour)) > 1
                        if sum(pds < thres) > 1
                            switch para_remove_criteria
                                case 'removeboth'
                                    mask = pds < para_p2p_mindist(contour);
                                case 'addmidpt'
%                                     if all(mask(pds < para_p2p_mindist(contour)))
                                    if all(mask(pds < thres))
                                        continue;
                                    end
%                                     tmpmask = xor(logical((pds < para_p2p_mindist(contour))+mask),mask);
                                    tmpmask = xor(logical((pds < thres)+mask),mask);
                                    tmpmask(pk) = 1;
                                    mpois = poi(tmpmask,:);
                                    obidx = [];
                                    for id = 1:2
                                        tmpidx = find(all(repmat(mpois(id,:),[size(contour,1),1]) == contour, 2),2);
                                        obidx = [obidx, tmpidx(1)];
                                    end
                                    obdists = pds(tmpmask);
                                    new_pois = [new_pois; contour(mod(round(min(obidx) + (max(obdists)/2)),length(contour))+1,:)];
                                    mask = mask | tmpmask;
                                case 'one'
                                    % MISSING IMPLEMENTATION
                                case 'curvdep'
                                    % MISSING IMPLEMENTATION
                                otherwise
                                    error('Unknown parameter type: Please select amoung min,max or all... abort...')
                            end 

                        end
                    end

                    poi = poi(~mask,:);
                    poi = [poi;new_pois];

                end
                
                poi_list = [poi_list; poi];
                
            end
            sc('DONE', VERBOSE, true);
              
            %% post processing
            if false && strcmp(postprocessing,'on')
                mask = zeros(size(poi_list,1),1);
                contour_idx = zeros(length(poi_list),1);

                for jk = 1:length(poi_list)
                    tmpci = find(all(contour == repmat(poi_list(jk,:), [length(contour),1]),2));
                    contour_idx(jk) = tmpci(1);
                end


                [~,mincidx] = min(contour_idx);
                [~,maxcidx] = max(contour_idx);
                new_pois = [];

                for pk = 1:size(poi_list,1)

                    tmp = repmat(contour_idx(pk),[size(poi_list,1),1]);
                    pds = abs(contour_idx-tmp);

                    if mincidx == pk || maxcidx == pk 
                        tmp_dist1 = length(contour) - contour_idx(maxcidx) + contour_idx(mincidx);
                        tmp_dist2 = abs(contour_idx(maxcidx) - contour_idx(mincidx));
                        if tmp_dist2 > tmp_dist1;
                            pds(pds == tmp_dist2) = tmp_dist1;
                        end
                    end

                    if sum(pds < para_p2p_mindist(contour)) > 1
                        switch para_remove_criteria
                            case 'removeboth'
                                mask = pds < para_p2p_mindist(contour);
                            case 'addmidpt'
                                if all(mask(pds < para_p2p_mindist(contour)))
                                    continue;
                                end
                                tmpmask = xor(logical((pds < para_p2p_mindist(contour))+mask),mask);
                                tmpmask(pk) = 1;
                                mpois = poi_list(tmpmask,:);
                                obidx = [];
                                for id = 1:2
                                    tmpidx = find(all(repmat(mpois(id,:),[size(contour,1),1]) == contour, 2),2);
                                    obidx = [obidx, tmpidx(1)];
                                end
                                obdists = pds(tmpmask);
                                new_pois = [new_pois; contour(mod(round(min(obidx) + (max(obdists)/2)),length(contour))+1,:)];
                                mask = mask | tmpmask;
                            case 'one'
                                % MISSING IMPLEMENTATION
                            case 'curvdep'
                                % MISSING IMPLEMENTATION
                            otherwise
                                error('Unknown parameter type: Please select amoung min,max or all... abort...')
                        end 

                    end
                end

                poi_list = poi_list(~mask,:);
                poi_list = [poi_list;new_pois];
            end
			
            %% feedback to user + storing
            if strcmp(SHOW_RESULT,'on')
                figure, plot(contour(:,1), contour(:,2), '.');
                hold on
                plot(poi_list(:,1), poi_list(:,2), 'ro', 'Markersize', 20);
            end
            
            if strcmp(PAUSE,'on')
                sc('WAITNING FOR USER INTERAKTION...', VERBOSE, true);
                pause();
                close all;
            end
            
            if strcmp(SAVE_RESULT,'on')
               f = figure('visible','off'); plot(contour(:,1), contour(:,2), '.');
               hold on
               plot(poi_list(:,1), poi_list(:,2), 'ro', 'Markersize', 20);
%                saveas(f, [OUTPUT, FIGDIR, c(i).name(1:end-4)], 'png');
            end
            
            %% data generated above are used for segment extraction now
            if strcmp(SAVE_SEGS,'on')
                sc('Generating Contour Segments...', VERBOSE);
%                 mkdir([OUTPUT, CONSEGSDIR, c(i).name(1:end-4)]);
                poi_list = [poi_list; poi_list(1,:)];
                for idx = 1:size(poi_list,1)-1
                    k = find(all(repmat(poi_list(idx,:),[size(contour,1),1]) == contour, 2));
                    if length(k) > 1
                        contour = contour(~ismember(1:size(contour,1), k(2)),:);
                    end
                    k = k(1);
                    tmp       = circshift(contour, -(k-1));
                    m         = find(all(repmat(poi_list(idx+1,:),[size(tmp,1),1]) == tmp, 2));
                    segment   = tmp(1:m,:);
					ContourSegments{idx,1} = idx;
					ContourSegments{idx,2} = segment;
                    %save([OUTPUT, CONSEGSDIR, c(i).name(1:end-4), '/', num2str(idx*1000), '.mat'], 'segment');
                end
                sc('DONE', VERBOSE, true);
                poi_list = poi_list(1:end-1,:);
            end
            
            %% data storing - enjoy :)
            if strcmp(SAVE_POIS,'on')
                sc('Storing POIs...', VERBOSE);
                %save([OUTPUT, poidir, c(i).name(1:end-4), '.mat'], 'poi');
                sc('DONE', VERBOSE, true);
            end
            
            
            %% calculate tangent angles to rotate image for MWC
            rot_list = compute_rotation(TTangle, poi_list);
            if strcmp(SHOW_RESULT,'on')

               figure, plot(contour(:,1), contour(:,2), '.');
               hold on;
               plot(poi_list(:,1), poi_list(:,2), 'ro', 'Markersize', 20);

               for tidx = 1:length(rot_list)
                   text(poi_list(tidx,1)+5, poi_list(tidx,2)+5, num2str(rot_list(tidx)))
               end
            end
            
%             if strcmp(SAVE_ROTANG,'on')
%                 sc('Storing rotation angles...', VERBOSE);
%                 %save([OUTPUT, ROTDIR, c(i).name(1:end-4), '.mat'], 'rot_list');
%                 sc('DONE', VERBOSE, true);
%             end
            
            sc('===========', VERBOSE, true);

        catch me
            disp(me);
%             pause();
        end
    %end
end

function sc(msg, verbose, nl)
    
    if nargin < 3
        nl = false;
    end
    
    if strcmp(verbose,'on')
        if nl
            fprintf('%s\n', msg)
        else
            fprintf('%s', msg)
        end
    end
end

