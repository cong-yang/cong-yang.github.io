function [newimg,contour,contourpointlist] = f_image_preprocessing(image,resize)
%f_image_preprocessing: this function is used to process original image, includes 
%                       resize, transfer.
%  input:
%        image: original image
%        resize: scale time
%  output:
%        newimg: preprocessed image
%        contour: smoothed shape contour
%        contourpointlist: smoothed shape contour point list

%input and transfer image
image = imresize(image,resize,'bicubic');
bw = 1-im2bw(image,0.7);
boundaries = bwboundaries(bw);
newimg = bw*0;
temppoints = size(boundaries{1,1},1);
for i=1:1:temppoints
    newimg(boundaries{1,1}(i,1),boundaries{1,1}(i,2)) = 1;
end
contour = newimg;
newimg = imfill(newimg);
newimg = 1 - newimg; %the shape must be black
contourpointlist = boundaries;
end