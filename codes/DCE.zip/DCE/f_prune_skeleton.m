function [bw,sy,sx] = f_prune_skeleton(bw, y1, x1)
%PRUNESKELETON Summary of this function goes here
%   Detailed explanation goes here

% detect all skeleton end points
sValidIdx = find(bw == 1);
mCostMat = zeros(length(sValidIdx), length(sValidIdx));
mMapping = [sValidIdx, (1:length(sValidIdx))'];

for sIdx = 1:length(sValidIdx)
    
    [sy, sx] = ind2sub(size(bw), sValidIdx(sIdx));
    for y = max(sy-1,1):min(sy+1,size(bw,1))
        for x = max(sx-1,1):min(sx+1,size(bw,2))
            
            sMappedIdx = mMapping(:,1) == sub2ind(size(bw), y, x);
            
            if bw(y,x) ~= 0 && sum([y,x] == [sy,sx]) ~= 2;
            
                if x ~= sx && y ~= sy
                    sCost = sqrt(2);
                else
                    sCost = 1;
                end

                mCostMat(sIdx,sMappedIdx) = sCost;
            
            end
        end
    end
end

% get closest skeleton point to evolution point
[~, mCPts] = bwdist(bw);
tmpLinIdx = sub2ind(size(bw), y1, x1);
vEndPtIdx = mMapping(ismember(mMapping(:,1), mCPts(tmpLinIdx)),2);

% vEndPtIdx = zeros(length(x1),1);
% for i = 1:length(x1)
%     for y = max(y1(i)-1,1):min(y1(i)+1,size(bw,1))
%         for x = max(x1(i)-1,1):min(x1(i)+1,size(bw,2))
% 
%             if bw(y,x) ~= 0
%                 % index mapping
%                 mIdx = find(mMapping(:,1) == sub2ind(size(bw), y, x));
%                 vEndPtIdx(i) = mIdx;
%                 break;
%             end
%         end
%     end
% 
%     for y = max(y1(i)-2,1):min(y1(i)+2,size(bw,1))
%         for x = max(x1(i)-2,1):min(x1(i)+2,size(bw,2))
% 
%             if bw(y,x) ~= 0
%                 % index mapping
%                 mIdx = find(mMapping(:,1) == sub2ind(size(bw), y, x));
%                 vEndPtIdx(i) = mIdx;
%                 break;
%             end
%         end
%     end    
% end

vSkeletonPts = [];

while length(vEndPtIdx) ~= 1

    sStartNodeIdx = vEndPtIdx(1);
    vEndPtIdx = vEndPtIdx(2:length(vEndPtIdx));
    
    for sDestinationNodeIdx = vEndPtIdx'
        [~, path, ~] = graphshortestpath(sparse(mCostMat), sStartNodeIdx, sDestinationNodeIdx);
    end
    
    vSkeletonLine = mMapping(path,1);
    vSkeletonPts = [ vSkeletonLine; vSkeletonPts ];

end

vSkeletonPts = unique(vSkeletonPts);
[sy, sx] = ind2sub(size(bw),vSkeletonPts);

end

