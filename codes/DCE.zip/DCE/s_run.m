clear all;
close all;

resize = 1;
dceweight = 10; %this is the parameter

image = imread('butterfly08.png');
image = im2bw(image);
image  = 1 - image;
[newimg,mycontour,~] = f_image_preprocessing(image,resize);

[~, ~, endpointX,endpointY] = f_generate_endpoints(newimg, dceweight);

showcontour = 1 - mycontour;
imshow(showcontour);
hold on;
for i = 1:length(endpointX)
    plot(endpointY(i),endpointX(i),'*r');
end
hold off;