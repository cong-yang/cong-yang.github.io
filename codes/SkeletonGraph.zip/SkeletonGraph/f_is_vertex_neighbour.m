function [ bool_vertexneibhgour ] = f_is_vertex_neighbour( x1, y1, x2, y2 )
%f_is_vertex_neighbour: check if the coordinates specified by the 
%                    parameter are vertex neighbor coordinates.
%   101
%   020
%   101
%   like upper example, all 1 are vertex neibhtour of 2, all 0 are edge
%   neighbour of 2.

% input:
%       point1_cox: x axis of the point1
%       point1_coy: y axis of the point1
%       point2_cox: x axis of the point2
%       point2_coy: y axis of the point2

% output:
%       bool_vertexneibhgour: vertex neighbour(1) or not(0).

bool_vertexneibhgour = 0;

% upper left
if (x1 == x2 - 1) && (y1 == y2 - 1)
    bool_vertexneibhgour = 1;
    return;
end

%upper right
if (x1 == x2 + 1) && (y1 == y2 - 1)
    bool_vertexneibhgour = 1;
    return;
end

%bottom left
if x1 == (x2 - 1) && (y1 == y2 + 1)
    bool_vertexneibhgour = 1;
    return;
end

%bottom right
if x1 == (x2 + 1) && (y1 == y2 + 1)
    bool_vertexneibhgour = 1;
    return;
end




end

