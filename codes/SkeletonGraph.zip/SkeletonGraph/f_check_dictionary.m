function [ pointid ] = f_check_dictionary( pointx, pointy, Dictionary )
%f_check_dictionary: this function is used to check the position of a point in the Dictionary.
%   input:
%         [pointx, pointy]: point for checking
%         Dictionary: point dictionary
%   output:
%         pointid: position(row number) of the point in the dictionary

for i = 1:size(Dictionary,1)
    myx = Dictionary(i,1);
    myy = Dictionary(i,2);
    
    if pointx == myx && pointy == myy
        pointid = i;
        return;
    end
end


end

