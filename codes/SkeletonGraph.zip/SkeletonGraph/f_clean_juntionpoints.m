function [ newjunctionpoints ] = f_clean_juntionpoints( junctionpoints )
%f_clean_juntionpoints: this function is used to clean adjacent junction
%                       points.
%In 2D as well as in 3D, in some node constellations
%it can happen that in one crossing of skeleton branches, multiple skeleton
%nodes are recognized as junction nodes as they all have more than two
%neighbors. These junction nodes can than be grouped into a NodeArea.
%The NodeArea clean function will try to pick one of the nodes in a node 
%area more or less wise.
%   input:
%         junctionpoints: original junction points
%   output:
%         cleaned junction points

NodeAreas = [];

%create node area list
for i = 1:size(junctionpoints,1)
    point1_cox = junctionpoints(i,1);
    point1_coy = junctionpoints(i,2);
    %check whether it belongs to any NodeArea
    if size(NodeAreas,1) > 0
        tempcheck = 0;
        for mm = 1:length(NodeAreas)
            NodeArea = NodeAreas{mm};
            [bool_belongs] = f_is_belong_nodearea(point1_cox, point1_coy, NodeArea);
            if bool_belongs == 2 %belongs to this node area
                NodeArea(size(NodeArea,1)+1,1) = point1_cox;
                NodeArea(size(NodeArea,1),2) = point1_coy;
                NodeAreas{mm} = NodeArea;
                break;
            end
            if bool_belongs == 1 %existed in this node area
                break;
            end
            if bool_belongs == 0 %don't belongs to any node area
                tempcheck = tempcheck + 1;
            end
        end
        if tempcheck == length(NodeAreas)
            [NodeArea] = f_create_nodearea(point1_cox, point1_coy, junctionpoints);
            NodeAreas{length(NodeAreas)+1} = NodeArea;
        end
    else
        [NodeArea] = f_create_nodearea(point1_cox, point1_coy, junctionpoints);
        NodeAreas{length(NodeAreas)+1} = NodeArea;
    end
end

%clean junction point for each cell of NodeAreas
for i = 1:length(NodeAreas)
    NodeArea = NodeAreas{i};
    [pointx, pointy] = f_nodearea_clean(NodeArea);
    newjunctionpoints(i,1) = pointx;
    newjunctionpoints(i,2) = pointy;
end


end

