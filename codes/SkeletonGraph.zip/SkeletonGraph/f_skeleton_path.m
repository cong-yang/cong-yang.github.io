function [ pathes ] = f_skeleton_path( SkeletonBranchs, endpoints, junctionpoints )
%f_skeleton_path: this function is used to generate all skeleton path
%between any two skeleton endpoints.
% input:
%       SkeletonBranchs: contain all skeleton branches and path between
%                        junction points.
%       endpoints: all endpoints
%       junctionpoints: all junction points.

% output:
%       pathes: all skeleton shortest pathes between any two endpoints.

% first step: build graph
%Build a graph from the sampled parts. The vertices of the graph are the
%critical nodes of the skeleton (that is, junction and end nodes). The
%edges of the graph is the list of nodes connection the two vertices.
% A skeleton graph is a reduction of the skeleton to only end nodes and
%junction nodes. The vertices of the graph are the end nodes and junction
%nodes, respectively. Two vertices in the skeleton graph are connected if
%there exists a skeleton branch between them. The edge weight is given by 
%the length of the corresponding skeleton part. This data structure is needed 
%mostly for searching the shortest paths in the skeleton to create the skeleton paths.

%Direct Acyclic Graph (DAG) � N-by-N Sparse matrix that represents a graph. 
%Nonzero entries in matrix G represent the weights of the edges.
%http://www.mathworks.de/de/help/bioinfo/ug/features-and-functions.html#bqv508b-1

endpointsize = size(endpoints,1);
junctionpointsize = size(junctionpoints,1);

Dictionary = [];

pathes = {};

for i = 1:endpointsize
    Dictionary(size(Dictionary,1)+1,1) = endpoints(i,1);
    Dictionary(size(Dictionary,1),2) = endpoints(i,2);
end

for j = 1:junctionpointsize
    Dictionary(size(Dictionary,1)+1,1) = junctionpoints(j,1);
    Dictionary(size(Dictionary,1),2) = junctionpoints(j,2);
end

%create sparse matrix
%http://www.mathworks.de/de/help/bioinfo/ref/graphshortestpath.html
weights = [];
starts = [];
ends = [];
for i = 1:length(SkeletonBranchs)
    SkeletonBranch = SkeletonBranchs{i};
    startx = SkeletonBranch(1,1);
    starty = SkeletonBranch(1,2);
    endx = SkeletonBranch(size(SkeletonBranch,1),1);
    endy = SkeletonBranch(size(SkeletonBranch,1),2);
    edgeweight = size(SkeletonBranch,1);
    startid = f_check_dictionary( startx, starty, Dictionary );
    endid = f_check_dictionary( endx, endy, Dictionary );
    
    weights(1,length(weights) + 1) = edgeweight;
    starts(1,length(starts) + 1) = startid;
    ends(1,length(ends) + 1) = endid;
    
    newSkeletonBranches{i,1} = startid;
    newSkeletonBranches{i,2} = endid;
    newSkeletonBranches{i,3} = SkeletonBranch;
end

%fix the hole of the graph
%just to avoid the situation of the single path
[starts, ends, weights, newSkeletonBranches] = f_DAG_fix(starts, ends, weights, newSkeletonBranches);


DAG = sparse(starts,ends,weights);
%%%%Plot graph%%%%%%%
%h = view(biograph(DAG,[],'ShowWeights','on'));
%%%%Plot end%%%%%%%%%


%find shortest path for each pair of endpoints
myindex = 1;
for i = 1:endpointsize
    startx = endpoints(i,1);
    starty = endpoints(i,2);
    startid = f_check_dictionary( startx, starty, Dictionary );
    for j = 1:endpointsize
        endx = endpoints(j,1);
        endy = endpoints(j,2);
        endid = f_check_dictionary( endx, endy, Dictionary );
        if startid ~= endid
            [~, path, ~] = graphshortestpath(DAG, startid, endid,'Directed',true,'Method','Dijkstra');
            %%%%%%Plot the shortest path%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %set(h.Nodes(path),'Color',[1 0.4 0.4])
            %edges = getedgesbynodeid(h,get(h.Nodes(path),'ID'));
            %set(edges,'LineColor',[1 0 0])
            %set(edges,'LineWidth',1.5)
            %%%%%Plot end%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %start to generate point path
            [path_points] = f_get_path_points(path,newSkeletonBranches);
            pathes{myindex,1}(1,1) = startx;
            pathes{myindex,1}(1,2) = starty;
            pathes{myindex,2}(1,1) = endx;
            pathes{myindex,2}(1,2) = endy;
            pathes{myindex,3} = path_points;
            myindex = myindex + 1;
        end
    end
end

end