function [ neighbournumber, allneighbours ] = f_all_neighbors( pointx, pointy, skeleton )
%f_all_neighbors: this function is used to calculate number of neighbours
%of the current point.
%   input:
%         pointx: x axis of the current point
%         pointy: y axis of the current point
%         skeleton: full skeleton graph
%   output:
%         neighbournumber: number of neighbours
%         

%check the six neighbours of current point
neighbournumber = 0;

%upleft
if skeleton(pointx-1,pointy-1) == 1
    neighbournumber = neighbournumber + 1;
    allneighbours(neighbournumber,1) = pointx - 1;
    allneighbours(neighbournumber,2) = pointy - 1;
end

%upmiddle
if skeleton(pointx,pointy-1) == 1
    neighbournumber = neighbournumber + 1;
    allneighbours(neighbournumber,1) = pointx;
    allneighbours(neighbournumber,2) = pointy - 1;
end

%upright
if skeleton(pointx+1,pointy-1) == 1
    neighbournumber = neighbournumber + 1;
    allneighbours(neighbournumber,1) = pointx + 1;
    allneighbours(neighbournumber,2) = pointy - 1;
end

%left
if skeleton(pointx-1,pointy) == 1
    neighbournumber = neighbournumber + 1;
    allneighbours(neighbournumber,1) = pointx - 1;
    allneighbours(neighbournumber,2) = pointy;
end

%right
if skeleton(pointx+1,pointy) == 1
    neighbournumber = neighbournumber + 1;
    allneighbours(neighbournumber,1) = pointx + 1;
    allneighbours(neighbournumber,2) = pointy;
end

%bottomleft
if skeleton(pointx-1,pointy+1) == 1
    neighbournumber = neighbournumber + 1;
    allneighbours(neighbournumber,1) = pointx - 1;
    allneighbours(neighbournumber,2) = pointy + 1;
end

%bottommiddle
if skeleton(pointx,pointy+1) == 1
    neighbournumber = neighbournumber + 1;
    allneighbours(neighbournumber,1) = pointx;
    allneighbours(neighbournumber,2) = pointy + 1;
end

%bottomright
if skeleton(pointx+1,pointy+1) == 1
    neighbournumber = neighbournumber + 1;
    allneighbours(neighbournumber,1) = pointx + 1;
    allneighbours(neighbournumber,2) = pointy + 1;
end

end

