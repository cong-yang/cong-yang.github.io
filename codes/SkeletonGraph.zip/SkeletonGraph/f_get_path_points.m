function [ path_points ] = f_get_path_points( path,newSkeletonBranches )
%f_get_path_points: this function is used to generate path points based on
%the shortest path.
%   input:
%         path: shortest path with node id
%         Dictionary: dictionary for node id
%         SkeletonBranchs: all skeleton branch path

%   output:
%         path_points: point list on shortest path
for i = 1:length(path)-1
    startid = path(i);
    endid = path(i+1);
    
    for j = 1:length(newSkeletonBranches)
        mystart = newSkeletonBranches{j,1};
        myend = newSkeletonBranches{j,2};
        if startid == mystart && endid == myend
            mypath = newSkeletonBranches{j,3};
            pathlength = length(mypath);
            if i == 1 %start path
                path_points = mypath;
            else
                path_points((length(path_points)+1):(length(path_points)+pathlength-1),:) = mypath(2:pathlength,:);
            end
        end
    end
end

end

