function [ bool_belongs ] = f_is_belong_nodearea( pointx, pointy, NodeArea )
%f_is_belong_nodearea:  to check whether [pointx, pointy] belongs to a node
%                       area.
%   input:
%         pointx: x axis of the point
%         pointy: y axis of the point
%         NodeArea: single node area
%   output:
%         bool_belongs: exist(1), should be added(2) or not belongs(0)

bool_belongs = 0;

%first situation, exist
for i = 1:size(NodeArea,1)
    myx = NodeArea(i,1);
    myy = NodeArea(i,2);
    
    if pointx == myx && pointy == myy
        bool_belongs = 1;
        return;
    end
end

%second situation
%[pointx, pointy] is the neighbour of one of point in NodeArea
for i = 1:size(NodeArea,1)
    myx = NodeArea(i,1);
    myy = NodeArea(i,2);
    
    [boolean_neighbour] = f_is_neighbour(myx, myy, pointx, pointy);
    if boolean_neighbour == 1
        bool_belongs = 2;
        return;
    end
end


end

