function [ bool_exit ] = f_check_exist( sid,eid,starts,ends )
%f_check_exist: to check whether vector is exist from starts to ends
%output: 0 not exist, 1 exist
bool_exit = 0;

mysize = length(starts);

for i = 1:mysize
    if ends(i) == sid && starts(i) == eid
        bool_exit = 1;
        return;
    end
end



end

