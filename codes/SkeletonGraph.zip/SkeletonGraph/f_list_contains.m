function [ bool_contain ] = f_list_contains( pointx, pointy, pointlist )
%f_list_contains: this function is used to check wheather a 
%                 point(pointx, pointy) is contained in pointlist
%   input:
%         pointx: x axis of the point
%         pointy: y axis of the point
%         pointlist: all point list
%   output:
%        bool_contain: contain(1), or not(0)

bool_contain = 0;

for j = 1:size(pointlist,1)
    if pointx == pointlist(j,1) && pointy == pointlist(j,2)
        bool_contain = 1;
        return;
    end
end

end

