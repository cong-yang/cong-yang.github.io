clear all;
close all;

myimage = imread('butterfly08.png');
myimage = im2bw(myimage);
mycontour = bwmorph(myimage, 'remove');
[radiMatrix] = f_get_RadiMatrix(mycontour);
imshow(radiMatrix);

%generate endpoints and pathes
load('myskeleton');
[skeleton] = f_hole_checking(skeleton);
[SkeletonBranchs, endpoints, junctionpoints] = f_skeleton_branches(skeleton,mycontour);
[pathes] = f_skeleton_path(SkeletonBranchs, endpoints, junctionpoints);
figure,imshow(skeleton);
hold on;
plot(junctionpoints(:,2),junctionpoints(:,1),'*r');
plot(endpoints(:,2),endpoints(:,1),'*g');
hold off;


