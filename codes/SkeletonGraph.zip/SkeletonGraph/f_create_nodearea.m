function [ NodeArea ] = f_create_nodearea(point1_cox, point1_coy, junctionpoints )
%f_create_nodearea: this function is used to create a nodearea with [pointx, pointy]
%   input:
%         point1_cox: x axis of the input point
%         point1_coy: y axis of the input point
%         junctionpoints: all junction point list
%   output:
%         NodeArea: node area
nodeareaindex = 1;
NodeArea = [];
for j = 1:size(junctionpoints,1)
    point2_cox = junctionpoints(j,1);
    point2_coy = junctionpoints(j,2);
    [boolean_neighbour] = f_is_neighbour(point1_cox, point1_coy, point2_cox, point2_coy);
    if boolean_neighbour == 1 %two points are neighbour points
        NodeArea(nodeareaindex,1) = point1_cox;
        NodeArea(nodeareaindex,2) = point1_coy;
        NodeArea(nodeareaindex+1,1) = point2_cox;
        NodeArea(nodeareaindex+1,2) = point2_coy;
        nodeareaindex = nodeareaindex + 2;
    else
        NodeArea(nodeareaindex,1) = point1_cox;
        NodeArea(nodeareaindex,2) = point1_coy;
        nodeareaindex = nodeareaindex + 1;
    end
end

[NodeArea] = f_remove_duplicate(junctionpoints, NodeArea);

end

