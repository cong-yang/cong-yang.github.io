function [ skeleton ] = f_hole_checking( skeleton )
%f_hole_checking: this function is used to fix the hole in skeleton
%   input:
%         skeleton: original skeleton
%   output:
%         skeleton: fixed skeleton

%here we detect two types of hole:
%first type
% 1
%101
% 1

%second type
% 11
%1001
% 11

[skex,skey] = find(skeleton==1);

for i = 1:size(skex,1)
    x = skex(i);
    y = skey(i);
    
    %detect the first type
    if skeleton(x+1,y-1) == 1 && skeleton(x+1,y) == 0 && skeleton(x+1,y+1) == 1 && skeleton(x+2,y) == 1
        skeleton(x+1,y) = 1;
    end
    
    %detec the second type
    if skeleton(x-1,y+1) == 1 && skeleton(x-1,y+2) == 1 && skeleton(x,y+1) == 0 && skeleton(x,y+2) == 0 && skeleton(x,y+3) == 1 && skeleton(x+1,y+1) == 1 && skeleton(x+1,y+2) == 1
        skeleton(x,y+1) = 1;
        skeleton(x,y+2) = 1;
    end
end

end

