function [ radiMatrix ] = f_get_RadiMatrix(contour)

contour = im2bw(contour);

%fill everything outside
if contour(1,1)==0
    contour = imfill(contour,[1 1],4);
end

%distance transform
DT = bwdist(contour);

%normalize distance transform
sum = 0;
count = 0;
for i=1:size(DT,1)
    for j=1:size(DT,2)
        if DT(i,j) ~= 0
            sum = sum+DT(i,j);
            count = count+1;
        end
    end
end

radiMatrix = DT/(sum/count);

end

