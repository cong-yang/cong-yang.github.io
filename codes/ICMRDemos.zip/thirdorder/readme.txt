


This is a matlab demonstration code for the article:
A Tensor-Based Algorithm for High-Order Graph Matching,
published at ieee CVPR 2009,
by Olivier Duchenne, Francis Bach, Inso Kweon and Jean Ponce.
and edited by Cong Yang for the following paper:
Shape-based Object Matching Using Point Context, 
published at ACM ICMR 2015

I. Introduction

This code load two point sets P1 and P2 from two objects and try to match 
by the third order graph matching

The original similarity matrix X is initialized randomly. 
but you can use you own similarity method to initialize it.

II. How to use

1/ lunch install.m
2/ lunch test.m
3/ change P1, P2 and X with your own data and similarity method
4/ you can directly use f_get_similarity_third_order as your own function





