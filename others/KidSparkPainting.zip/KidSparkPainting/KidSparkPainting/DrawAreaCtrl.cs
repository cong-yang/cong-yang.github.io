using System;
using System.Threading;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Data;
using System.Windows.Forms;

namespace KidSparkPainting
{
	/// <summary>
    /// ժҪ˵��DrawAreaCtrl.
	/// </summary>
	public class DrawAreaCtrl : System.Windows.Forms.Control
    {
        #region ���в��������б�
        /// <summary>
        /// ���еĲ���ģʽ
        /// enModePoint:��깤��
        /// enModeLine��Ǧ�ʹ���
        /// enModeRect�����ι���
        /// enModeEllipse:��Բ����
        /// enModeCrayon:���ʹ���
        /// enModeRoundRectangle:Բ�Ǿ��ι���
        /// enModeInsertPic:����ͼƬ����
        /// enModeStraightline:ֱ�߹���
        /// enModeTexturePen:��������
        /// enModeInkPainting:ˮī������
        /// enModeChineseBrush:����ë��
        /// enModeEraser:��Ƥ������
        /// </summary>
        public enum WHITEBOARD_DRAW_MODE { 
                    enModePoint,        //��깤��
                    enModePencil,       //Ǧ�ʹ���
                    enModeRect,         //���ι���
                    enModeEllipse,      //��Բ����
                    enModeInsertPic,    //����ͼƬ
                    enModeStraightline, //ֱ�߹���
                    enModeCrayon,       //���ʹ���
                    enModeTexturePen,   //�������ʹ���
                    enModeInkPainting,  //ˮī������
                    enModeChineseBrush, //����ë�ʹ���
                    enModeEraser        //��Ƥ������
                };

        public WHITEBOARD_DRAW_MODE m_enDrawMode;  //��ͼģʽ

        #endregion ���в��������б�

        #region �������
        private Point m_ptLineStart, m_ptLineEnd, m_ptLinePrev; //���һ���ߵ�ǰ�˺ͺ�˴Ӷ��γ�һ����
        private bool m_bMouseDown;  //���������갴�µ�״̬��־
		private Bitmap  m_bmpSaved; //��Ӱλͼ��������������ͼ
		public	Bitmap  BitmapCanvas //������ҳ������ΪͼƬʹ��
		{
			get
			{
				return m_bmpSaved;
			}
		}

		private Graphics m_grfxBm;  //�����ͼ��壬֮���ͼ�����ڸ�����Ͻ��е�

        public Color m_ColorBack;  //��ͼ��ı�����ɫ
        public int PenSize; //���ʳߴ�
        public int InkFlow; //����īˮ����
        public Color Pen_Color; //������ɫ

        public Color TexturePen_MainColor;          //������������ɫ
        public Color TexturePen_InsertColor;        //�������ʲ�����ɫ
        public HatchStyle TexturePen_Hatchstyle;    //����������ʽ
        HatchBrush brushchinesepen = new HatchBrush(HatchStyle.BackwardDiagonal, Color.Black, Color.White); //������������
        
        #region ���ʴ�ϸѡ��

        //������״
        public enum CrayonWidth
        {
            Thin,       //ϸ����
            Middle,     //�е�����
            Thick       //������
        };

        public CrayonWidth CrayonMode;  //���ʴ�ϸģʽ

        #endregion ���ʴ�ϸѡ��

        #region ��������ͼƬ

        private Image piccy;

        private Point[] piccyBounds;

        private bool caninsert = true;

        #endregion ��������ͼƬ

        #region ��������Բ�Ƿ����

        public enum FillorNot
        {
            Fill,   //���ģʽ
            NotFill //�����ģʽ
        };

        public Color FillColor; //�����ɫ
        public FillorNot fillornot; //��ͼ���ģʽ

        #endregion ��������Բ�Ƿ����

        #region ��Ƥ������

        public enum EraserType
        {
            EraserEllipse,  //Բ����Ƥ��
            EraserRectangle //������Ƥ��
        };

        public EraserType erasertype;   //��Ƥ������

        #endregion ��Ƥ������

        #endregion �������

        #region ����ʱ��ļ�������

        public DrawAreaCtrl()
		{
			//m_enDrawMode = WHITEBOARD_DRAW_MODE.enModePencil; //����Ĭ�ϻ���
			
			m_ColorBack	= Color.White; //��ʼ������Ϊ��ɫ
			this.BackColor =  m_ColorBack;
		
			m_ptLineStart = m_ptLineEnd = m_ptLinePrev = new Point(0,0);
			m_bMouseDown = false;

            Size sz = SystemInformation.PrimaryMonitorMaximizedWindowSize;  //��ȡĬ��һ������ʾ������󻯴��ڳߴ硣
			m_bmpSaved = new Bitmap (sz.Width, sz.Height);
			m_grfxBm = Graphics.FromImage(m_bmpSaved);  //���������ͼƬ����
			//m_grfxBm.Clear(BackColor);
			UnlockWhiteBoardMouseEvents();  //������������Ӷ���
        }

        #endregion ����ʱ��ļ�������

        #region ��Ҫ�����������޸�
        //����Ҫ�ĺ�����Ϊ������Ӷ����¼�
        public void UnlockWhiteBoardMouseEvents()
        {
            this.MouseDown += new MouseEventHandler(this.OnMouseDownHdlr);
            this.MouseMove += new MouseEventHandler(this.OnMouseMoveHdlr);
            this.MouseUp += new MouseEventHandler(this.OnMouseUpHdlr);
        }

        //����Ҫ�ĺ����������ػ�
		protected override void OnPaint(PaintEventArgs e)
		{
			Graphics g = e.Graphics;
			g.DrawImage(m_bmpSaved, 0,0,m_bmpSaved.Width, m_bmpSaved.Height);
        }

        //��걻����
		protected void OnMouseDownHdlr(object sender, MouseEventArgs mea)
		{
		    Point pt = new Point(mea.X, mea.Y);
			WhenMouseDown(pt);
		}

        //����ƶ�
		protected void OnMouseMoveHdlr(object sender, MouseEventArgs mea)
		{
			Point pt = new Point(mea.X, mea.Y);
			WhenMouseMove(pt);
		}

        //���̧��
		protected void OnMouseUpHdlr(object sender, MouseEventArgs mea)
		{
			Point pt = new Point(mea.X, mea.Y);
			WhenMouseUp(pt);
        }

        #endregion ��Ҫ�����������޸�

        #region �����Ļ����

        //���������Ļ����
        public void ClearScreen()
        {
            //�������ʣ����ʵ���ɫ��
            SolidBrush BkgBrush = new SolidBrush(m_ColorBack);
            //����һ�����Σ��������ǻ���
            float x = 0.0F;
            float y = 0.0F;
            float width = this.Width;
            float height = this.Height;
            //���þ���
            Graphics grfx = CreateGraphics();
            grfx.FillRectangle(BkgBrush, x, y, width, height);
            grfx.Dispose();
            //�����������λͼ
            m_grfxBm.FillRectangle(BkgBrush, x, y, width, height);
        }

        //��Ƥ������

        #endregion �����Ļ����

        #region ��걻���¡��˶���̧��Ķ���
        //��걻����ʱ��Ķ���
		public void WhenMouseDown(Point pt)
		{
			switch (m_enDrawMode)
            {
                #region ��깤��
                case WHITEBOARD_DRAW_MODE.enModePoint:
                    m_ptLineStart.X = pt.X;
                    m_ptLineStart.Y = pt.Y;
                    m_ptLineEnd.X = pt.X;
                    m_ptLineEnd.Y = pt.Y;
                    m_bMouseDown = true;
                    break;
                #endregion ��깤��
                #region Ǧ�ʹ���
                case WHITEBOARD_DRAW_MODE.enModePencil:   //Ǧ�ʹ���
					m_ptLineStart.X  = m_ptLinePrev.X = pt.X;
					m_ptLineStart.Y  = m_ptLinePrev.Y = pt.Y;
					m_bMouseDown = true;
					break;
                #endregion Ǧ�ʹ���
                #region ����
                case WHITEBOARD_DRAW_MODE.enModeRect:   //���ι���
					m_ptLineStart.X = pt.X;
					m_ptLineStart.Y = pt.Y;
                    m_ptLineEnd.X = pt.X;
                    m_ptLineEnd.Y = pt.Y;
                    m_bMouseDown = true;
					break;
                #endregion ����
                #region ��Բ
                case WHITEBOARD_DRAW_MODE.enModeEllipse:    //��Բ����
					m_ptLineStart.X = pt.X;
					m_ptLineStart.Y = pt.Y;
					m_bMouseDown = true;
					break;
                #endregion ��Բ
                #region ����ͼƬ
                case WHITEBOARD_DRAW_MODE.enModeInsertPic:  //����ͼƬ
                    m_ptLineStart.X = pt.X;
                    m_ptLineStart.Y = pt.Y;
                    m_ptLineEnd.X = pt.X;
                    m_ptLineEnd.Y = pt.Y;
                    m_bMouseDown = true;
                    break;
                #endregion ����ͼƬ
                #region ֱ�߹���
                case WHITEBOARD_DRAW_MODE.enModeStraightline:
                    m_ptLineStart.X = pt.X;
                    m_ptLineStart.Y = pt.Y;
                    m_ptLineEnd.X = pt.X;
                    m_ptLineEnd.Y = pt.Y;
                    m_bMouseDown = true;
                    break;
                #endregion ֱ�߹���
                #region ���ʹ���
                case WHITEBOARD_DRAW_MODE.enModeCrayon:   //���ʹ���
                    switch (CrayonMode) //���ʹ���ģʽ
                    {
                        #region ϸ����
                        case CrayonWidth.Thin:
                            Size ellipseSizeThin = new Size(1, 2);
                            Brush redbrushThin = new SolidBrush(Color.FromArgb(InkFlow, Pen_Color.R, Pen_Color.G, Pen_Color.B));
                            Point ellipseTopLeftThin;
                            Random raThin = new Random();
                            int widthThin;
                            int hightThin;
                            Graphics grfxThin = CreateGraphics();
                            Rectangle ellipseAreaThin;
                            for (int i = 0; i < 15; i++)
                            {
                                widthThin = raThin.Next(pt.X, pt.X + 0);
                                hightThin = raThin.Next(pt.Y, pt.Y + 0);
                                ellipseTopLeftThin = new Point(widthThin, hightThin);
                                ellipseAreaThin = new Rectangle(ellipseTopLeftThin, ellipseSizeThin);
                                grfxThin.FillEllipse(redbrushThin, ellipseAreaThin);
                                m_grfxBm.FillEllipse(redbrushThin, ellipseAreaThin);
                            }
                            for (int k = 0; k < 25; k++)
                            {
                                widthThin = raThin.Next(pt.X - 0, pt.X + 4);
                                hightThin = raThin.Next(pt.Y - 1, pt.Y + 2);
                                ellipseTopLeftThin = new Point(widthThin, hightThin);
                                ellipseAreaThin = new Rectangle(ellipseTopLeftThin, ellipseSizeThin);
                                grfxThin.FillEllipse(redbrushThin, ellipseAreaThin);
                                m_grfxBm.FillEllipse(redbrushThin, ellipseAreaThin);
                            }
                            for (int j = 0; j < 35; j++)
                            {
                                widthThin = raThin.Next(pt.X - 3, pt.X + 7);
                                hightThin = raThin.Next(pt.Y - 4, pt.Y + 4);
                                ellipseTopLeftThin = new Point(widthThin, hightThin);
                                ellipseAreaThin = new Rectangle(ellipseTopLeftThin, ellipseSizeThin);
                                grfxThin.FillEllipse(redbrushThin, ellipseAreaThin);
                                m_grfxBm.FillEllipse(redbrushThin, ellipseAreaThin);
                            }

                            m_ptLineStart.X = m_ptLinePrev.X = pt.X;
                            m_ptLineStart.Y = m_ptLinePrev.Y = pt.Y;
                            m_bMouseDown = true;
                            break;
                        #endregion ϸ����
                        #region �е�����
                        case CrayonWidth.Middle:
                            Size ellipseSizeMiddle = new Size(1, 2);
                            Brush redbrushMiddle = new SolidBrush(Color.FromArgb(InkFlow, Pen_Color.R, Pen_Color.G, Pen_Color.B));
                            Point ellipseTopLeftMiddle;
                            Random raMiddle = new Random();
                            int widthMiddle;
                            int hightMiddle;
                            Graphics grfxMiddle = CreateGraphics();
                            Rectangle ellipseAreaMiddle;
                            for (int i = 0; i < 35; i++)
                            {
                                widthMiddle = raMiddle.Next(pt.X, pt.X + 5);
                                hightMiddle = raMiddle.Next(pt.Y, pt.Y + 5);
                                ellipseTopLeftMiddle = new Point(widthMiddle, hightMiddle);
                                ellipseAreaMiddle = new Rectangle(ellipseTopLeftMiddle, ellipseSizeMiddle);
                                grfxMiddle.FillEllipse(redbrushMiddle, ellipseAreaMiddle);
                                m_grfxBm.FillEllipse(redbrushMiddle, ellipseAreaMiddle);
                            }
                            for (int k = 0; k < 45; k++)
                            {
                                widthMiddle = raMiddle.Next(pt.X - 2, pt.X + 12);
                                hightMiddle = raMiddle.Next(pt.Y - 3, pt.Y + 10);
                                ellipseTopLeftMiddle = new Point(widthMiddle, hightMiddle);
                                ellipseAreaMiddle = new Rectangle(ellipseTopLeftMiddle, ellipseSizeMiddle);
                                grfxMiddle.FillEllipse(redbrushMiddle, ellipseAreaMiddle);
                                m_grfxBm.FillEllipse(redbrushMiddle, ellipseAreaMiddle);
                            }
                            for (int j = 0; j < 55; j++)
                            {
                                widthMiddle = raMiddle.Next(pt.X - 6, pt.X + 15);
                                hightMiddle = raMiddle.Next(pt.Y - 7, pt.Y + 12);
                                ellipseTopLeftMiddle = new Point(widthMiddle, hightMiddle);
                                ellipseAreaMiddle = new Rectangle(ellipseTopLeftMiddle, ellipseSizeMiddle);
                                grfxMiddle.FillEllipse(redbrushMiddle, ellipseAreaMiddle);
                                m_grfxBm.FillEllipse(redbrushMiddle, ellipseAreaMiddle);
                            }

                            m_ptLineStart.X = m_ptLinePrev.X = pt.X;
                            m_ptLineStart.Y = m_ptLinePrev.Y = pt.Y;
                            m_bMouseDown = true;
                            break;
                        #endregion �е�����
                        #region ������
                        case CrayonWidth.Thick:
                            Size ellipseSizeThick = new Size(1, 2);
                            Brush redbrushThick = new SolidBrush(Color.FromArgb(InkFlow, Pen_Color.R, Pen_Color.G, Pen_Color.B));
                            Point ellipseTopLeftThick;
                            Random raThick = new Random();
                            int widthThick;
                            int hightThick;
                            Graphics grfxThick = CreateGraphics();
                            Rectangle ellipseAreaThick;
                            for (int i = 0; i < 35; i++)
                            {
                                widthThick = raThick.Next(pt.X, pt.X + 5);
                                hightThick = raThick.Next(pt.Y, pt.Y + 5);
                                ellipseTopLeftThick = new Point(widthThick, hightThick);
                                ellipseAreaThick = new Rectangle(ellipseTopLeftThick, ellipseSizeThick);
                                grfxThick.FillEllipse(redbrushThick, ellipseAreaThick);
                                m_grfxBm.FillEllipse(redbrushThick, ellipseAreaThick);
                            }
                            for (int k = 0; k < 45; k++)
                            {
                                widthThick = raThick.Next(pt.X - 2, pt.X + 12);
                                hightThick = raThick.Next(pt.Y - 3, pt.Y + 10);
                                ellipseTopLeftThick = new Point(widthThick, hightThick);
                                ellipseAreaThick = new Rectangle(ellipseTopLeftThick, ellipseSizeThick);
                                grfxThick.FillEllipse(redbrushThick, ellipseAreaThick);
                                m_grfxBm.FillEllipse(redbrushThick, ellipseAreaThick);
                            }
                            for (int j = 0; j < 55; j++)
                            {
                                widthThick = raThick.Next(pt.X - 6, pt.X + 15);
                                hightThick = raThick.Next(pt.Y - 7, pt.Y + 12);
                                ellipseTopLeftThick = new Point(widthThick, hightThick);
                                ellipseAreaThick = new Rectangle(ellipseTopLeftThick, ellipseSizeThick);
                                grfxThick.FillEllipse(redbrushThick, ellipseAreaThick);
                                m_grfxBm.FillEllipse(redbrushThick, ellipseAreaThick);
                            }

                            m_ptLineStart.X = m_ptLinePrev.X = pt.X;
                            m_ptLineStart.Y = m_ptLinePrev.Y = pt.Y;
                            m_bMouseDown = true;
                            break;
                        #endregion ������
                        #region Ĭ������
                        default:
                            break;
                        #endregion Ĭ������
                    }
                    break;
                #endregion ���ʹ���
                #region ��������
                case WHITEBOARD_DRAW_MODE.enModeTexturePen:   //��������
                    m_ptLineStart.X = m_ptLinePrev.X = pt.X;
                    m_ptLineStart.Y = m_ptLinePrev.Y = pt.Y;
                    Graphics grfxTexturePen = CreateGraphics();
                    grfxTexturePen.FillEllipse(brushchinesepen, pt.X - (PenSize / 2), pt.Y - (PenSize / 2), PenSize, PenSize);
                    grfxTexturePen.Dispose();
                    m_grfxBm.FillEllipse(brushchinesepen, pt.X - (PenSize / 2), pt.Y - (PenSize / 2), PenSize, PenSize);
                    m_bMouseDown = true;
                    break;
                #endregion ��������
                #region ˮī������
                case WHITEBOARD_DRAW_MODE.enModeInkPainting:   //ˮī������
                    m_ptLineStart.X = m_ptLinePrev.X = pt.X;
                    m_ptLineStart.Y = m_ptLinePrev.Y = pt.Y;

                    Graphics grfxInkPainting = CreateGraphics();
                    GraphicsPath path = new GraphicsPath();
                    path.AddEllipse(pt.X, pt.Y, PenSize, PenSize);

                    PathGradientBrush pthGrBrush = new PathGradientBrush(path);

                    pthGrBrush.CenterColor = Color.FromArgb(255,
                        (int)(Pen_Color.R - Pen_Color.R * 0.345),
                        (int)(Pen_Color.G - Pen_Color.G * 0.345),
                        (int)(Pen_Color.B - Pen_Color.B * 0.345));    //��ɫ,͸����255����͸����
                    Color[] colors = { Color.FromArgb(0, Pen_Color.R, Pen_Color.G, Pen_Color.B) }; //��ɫ

                    pthGrBrush.SurroundColors = colors;
                    grfxInkPainting.FillEllipse(pthGrBrush, pt.X, pt.Y, PenSize, PenSize);
                    grfxInkPainting.Dispose();

                    m_grfxBm.FillEllipse(pthGrBrush, pt.X, pt.Y, PenSize, PenSize);
                    m_bMouseDown = true;
                    break;
                #endregion ˮī������
                #region ����ë��
                case WHITEBOARD_DRAW_MODE.enModeChineseBrush:   //����ë��
                    m_ptLineStart.X = m_ptLinePrev.X = pt.X;
                    m_ptLineStart.Y = m_ptLinePrev.Y = pt.Y;

                    Pen ChinesePn = new Pen(Color.FromArgb(InkFlow, Pen_Color.R, Pen_Color.G, Pen_Color.B), PenSize);
                    Brush ChineseBrush = new SolidBrush(Color.FromArgb(InkFlow, Pen_Color.R, Pen_Color.G, Pen_Color.B));
                    Graphics grfxChineseBrush = CreateGraphics();
                    grfxChineseBrush.DrawLine(ChinesePn, m_ptLineStart, pt);
                    grfxChineseBrush.FillEllipse(ChineseBrush, pt.X - (PenSize / 2), pt.Y - (PenSize / 2), PenSize, PenSize);
                    grfxChineseBrush.Dispose();

                    m_grfxBm.DrawLine(ChinesePn, m_ptLineStart, pt);
                    m_grfxBm.FillEllipse(ChineseBrush, pt.X - (PenSize / 2), pt.Y - (PenSize / 2), PenSize, PenSize);
                    m_bMouseDown = true;
                    break;
                #endregion ����ë��
                #region ��Ƥ������
                case WHITEBOARD_DRAW_MODE.enModeEraser: //��Ƥ������
                    m_ptLineStart.X = m_ptLinePrev.X = pt.X;
                    m_ptLineStart.Y = m_ptLinePrev.Y = pt.Y;
                    m_bMouseDown = true;
                    break;
                #endregion ��Ƥ������
                #region Ĭ��
                default:
					break;
                #endregion Ĭ��
            }
		}
		
  		//����˶�ʱ��Ķ���
		public void WhenMouseMove(Point pt)
		{
			switch (m_enDrawMode)
            {
                #region ��깤��
                case WHITEBOARD_DRAW_MODE.enModePoint:

                    Point pointshubiao = new Point(pt.X, pt.Y);
                    Point oldPointshubiao = m_ptLineEnd;

                    if (!m_bMouseDown)
                    {
                        return;
                    }

                    m_ptLineEnd.X = pt.X;
                    m_ptLineEnd.Y = pt.Y;

                    ControlPaint.DrawReversibleFrame(
                        this.RectangleToScreen(DrawRectangle.GetNormalizedRectangle(m_ptLineStart, oldPointshubiao)),
                        Color.Black, FrameStyle.Dashed);

                    // Draw new selection rectangle
                    ControlPaint.DrawReversibleFrame(
                        this.RectangleToScreen(DrawRectangle.GetNormalizedRectangle(m_ptLineStart, pointshubiao)),
                        Color.Black, FrameStyle.Dashed);
                    break;
                #endregion ��깤��
                #region Ǧ�ʹ���
                case WHITEBOARD_DRAW_MODE.enModePencil:   //��ֱ��
					m_ptLineEnd.X = pt.X;
					m_ptLineEnd.Y = pt.Y;
					if	(m_bMouseDown)
					{
                        Pen pn = new Pen(Color.FromArgb(InkFlow, Pen_Color.R, Pen_Color.G, Pen_Color.B), PenSize);
						Graphics grfx = CreateGraphics();
						grfx.DrawLine(pn, m_ptLinePrev, m_ptLineEnd);
						grfx.Dispose();
						//��bitmap�������
						m_grfxBm.DrawLine(pn, m_ptLinePrev, m_ptLineEnd);
					}
					m_ptLinePrev = m_ptLineEnd;
					break;
                #endregion Ǧ�ʹ���
                #region ����
                case WHITEBOARD_DRAW_MODE.enModeRect:   //������
					m_ptLineEnd.X = pt.X;
					m_ptLineEnd.Y = pt.Y;
					if	(m_bMouseDown)
					{
                        Graphics grfx = CreateGraphics();
                        switch (fillornot)  //�鿴�Ƿ�Ϊ���ģʽ
                        {
                            #region ���ģʽ
                            case FillorNot.Fill:    //Ϊ���ģʽ
                                Brush fillpen = new SolidBrush(Color.FromArgb(InkFlow, FillColor.R, FillColor.G, FillColor.B));
                                Brush brushback = new SolidBrush(m_ColorBack);
                                //�����ǰ��������
                                grfx.FillRectangle(brushback,
                                    (float)m_ptLineStart.X,
                                    (float)m_ptLineStart.Y,
                                    (float)m_ptLinePrev.X - (float)m_ptLineStart.X,
                                    (float)m_ptLinePrev.Y - (float)m_ptLineStart.Y);
                                //�����µ�������
                                grfx.FillRectangle(fillpen,
                                    (float)m_ptLineStart.X,
                                    (float)m_ptLineStart.Y,
                                    (float)m_ptLineEnd.X - (float)m_ptLineStart.X,
                                    (float)m_ptLineEnd.Y - (float)m_ptLineStart.Y);
                                grfx.Dispose();
                                //����֮ǰλͼ�ϵ�������
                                m_grfxBm.FillRectangle(brushback,
                                    (float)m_ptLineStart.X,
                                    (float)m_ptLineStart.Y,
                                    (float)m_ptLinePrev.X - (float)m_ptLineStart.X,
                                    (float)m_ptLinePrev.Y - (float)m_ptLineStart.Y);
                                //��λͼ�ϻ����µ�������
                                m_grfxBm.FillRectangle(fillpen,
                                    (float)m_ptLineStart.X,
                                    (float)m_ptLineStart.Y,
                                    (float)m_ptLineEnd.X - (float)m_ptLineStart.X,
                                    (float)m_ptLineEnd.Y - (float)m_ptLineStart.Y);
                                break;
                            #endregion ���ģʽ
                            #region �����ģʽ
                            case FillorNot.NotFill: //�������ģʽ
                                Pen pn = new Pen(Color.FromArgb(InkFlow, Pen_Color.R, Pen_Color.G, Pen_Color.B), PenSize);
                                Pen pnFore = new Pen(m_ColorBack, PenSize);
                                //�����ǰ�ľ���
                                grfx.DrawRectangle(pnFore,
                                    (float)m_ptLineStart.X,
                                    (float)m_ptLineStart.Y,
                                    (float)m_ptLinePrev.X - (float)m_ptLineStart.X,
                                    (float)m_ptLinePrev.Y - (float)m_ptLineStart.Y);
                                //�����µľ���
                                grfx.DrawRectangle(pn,
                                    (float)m_ptLineStart.X,
                                    (float)m_ptLineStart.Y,
                                    (float)m_ptLineEnd.X - (float)m_ptLineStart.X,
                                    (float)m_ptLineEnd.Y - (float)m_ptLineStart.Y);
                                //Math.Abs
                                grfx.Dispose();
                                //����֮ǰλͼ�ϵľ���
                                m_grfxBm.DrawRectangle(pnFore,
                                    (float)m_ptLineStart.X,
                                    (float)m_ptLineStart.Y,
                                    (float)m_ptLinePrev.X - (float)m_ptLineStart.X,
                                    (float)m_ptLinePrev.Y - (float)m_ptLineStart.Y);
                                //��λͼ�ϻ����µľ���
                                m_grfxBm.DrawRectangle(pn,
                                    (float)m_ptLineStart.X,
                                    (float)m_ptLineStart.Y,
                                    (float)m_ptLineEnd.X - (float)m_ptLineStart.X,
                                    (float)m_ptLineEnd.Y - (float)m_ptLineStart.Y);
                                break;
                            #endregion �����ģʽ
                            #region Ĭ��
                            default:
                                break;
                            #endregion Ĭ��
                        }
					}
					m_ptLinePrev = m_ptLineEnd;
					break;
                #endregion ����
                #region ��Բ
                case WHITEBOARD_DRAW_MODE.enModeEllipse:
					m_ptLineEnd.X = pt.X;
					m_ptLineEnd.Y = pt.Y;
					if	(m_bMouseDown)
					{
						Graphics grfx = CreateGraphics();
                        switch (fillornot)  //�鿴�Ƿ�Ϊ���ģʽ
                        {
                            #region ���ģʽ
                            case FillorNot.Fill:    //Ϊ���ģʽ
                                Brush fillpen = new SolidBrush(Color.FromArgb(InkFlow, FillColor.R, FillColor.G, FillColor.B));
                                Brush backpen = new SolidBrush(m_ColorBack);
                                //�����ǰ�������Բ
                                grfx.FillEllipse(backpen,
                                    (float)m_ptLineStart.X,
                                    (float)m_ptLineStart.Y,
                                    (float)m_ptLinePrev.X - (float)m_ptLineStart.X,
                                    (float)m_ptLinePrev.Y - (float)m_ptLineStart.Y);
                                //�����µ������Բ
                                grfx.FillEllipse(fillpen,
                                    (float)m_ptLineStart.X,
                                    (float)m_ptLineStart.Y,
                                    (float)m_ptLineEnd.X - (float)m_ptLineStart.X,
                                    (float)m_ptLineEnd.Y - (float)m_ptLineStart.Y);
                                grfx.Dispose();
                                //����λͼ��֮ǰ�������Բ
                                m_grfxBm.FillEllipse(backpen,
                                    (float)m_ptLineStart.X,
                                    (float)m_ptLineStart.Y,
                                    (float)m_ptLinePrev.X - (float)m_ptLineStart.X,
                                    (float)m_ptLinePrev.Y - (float)m_ptLineStart.Y);
                                //��λͼɽ�����µ������Բ
                                m_grfxBm.FillEllipse(fillpen,
                                    (float)m_ptLineStart.X,
                                    (float)m_ptLineStart.Y,
                                    (float)m_ptLineEnd.X - (float)m_ptLineStart.X,
                                    (float)m_ptLineEnd.Y - (float)m_ptLineStart.Y);
                                break;
                            #endregion ���ģʽ
                            #region �����ģʽ
                            case FillorNot.NotFill: //�������ģʽ
                                Pen pn = new Pen(Color.FromArgb(InkFlow, Pen_Color.R, Pen_Color.G, Pen_Color.B), PenSize);
                                Pen pnFore = new Pen(m_ColorBack, PenSize);
                                //�����ǰ����Բ
                                grfx.DrawEllipse(pnFore,
                                    (float)m_ptLineStart.X,
                                    (float)m_ptLineStart.Y,
                                    (float)m_ptLinePrev.X - (float)m_ptLineStart.X,
                                    (float)m_ptLinePrev.Y - (float)m_ptLineStart.Y);
                                //�����µ���Բ
                                grfx.DrawEllipse(pn,
                                    (float)m_ptLineStart.X,
                                    (float)m_ptLineStart.Y,
                                    (float)m_ptLineEnd.X - (float)m_ptLineStart.X,
                                    (float)m_ptLineEnd.Y - (float)m_ptLineStart.Y);
                                grfx.Dispose();
                                //����λͼ��֮ǰ����Բ
                                m_grfxBm.DrawEllipse(pnFore,
                                    (float)m_ptLineStart.X,
                                    (float)m_ptLineStart.Y,
                                    (float)m_ptLinePrev.X - (float)m_ptLineStart.X,
                                    (float)m_ptLinePrev.Y - (float)m_ptLineStart.Y);
                                //��λͼɽ�����µ���Բ
                                m_grfxBm.DrawEllipse(pn,
                                    (float)m_ptLineStart.X,
                                    (float)m_ptLineStart.Y,
                                    (float)m_ptLineEnd.X - (float)m_ptLineStart.X,
                                    (float)m_ptLineEnd.Y - (float)m_ptLineStart.Y);
                                break;
                            #endregion �����ģʽ
                            #region Ĭ��
                            default:
                                break;
                            #endregion Ĭ��
                        }
					}
					m_ptLinePrev = m_ptLineEnd;
					break;
                #endregion ��Բ
                #region ����ͼƬ
                case WHITEBOARD_DRAW_MODE.enModeInsertPic:

                    Point point = new Point(pt.X, pt.Y);
                    Point oldPoint = m_ptLineEnd;

                    if (!m_bMouseDown)
                    {
                        return;
                    }

                    m_ptLineEnd.X = pt.X;
                    m_ptLineEnd.Y = pt.Y;

                        ControlPaint.DrawReversibleFrame(
                            this.RectangleToScreen(DrawRectangle.GetNormalizedRectangle(m_ptLineStart, oldPoint)),
                            Color.Black, FrameStyle.Dashed);

                        // Draw new selection rectangle
                        ControlPaint.DrawReversibleFrame(
                            this.RectangleToScreen(DrawRectangle.GetNormalizedRectangle(m_ptLineStart, point)),
                            Color.Black, FrameStyle.Dashed);
                        caninsert = true;   //���Լ�������ͼƬ
                    break;
                #endregion ����ͼƬ
                #region ֱ�߹���
                case WHITEBOARD_DRAW_MODE.enModeStraightline:
                    m_ptLineEnd.X = pt.X;
                    m_ptLineEnd.Y = pt.Y;
                    if (m_bMouseDown)
                    {
                        Pen pn = new Pen(Color.FromArgb(InkFlow, Pen_Color.R, Pen_Color.G, Pen_Color.B), PenSize);
                        Pen pnFore = new Pen(m_ColorBack, PenSize);
                        Graphics grfx = CreateGraphics();
                        //������ǰ��ֱ��
                        grfx.DrawLine(pnFore, m_ptLineStart.X, m_ptLineStart.Y, m_ptLinePrev.X, m_ptLinePrev.Y);
						//�����µ�ֱ��
                        grfx.DrawLine(pn, m_ptLineStart.X, m_ptLineStart.Y, m_ptLineEnd.X , m_ptLineEnd.Y);
						//Math.Abs
						grfx.Dispose();
						//����֮ǰλͼ�ϵ�ֱ��
                        m_grfxBm.DrawLine(pnFore, m_ptLineStart.X, m_ptLineStart.Y, m_ptLinePrev.X, m_ptLinePrev.Y);
						//��λͼ�ϻ����µ�ֱ��
                        m_grfxBm.DrawLine(pn, m_ptLineStart.X, m_ptLineStart.Y, m_ptLineEnd.X, m_ptLineEnd.Y);
					}
                    m_ptLinePrev = m_ptLineEnd;
                    break;
                #endregion ֱ�߹���
                #region ���ʹ���
                case WHITEBOARD_DRAW_MODE.enModeCrayon:   //���ʹ���
                    if (m_bMouseDown)
                    {
                        switch (CrayonMode) //���ʹ���ģʽ
                        {
                            #region ϸ����
                            case CrayonWidth.Thin:
                                Size ellipseSizeThin = new Size(1, 2);
                                Brush redbrushThin = new SolidBrush(Color.FromArgb(InkFlow, Pen_Color.R, Pen_Color.G, Pen_Color.B));
                                Point ellipseTopLeftThin;
                                Random raThin = new Random();
                                int widthThin;
                                int hightThin;
                                Graphics grfxThin = CreateGraphics();
                                Rectangle ellipseAreaThin;
                                for (int i = 0; i < 15; i++)
                                {
                                    widthThin = raThin.Next(pt.X, pt.X + 0);
                                    hightThin = raThin.Next(pt.Y, pt.Y + 0);
                                    ellipseTopLeftThin = new Point(widthThin, hightThin);
                                    ellipseAreaThin = new Rectangle(ellipseTopLeftThin, ellipseSizeThin);
                                    grfxThin.FillEllipse(redbrushThin, ellipseAreaThin);
                                    m_grfxBm.FillEllipse(redbrushThin, ellipseAreaThin);
                                }
                                for (int k = 0; k < 25; k++)
                                {
                                    widthThin = raThin.Next(pt.X - 0, pt.X + 4);
                                    hightThin = raThin.Next(pt.Y - 1, pt.Y + 2);
                                    ellipseTopLeftThin = new Point(widthThin, hightThin);
                                    ellipseAreaThin = new Rectangle(ellipseTopLeftThin, ellipseSizeThin);
                                    grfxThin.FillEllipse(redbrushThin, ellipseAreaThin);
                                    m_grfxBm.FillEllipse(redbrushThin, ellipseAreaThin);
                                }
                                for (int j = 0; j < 35; j++)
                                {
                                    widthThin = raThin.Next(pt.X - 3, pt.X + 7);
                                    hightThin = raThin.Next(pt.Y - 4, pt.Y + 4);
                                    ellipseTopLeftThin = new Point(widthThin, hightThin);
                                    ellipseAreaThin = new Rectangle(ellipseTopLeftThin, ellipseSizeThin);
                                    grfxThin.FillEllipse(redbrushThin, ellipseAreaThin);
                                    m_grfxBm.FillEllipse(redbrushThin, ellipseAreaThin);
                                }

                                m_ptLineStart.X = m_ptLinePrev.X = pt.X;
                                m_ptLineStart.Y = m_ptLinePrev.Y = pt.Y;
                                m_bMouseDown = true;
                                break;
                            #endregion ϸ����
                            #region �е�����
                            case CrayonWidth.Middle:
                                Size ellipseSizeMiddle = new Size(1, 2);
                                Brush redbrushMiddle = new SolidBrush(Color.FromArgb(InkFlow, Pen_Color.R, Pen_Color.G, Pen_Color.B));
                                Point ellipseTopLeftMiddle;
                                Random raMiddle = new Random();
                                int widthMiddle;
                                int hightMiddle;
                                Graphics grfxMiddle = CreateGraphics();
                                Rectangle ellipseAreaMiddle;
                                for (int i = 0; i < 35; i++)
                                {
                                    widthMiddle = raMiddle.Next(pt.X, pt.X + 5);
                                    hightMiddle = raMiddle.Next(pt.Y, pt.Y + 5);
                                    ellipseTopLeftMiddle = new Point(widthMiddle, hightMiddle);
                                    ellipseAreaMiddle = new Rectangle(ellipseTopLeftMiddle, ellipseSizeMiddle);
                                    grfxMiddle.FillEllipse(redbrushMiddle, ellipseAreaMiddle);
                                    m_grfxBm.FillEllipse(redbrushMiddle, ellipseAreaMiddle);
                                }
                                for (int k = 0; k < 45; k++)
                                {
                                    widthMiddle = raMiddle.Next(pt.X - 2, pt.X + 12);
                                    hightMiddle = raMiddle.Next(pt.Y - 3, pt.Y + 10);
                                    ellipseTopLeftMiddle = new Point(widthMiddle, hightMiddle);
                                    ellipseAreaMiddle = new Rectangle(ellipseTopLeftMiddle, ellipseSizeMiddle);
                                    grfxMiddle.FillEllipse(redbrushMiddle, ellipseAreaMiddle);
                                    m_grfxBm.FillEllipse(redbrushMiddle, ellipseAreaMiddle);
                                }
                                for (int j = 0; j < 55; j++)
                                {
                                    widthMiddle = raMiddle.Next(pt.X - 6, pt.X + 15);
                                    hightMiddle = raMiddle.Next(pt.Y - 7, pt.Y + 12);
                                    ellipseTopLeftMiddle = new Point(widthMiddle, hightMiddle);
                                    ellipseAreaMiddle = new Rectangle(ellipseTopLeftMiddle, ellipseSizeMiddle);
                                    grfxMiddle.FillEllipse(redbrushMiddle, ellipseAreaMiddle);
                                    m_grfxBm.FillEllipse(redbrushMiddle, ellipseAreaMiddle);
                                }

                                m_ptLineStart.X = m_ptLinePrev.X = pt.X;
                                m_ptLineStart.Y = m_ptLinePrev.Y = pt.Y;
                                m_bMouseDown = true;
                                break;
                            #endregion �е�����
                            #region ������
                            case CrayonWidth.Thick:
                                Size ellipseSizeThick = new Size(1, 2);
                                Brush redbrushThick = new SolidBrush(Color.FromArgb(InkFlow, Pen_Color.R, Pen_Color.G, Pen_Color.B));
                                Point ellipseTopLeftThick;
                                Random raThick = new Random();
                                int widthThick;
                                int hightThick;
                                Graphics grfxThick = CreateGraphics();
                                Rectangle ellipseAreaThick;
                                for (int i = 0; i < 35; i++)
                                {
                                    widthThick = raThick.Next(pt.X, pt.X + 10);
                                    hightThick = raThick.Next(pt.Y, pt.Y + 10);
                                    ellipseTopLeftThick = new Point(widthThick, hightThick);
                                    ellipseAreaThick = new Rectangle(ellipseTopLeftThick, ellipseSizeThick);
                                    grfxThick.FillEllipse(redbrushThick, ellipseAreaThick);
                                    m_grfxBm.FillEllipse(redbrushThick, ellipseAreaThick);
                                }
                                for (int k = 0; k < 55; k++)
                                {
                                    widthThick = raThick.Next(pt.X - 4, pt.X + 24);
                                    hightThick = raThick.Next(pt.Y - 6, pt.Y + 20);
                                    ellipseTopLeftThick = new Point(widthThick, hightThick);
                                    ellipseAreaThick = new Rectangle(ellipseTopLeftThick, ellipseSizeThick);
                                    grfxThick.FillEllipse(redbrushThick, ellipseAreaThick);
                                    m_grfxBm.FillEllipse(redbrushThick, ellipseAreaThick);
                                }
                                for (int j = 0; j < 65; j++)
                                {
                                    widthThick = raThick.Next(pt.X - 12, pt.X + 30);
                                    hightThick = raThick.Next(pt.Y - 14, pt.Y + 24);
                                    ellipseTopLeftThick = new Point(widthThick, hightThick);
                                    ellipseAreaThick = new Rectangle(ellipseTopLeftThick, ellipseSizeThick);
                                    grfxThick.FillEllipse(redbrushThick, ellipseAreaThick);
                                    m_grfxBm.FillEllipse(redbrushThick, ellipseAreaThick);
                                }

                                m_ptLineStart.X = m_ptLinePrev.X = pt.X;
                                m_ptLineStart.Y = m_ptLinePrev.Y = pt.Y;
                                m_bMouseDown = true;
                                break;
                            #endregion ������
                            #region Ĭ������
                            default:
                                break;
                            #endregion Ĭ������
                        }
                    }
                    break;
                #endregion ���ʹ���
                #region ��������
                case WHITEBOARD_DRAW_MODE.enModeTexturePen:   //��������
                    m_ptLineEnd.X = pt.X;
                    m_ptLineEnd.Y = pt.Y;
                    if (m_bMouseDown)
                    {
                        Pen brickWidePen = new Pen(brushchinesepen, PenSize);
                        Graphics grfx = CreateGraphics();
                        grfx.DrawLine(brickWidePen, m_ptLinePrev, m_ptLineEnd);
                        grfx.FillEllipse(brushchinesepen, pt.X - (PenSize / 2), pt.Y - (PenSize / 2), PenSize, PenSize);
                        grfx.Dispose();
                        //��bitmap�������
                        m_grfxBm.DrawLine(brickWidePen, m_ptLinePrev, m_ptLineEnd);
                        m_grfxBm.FillEllipse(brushchinesepen, pt.X - (PenSize / 2), pt.Y - (PenSize / 2), PenSize, PenSize);
                        brickWidePen.Dispose();
                    }
                    m_ptLinePrev = m_ptLineEnd;
                    break;
                #endregion ��������
                #region ˮī������
                case WHITEBOARD_DRAW_MODE.enModeInkPainting:   //ˮī������
                    if (m_bMouseDown)
                    {
                        Graphics grfx = CreateGraphics();
                        GraphicsPath path = new GraphicsPath();
                        path.AddEllipse(pt.X, pt.Y, PenSize, PenSize);
                        PathGradientBrush pthGrBrush = new PathGradientBrush(path);
                        pthGrBrush.CenterColor = Color.FromArgb(255, 
                            (int)(Pen_Color.R - Pen_Color.R * 0.345), 
                            (int)(Pen_Color.G - Pen_Color.G * 0.345), 
                            (int)(Pen_Color.B - Pen_Color.B * 0.345));    //��ɫ,͸����255����͸����
                        Color[] colors = { Color.FromArgb(0, Pen_Color.R, Pen_Color.G, Pen_Color.B) };  //��ɫ,͸����0����ȫ͸����
                        pthGrBrush.SurroundColors = colors;
                        grfx.FillEllipse(pthGrBrush, pt.X, pt.Y, PenSize, PenSize);
                        grfx.Dispose();
                        m_grfxBm.FillEllipse(pthGrBrush, pt.X, pt.Y, PenSize, PenSize);
                    }
                    break;
                #endregion ˮī������
                #region ����ë��
                case WHITEBOARD_DRAW_MODE.enModeChineseBrush:   //����ë��
                    m_ptLineEnd.X = pt.X;
                    m_ptLineEnd.Y = pt.Y;
                    if (m_bMouseDown)
                    {
                        Pen ChinesePn = new Pen(Color.FromArgb(InkFlow, Pen_Color.R, Pen_Color.G, Pen_Color.B), PenSize);
                        Brush ChineseBrush = new SolidBrush(Color.FromArgb(InkFlow, Pen_Color.R, Pen_Color.G, Pen_Color.B));
                        Graphics grfx = CreateGraphics();
                        grfx.DrawLine(ChinesePn, m_ptLinePrev, m_ptLineEnd);
                        grfx.FillEllipse(ChineseBrush, pt.X - (PenSize / 2), pt.Y - (PenSize / 2), PenSize, PenSize);
                        grfx.Dispose();

                        m_grfxBm.DrawLine(ChinesePn, m_ptLinePrev, m_ptLineEnd);
                        m_grfxBm.FillEllipse(ChineseBrush, pt.X - (PenSize / 2), pt.Y - (PenSize / 2), PenSize, PenSize);
                    }
                    m_ptLinePrev = m_ptLineEnd;
                    break;
                #endregion ����ë��
                #region ��Ƥ������
                case WHITEBOARD_DRAW_MODE.enModeEraser: //��Ƥ������
                    m_ptLineEnd.X = pt.X;
                    m_ptLineEnd.Y = pt.Y;
                    if (m_bMouseDown)
                    {
                        Brush EraserBrush = new SolidBrush(m_ColorBack);
                        Graphics grfx = CreateGraphics();
                        switch (erasertype) //��Ƥ������
                        {
                            #region ��Բ����Ƥ��
                            case EraserType.EraserEllipse:  //��Բ����Ƥ��
                                grfx.FillEllipse(EraserBrush, pt.X - (PenSize / 2), pt.Y - (PenSize / 2), PenSize, PenSize);
                                grfx.Dispose();
                                m_grfxBm.FillEllipse(EraserBrush, pt.X - (PenSize / 2), pt.Y - (PenSize / 2), PenSize, PenSize);
                                break;
                            #endregion ��Բ����Ƥ��
                            #region ������Ƥ��
                            case EraserType.EraserRectangle: //������Ƥ��
                                grfx.FillRectangle(EraserBrush, pt.X - (PenSize / 2), pt.Y - (PenSize / 2), PenSize, PenSize);
                                grfx.Dispose();
                                m_grfxBm.FillRectangle(EraserBrush, pt.X - (PenSize / 2), pt.Y - (PenSize / 2), PenSize, PenSize);
                                break;
                            #endregion ������Ƥ��
                            #region Ĭ����Ƥ��
                            default:
                                break;
                            #endregion Ĭ����Ƥ��
                        }
                    }
                    m_ptLinePrev = m_ptLineEnd;
                    break;
                #endregion ��Ƥ������
                #region Ĭ��
                default:
					break;
                #endregion Ĭ��
            }
		}

        //��걻̧��ʱ��Ķ���
		public void WhenMouseUp(Point pt)
		{
			switch (m_enDrawMode)
            {
                #region ��깤��
                case WHITEBOARD_DRAW_MODE.enModePoint:
                    ControlPaint.DrawReversibleFrame(this.RectangleToScreen(
                        DrawRectangle.GetNormalizedRectangle(m_ptLineStart, m_ptLineEnd)),
                        Color.Black, FrameStyle.Dashed);
                    m_bMouseDown = false;
                    break;
                #endregion ��깤��
                #region Ǧ�ʡ����Ρ���Բ
                case WHITEBOARD_DRAW_MODE.enModePencil: //Ǧ�ʹ���
				case WHITEBOARD_DRAW_MODE.enModeRect:   //���ι���
				case WHITEBOARD_DRAW_MODE.enModeEllipse://��Բ����
					m_bMouseDown = false;
					break;
                #endregion Ǧ�ʡ����Ρ���Բ
                #region ����ͼƬ
                case WHITEBOARD_DRAW_MODE.enModeInsertPic://����ͼƬ
                    ControlPaint.DrawReversibleFrame(
                        this.RectangleToScreen(DrawRectangle.GetNormalizedRectangle(m_ptLineStart, m_ptLineEnd)), 
                        Color.Black, FrameStyle.Dashed);
                    m_bMouseDown = false;
                    int picwidth = System.Math.Abs(m_ptLineEnd.X - m_ptLineStart.X);    //�û��Զ���ͼƬ�Ŀ���
                    int picheight = System.Math.Abs(m_ptLineEnd.Y - m_ptLineStart.Y);   //�û��Զ���ͼƬ�ĸ߶�
                    if (picwidth > 0 && picheight > 0 && caninsert)
                    {
                        StartInsertPic(m_ptLineStart.X, m_ptLineStart.Y, picwidth, picheight);  //��ʼ����ͼƬ
                        caninsert = false;  //���ɼ�������ͼƬ
                    }
                    break;
                #endregion ����ͼƬ
                #region ֱ�߹���
                case WHITEBOARD_DRAW_MODE.enModeStraightline:
                    m_bMouseDown = false;
                    break;
                #endregion ֱ�߹���
                #region ���ʹ���
                case WHITEBOARD_DRAW_MODE.enModeCrayon:   //���ʹ���
                    m_bMouseDown = false;
                    break;
                #endregion ���ʹ���
                #region ��������
                case WHITEBOARD_DRAW_MODE.enModeTexturePen:   //��������
                    m_bMouseDown = false;
                    break;
                #endregion ��������
                #region ˮī������
                case WHITEBOARD_DRAW_MODE.enModeInkPainting:   //ˮī������
                    m_bMouseDown = false;
                    break;
                #endregion ˮī������
                #region ����ë��
                case WHITEBOARD_DRAW_MODE.enModeChineseBrush:   //����ë��
                    m_bMouseDown = false;
                    break;
                #endregion ����ë��
                #region ��Ƥ������
                case WHITEBOARD_DRAW_MODE.enModeEraser: //��Ƥ������
                    m_bMouseDown = false;
                    break;
                #endregion ��Ƥ������
                #region Ĭ��
                default:
					break;
                #endregion Ĭ��
            }
        }

        #endregion ��걻���¡��˶���̧��Ķ���

        #region ���巽������

        //ͼƬ����
        public void StartInsertPic(int StartX, int StartY, int picwidth, int picheight)
        {
            try
            {
                OpenFileDialog OpenJpgDialog = new OpenFileDialog();
                OpenJpgDialog.Title = "ѡ������Ҫ��ͼƬ";
                OpenJpgDialog.Filter = "jpg files (*.jpg)|*.jpg|bmp files (*.bmp)|*.bmp|All files (*.*)|*.*";
                if (OpenJpgDialog.ShowDialog() == DialogResult.OK)
                {
                    piccy = Image.FromFile(OpenJpgDialog.FileName);
                    piccyBounds = new Point[3];
                    piccyBounds[0] = new Point(StartX, StartY); //top left
                    piccyBounds[1] = new Point(StartX + picwidth, StartY);  //top right
                    piccyBounds[2] = new Point(StartX, StartY + picheight); //bottom left

                    Graphics grfx = CreateGraphics();
                    grfx.DrawImage(piccy, piccyBounds);
                    grfx.Dispose();
                    m_grfxBm.DrawImage(piccy, piccyBounds);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        //���ƶ�ͼƬ��Ƕ��
        public void InsertMovePic(int StartX, int StartY, int picwidth, int picheight, Image movepic)
        {
            try
            {
                //MessageBox.Show(StartX.ToString() + " " + StartY.ToString() + "  " + picwidth.ToString() + "  " + picheight.ToString());
                piccyBounds = new Point[3];
                piccyBounds[0] = new Point(StartX, StartY); //top left
                piccyBounds[1] = new Point(StartX + picwidth, StartY);  //top right
                piccyBounds[2] = new Point(StartX, StartY + picheight); //bottom left

                Graphics grfx = CreateGraphics();
                grfx.DrawImage(movepic, piccyBounds);
                grfx.Dispose();
                m_grfxBm.DrawImage(movepic, piccyBounds);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        //�任��������
        public void ChangeTexturePen(HatchStyle hatchstyle,Color maincolor,Color insertcolor)
        {
            brushchinesepen = new HatchBrush(hatchstyle, maincolor, insertcolor);
        }

        //�½�����
        public void NewWhiteBoard(int BoardX, int BoardY, int BoardWidth, int BoardHeight)
        {
            //�������ʣ����ʵ���ɫ��
            SolidBrush BkgBrush = new SolidBrush(m_ColorBack);
            //���þ���
            Graphics grfx = CreateGraphics();
            grfx.FillRectangle(BkgBrush, BoardX, BoardY, BoardWidth, BoardHeight);
            grfx.Dispose();
            //�����������λͼ
            m_grfxBm.FillRectangle(BkgBrush, BoardX, BoardY, BoardWidth, BoardHeight);
        }

        #endregion ���巽������

        #region ���������֪�Ƿ�ʹ�ã����������
        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.ResumeLayout(false);
        }
        #endregion ���������֪�Ƿ�ʹ�ã����������
    }
}