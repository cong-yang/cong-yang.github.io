﻿namespace KidSparkPainting
{
    partial class FlashPlayer
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FlashPlayer));
            this.panelMain = new System.Windows.Forms.Panel();
            this.AxFlashPlayer = new AxShockwaveFlashObjects.AxShockwaveFlash();
            this.panelOperate = new System.Windows.Forms.Panel();
            this.ShowTools = new System.Windows.Forms.PictureBox();
            this.Delete = new System.Windows.Forms.PictureBox();
            this.HidePanel = new System.Windows.Forms.PictureBox();
            this.Stop = new System.Windows.Forms.PictureBox();
            this.Play = new System.Windows.Forms.PictureBox();
            this.mFlashPlayerTimer = new System.Windows.Forms.Timer(this.components);
            this.panelMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AxFlashPlayer)).BeginInit();
            this.panelOperate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ShowTools)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Delete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HidePanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Stop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Play)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMain
            // 
            this.panelMain.BackColor = System.Drawing.Color.Transparent;
            this.panelMain.Controls.Add(this.AxFlashPlayer);
            this.panelMain.Controls.Add(this.panelOperate);
            this.panelMain.Location = new System.Drawing.Point(10, 10);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(402, 318);
            this.panelMain.TabIndex = 0;
            // 
            // AxFlashPlayer
            // 
            this.AxFlashPlayer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AxFlashPlayer.Enabled = true;
            this.AxFlashPlayer.Location = new System.Drawing.Point(0, 0);
            this.AxFlashPlayer.Name = "AxFlashPlayer";
            this.AxFlashPlayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("AxFlashPlayer.OcxState")));
            this.AxFlashPlayer.Size = new System.Drawing.Size(402, 287);
            this.AxFlashPlayer.TabIndex = 2;
            // 
            // panelOperate
            // 
            this.panelOperate.BackColor = System.Drawing.Color.Transparent;
            this.panelOperate.Controls.Add(this.ShowTools);
            this.panelOperate.Controls.Add(this.Delete);
            this.panelOperate.Controls.Add(this.HidePanel);
            this.panelOperate.Controls.Add(this.Stop);
            this.panelOperate.Controls.Add(this.Play);
            this.panelOperate.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelOperate.Location = new System.Drawing.Point(0, 287);
            this.panelOperate.Name = "panelOperate";
            this.panelOperate.Size = new System.Drawing.Size(402, 31);
            this.panelOperate.TabIndex = 1;
            // 
            // ShowTools
            // 
            this.ShowTools.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ShowTools.Dock = System.Windows.Forms.DockStyle.Right;
            this.ShowTools.Image = global::KidSparkPainting.Properties.Resources.Triangle;
            this.ShowTools.Location = new System.Drawing.Point(335, 0);
            this.ShowTools.Name = "ShowTools";
            this.ShowTools.Size = new System.Drawing.Size(13, 31);
            this.ShowTools.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ShowTools.TabIndex = 15;
            this.ShowTools.TabStop = false;
            this.ShowTools.Visible = false;
            this.ShowTools.Click += new System.EventHandler(this.ShowTools_Click);
            // 
            // Delete
            // 
            this.Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Delete.Dock = System.Windows.Forms.DockStyle.Right;
            this.Delete.Image = global::KidSparkPainting.Properties.Resources.Exit1;
            this.Delete.Location = new System.Drawing.Point(348, 0);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(27, 31);
            this.Delete.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Delete.TabIndex = 14;
            this.Delete.TabStop = false;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // HidePanel
            // 
            this.HidePanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.HidePanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.HidePanel.Image = global::KidSparkPainting.Properties.Resources.HIDETOOLS;
            this.HidePanel.Location = new System.Drawing.Point(375, 0);
            this.HidePanel.Name = "HidePanel";
            this.HidePanel.Size = new System.Drawing.Size(27, 31);
            this.HidePanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.HidePanel.TabIndex = 13;
            this.HidePanel.TabStop = false;
            this.HidePanel.Click += new System.EventHandler(this.HidePanel_Click);
            // 
            // Stop
            // 
            this.Stop.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Stop.Dock = System.Windows.Forms.DockStyle.Left;
            this.Stop.Image = global::KidSparkPainting.Properties.Resources.STOP;
            this.Stop.Location = new System.Drawing.Point(29, 0);
            this.Stop.Name = "Stop";
            this.Stop.Size = new System.Drawing.Size(29, 31);
            this.Stop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Stop.TabIndex = 12;
            this.Stop.TabStop = false;
            this.Stop.Click += new System.EventHandler(this.Stop_Click);
            // 
            // Play
            // 
            this.Play.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Play.Dock = System.Windows.Forms.DockStyle.Left;
            this.Play.Image = global::KidSparkPainting.Properties.Resources.PLAY;
            this.Play.Location = new System.Drawing.Point(0, 0);
            this.Play.Name = "Play";
            this.Play.Size = new System.Drawing.Size(29, 31);
            this.Play.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Play.TabIndex = 11;
            this.Play.TabStop = false;
            this.Play.Click += new System.EventHandler(this.Play_Click);
            // 
            // FlashPlayer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(127)))), ((int)(((byte)(228)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.panelMain);
            this.Name = "FlashPlayer";
            this.Size = new System.Drawing.Size(422, 338);
            this.panelMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AxFlashPlayer)).EndInit();
            this.panelOperate.ResumeLayout(false);
            this.panelOperate.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ShowTools)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Delete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HidePanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Stop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Play)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Panel panelOperate;
        private System.Windows.Forms.Timer mFlashPlayerTimer;
        private System.Windows.Forms.PictureBox Play;
        private System.Windows.Forms.PictureBox Stop;
        private System.Windows.Forms.PictureBox HidePanel;
        private System.Windows.Forms.PictureBox Delete;
        private AxShockwaveFlashObjects.AxShockwaveFlash AxFlashPlayer;
        private System.Windows.Forms.PictureBox ShowTools;
    }
}
