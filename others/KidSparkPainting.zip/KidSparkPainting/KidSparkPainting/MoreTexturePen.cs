﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace KidSparkPainting
{
    public partial class MoreTexturePen : Form
    {
        public MoreTexturePen()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;    //窗口位于屏幕的中央位置
            this.MaximizeBox = false;   //无最大化
            this.MinimizeBox = false;   //无最小化
        }

        private HatchStyle TexturePenStyle;

        #region 变换和预览
        private void radioButtonBackwardDiagonal_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.BackwardDiagonal;
            LabelName.Text = "BackwardDiagonal";
            TexturePenStyle = HatchStyle.BackwardDiagonal;
        }

        private void radioButtonDarkDownwardDiagonal_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.DarkDownwardDiagonal;
            LabelName.Text = "DarkDownwardDiagonal";
            TexturePenStyle = HatchStyle.DarkDownwardDiagonal;
        }

        private void radioButtonDarkHorizontal_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.DarkHorizontal;
            LabelName.Text = "DarkHorizontal";
            TexturePenStyle = HatchStyle.DarkHorizontal;
        }

        private void radioButtonDarkUpwardDiagonal_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.DarkUpwardDiagonal;
            LabelName.Text = "DarkUpwardDiagonal";
            TexturePenStyle = HatchStyle.DarkUpwardDiagonal;
        }

        private void radioButtonDarkVertical_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.DarkVertical;
            LabelName.Text = "DarkVertical";
            TexturePenStyle = HatchStyle.DarkVertical;
        }

        private void radioButtonDashedDownwardDiagonal_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.DashedDownwardDiagonal;
            LabelName.Text = "DashedDownwardDiagonal";
            TexturePenStyle = HatchStyle.DashedDownwardDiagonal;
        }

        private void radioButtonDashedHorizontal_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.DashedHorizontal;
            LabelName.Text = "DashedHorizontal";
            TexturePenStyle = HatchStyle.DashedHorizontal;
        }

        private void radioButtonDashedUpwardDiagonal_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.DashedUpwardDiagonal;
            LabelName.Text = "DashedUpwardDiagonal";
            TexturePenStyle = HatchStyle.DashedUpwardDiagonal;
        }

        private void radioButtonDashedVertical_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.DashedVertical;
            LabelName.Text = "DashedVertical";
            TexturePenStyle = HatchStyle.DashedVertical;
        }

        private void radioButtonDiagonalBrick_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.DiagonalBrick;
            LabelName.Text = "DiagonalBrick";
            TexturePenStyle = HatchStyle.DiagonalBrick;
        }

        private void radioButtonDiagonalCross_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.DiagonalCross;
            LabelName.Text = "DiagonalCross";
            TexturePenStyle = HatchStyle.DiagonalCross;
        }

        private void radioButtonDivot_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Divot;
            LabelName.Text = "Divot";
            TexturePenStyle = HatchStyle.Divot;
        }

        private void radioButtonDottedDiamond_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.DottedDiamond;
            LabelName.Text = "DottedDiamond";
            TexturePenStyle = HatchStyle.DottedDiamond;
        }

        private void radioButtonDottedGrid_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.DottedGrid;
            LabelName.Text = "DottedGrid";
            TexturePenStyle = HatchStyle.DottedGrid;
        }

        private void radioButtonForwardDiagonal_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.ForwardDiagonal;
            LabelName.Text = "ForwardDiagonal";
            TexturePenStyle = HatchStyle.ForwardDiagonal;
        }

        private void radioButtonHorizontal_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Horizontal;
            LabelName.Text = "Horizontal";
            TexturePenStyle = HatchStyle.Horizontal;
        }

        private void radioButtonHorizontalBrick_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.HorizontalBrick;
            LabelName.Text = "HorizontalBrick";
            TexturePenStyle = HatchStyle.HorizontalBrick;
        }

        private void radioButtonLargeCheckerBoard_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.LargeCheckerBoard;
            LabelName.Text = "LargeCheckerBoard";
            TexturePenStyle = HatchStyle.LargeCheckerBoard;
        }

        private void radioButtonLargeConfetti_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.LargeConfetti;
            LabelName.Text = "LargeConfetti";
            TexturePenStyle = HatchStyle.LargeConfetti;
        }

        private void radioButtonLargeGrid_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.LargeGrid;
            LabelName.Text = "LargeGrid";
            TexturePenStyle = HatchStyle.LargeGrid;
        }

        private void radioButtonLightDownwardDiagonal_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.LightDownwardDiagonal;
            LabelName.Text = "LightDownwardDiagonal";
            TexturePenStyle = HatchStyle.LightDownwardDiagonal;
        }

        private void radioButtonLightHorizontal_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.LightHorizontal;
            LabelName.Text = "LightHorizontal";
            TexturePenStyle = HatchStyle.LightHorizontal;
        }

        private void radioButtonLightVertical_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.LightVertical;
            LabelName.Text = "LightVertical";
            TexturePenStyle = HatchStyle.LightVertical;
        }

        private void radioButtonNarrowHorizontal_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.NarrowHorizontal;
            LabelName.Text = "NarrowHorizontal";
            TexturePenStyle = HatchStyle.NarrowHorizontal;
        }

        private void radioButtonNarrowVertical_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.NarrowVertical;
            LabelName.Text = "NarrowVertical";
            TexturePenStyle = HatchStyle.NarrowVertical;
        }

        private void radioButtonOutlinedDiamond_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.OutlinedDiamond;
            LabelName.Text = "OutlinedDiamond";
            TexturePenStyle = HatchStyle.OutlinedDiamond;
        }

        private void radioButtonPercent05_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Percent05;
            LabelName.Text = "Percent05";
            TexturePenStyle = HatchStyle.Percent05;
        }

        private void radioButtonPercent10_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Percent10;
            LabelName.Text = "Percent10";
            TexturePenStyle = HatchStyle.Percent10;
        }

        private void radioButtonPercent20_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Percent20;
            LabelName.Text = "Percent20";
            TexturePenStyle = HatchStyle.Percent20;
        }

        private void radioButtonPercent25_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Percent25;
            LabelName.Text = "Percent25";
            TexturePenStyle = HatchStyle.Percent25;
        }

        private void radioButtonPercent30_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Percent30;
            LabelName.Text = "Percent30";
            TexturePenStyle = HatchStyle.Percent30;
        }

        private void radioButtonPercent40_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Percent40;
            LabelName.Text = "Percent40";
            TexturePenStyle = HatchStyle.Percent40;
        }

        private void radioButtonPercent50_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Percent50;
            LabelName.Text = "Percent50";
            TexturePenStyle = HatchStyle.Percent50;
        }

        private void radioButtonPercent60_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Percent60;
            LabelName.Text = "Percent60";
            TexturePenStyle = HatchStyle.Percent60;
        }

        private void radioButtonPercent70_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Percent70;
            LabelName.Text = "Percent70";
            TexturePenStyle = HatchStyle.Percent70;
        }

        private void radioButtonPercent75_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Percent75;
            LabelName.Text = "Percent75";
            TexturePenStyle = HatchStyle.Percent75;
        }

        private void radioButtonPercent80_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Percent80;
            LabelName.Text = "Percent80";
            TexturePenStyle = HatchStyle.Percent80;
        }

        private void radioButtonPercent90_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Percent90;
            LabelName.Text = "Percent90";
            TexturePenStyle = HatchStyle.Percent90;
        }

        private void radioButtonPlaid_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Plaid;
            LabelName.Text = "Plaid";
            TexturePenStyle = HatchStyle.Plaid;
        }

        private void radioButtonShingle_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Shingle;
            LabelName.Text = "Shingle";
            TexturePenStyle = HatchStyle.Shingle;
        }

        private void radioButtonSmallCheckerBoard_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.SmallCheckerBoard;
            LabelName.Text = "SmallCheckerBoard";
            TexturePenStyle = HatchStyle.SmallCheckerBoard;
        }

        private void radioButtonSmallConfetti_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.SmallConfetti;
            LabelName.Text = "SmallConfetti";
            TexturePenStyle = HatchStyle.SmallConfetti;
        }

        private void radioButtonSmallGrid_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.SmallGrid;
            LabelName.Text = "SmallGrid";
            TexturePenStyle = HatchStyle.SmallGrid;
        }

        private void radioButtonSolidDiamond_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.SolidDiamond;
            LabelName.Text = "SolidDiamond";
            TexturePenStyle = HatchStyle.SolidDiamond;
        }

        private void radioButtonSphere_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Sphere;
            LabelName.Text = "Sphere";
            TexturePenStyle = HatchStyle.Sphere;
        }

        private void radioButtonTrellis_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Trellis;
            LabelName.Text = "Trellis";
            TexturePenStyle = HatchStyle.Trellis;
        }

        private void radioButtonVertical_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Vertical;
            LabelName.Text = "Vertical";
            TexturePenStyle = HatchStyle.Vertical;
        }

        private void radioButtonWave_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Wave;
            LabelName.Text = "Wave";
            TexturePenStyle = HatchStyle.Wave;
        }

        private void radioButtonWeave_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.Weave;
            LabelName.Text = "Weave";
            TexturePenStyle = HatchStyle.Weave;
        }

        private void radioButtonWideDownwardDiagonal_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.WideDownwardDiagonal;
            LabelName.Text = "WideDownwardDiagonal";
            TexturePenStyle = HatchStyle.WideDownwardDiagonal;
        }

        private void radioButtonWideUpwardDiagonal_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.WideUpwardDiagonal;
            LabelName.Text = "WideUpwardDiagonal";
            TexturePenStyle = HatchStyle.WideUpwardDiagonal;
        }

        private void radioButtonZipZag_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.ZipZag;
            LabelName.Text = "ZipZag";
            TexturePenStyle = HatchStyle.ZigZag;
        }
        #endregion 变换和预览

        //确认
        private void ButtonOk_Click(object sender, EventArgs e)
        {
            WinForm winform = (WinForm)this.Owner;
            winform.DrawPlace.m_enDrawMode = DrawAreaCtrl.WHITEBOARD_DRAW_MODE.enModeTexturePen;
            winform.DrawPlace.TexturePen_Hatchstyle = TexturePenStyle;
            winform.DrawPlace.ChangeTexturePen(TexturePenStyle, winform.DrawPlace.TexturePen_MainColor,winform.DrawPlace.TexturePen_InsertColor);
            this.Close();
        }

        //取消
        private void ButtonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
