﻿namespace KidSparkPainting
{
    partial class WinForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WinForm));
            this.Tab_Imgbase = new System.Windows.Forms.TabPage();
            this.EraserRectangle = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.EraserEllipse = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.NotFill = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.Fill = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.ShapePenPriview = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.tabControlLeft = new System.Windows.Forms.TabControl();
            this.Tab_Property = new System.Windows.Forms.TabPage();
            this.panelEraser = new System.Windows.Forms.Panel();
            this.labelEraser = new System.Windows.Forms.Label();
            this.panelEraserIn = new System.Windows.Forms.Panel();
            this.shapeContainer3 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.panelDrawFill = new System.Windows.Forms.Panel();
            this.panelDrawFillIn = new System.Windows.Forms.Panel();
            this.labelFill = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.shapeContainer2 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.panelTexturePen = new System.Windows.Forms.Panel();
            this.panelTexturePenIn = new System.Windows.Forms.Panel();
            this.labelwenlihuabi = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelTextureMain = new System.Windows.Forms.Label();
            this.labelTextureInsert = new System.Windows.Forms.Label();
            this.labelTexturePenMore = new System.Windows.Forms.Label();
            this.panellabi = new System.Windows.Forms.Panel();
            this.panellabiin = new System.Windows.Forms.Panel();
            this.labellabi = new System.Windows.Forms.Label();
            this.pictureBoxlabicu = new System.Windows.Forms.PictureBox();
            this.pictureBoxLabizhong = new System.Windows.Forms.PictureBox();
            this.pictureBoxLabixi = new System.Windows.Forms.PictureBox();
            this.panelPenColor = new System.Windows.Forms.Panel();
            this.labelPenColor = new System.Windows.Forms.Label();
            this.panelInkFlow = new System.Windows.Forms.Panel();
            this.labelInkFlow = new System.Windows.Forms.Label();
            this.trackBarInkFlow = new System.Windows.Forms.TrackBar();
            this.panelPenWidth = new System.Windows.Forms.Panel();
            this.labelPenWidth = new System.Windows.Forms.Label();
            this.trackBarPenWidth = new System.Windows.Forms.TrackBar();
            this.panelpriview = new System.Windows.Forms.Panel();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.Tab_DrawedBoard = new System.Windows.Forms.TabPage();
            this.skinEngine = new Sunisoft.IrisSkin.SkinEngine(((System.ComponentModel.Component)(this)));
            this.toolStripTools = new System.Windows.Forms.ToolStrip();
            this.ButtonOpen = new System.Windows.Forms.ToolStripButton();
            this.ButtonNew = new System.Windows.Forms.ToolStripButton();
            this.ButtonSaveAs = new System.Windows.Forms.ToolStripButton();
            this.ButtonPoint = new System.Windows.Forms.ToolStripButton();
            this.ButtonDrawLine = new System.Windows.Forms.ToolStripButton();
            this.ButtonRec = new System.Windows.Forms.ToolStripButton();
            this.ButtonEllipse = new System.Windows.Forms.ToolStripButton();
            this.ButtonClean = new System.Windows.Forms.ToolStripButton();
            this.ButtonPic = new System.Windows.Forms.ToolStripButton();
            this.ButtonMoviePic = new System.Windows.Forms.ToolStripButton();
            this.ButtonSLine = new System.Windows.Forms.ToolStripButton();
            this.ButtonCrayon = new System.Windows.Forms.ToolStripButton();
            this.ButtonTexturePen = new System.Windows.Forms.ToolStripButton();
            this.ButtonInkPainting = new System.Windows.Forms.ToolStripButton();
            this.ButtonChineseBrush = new System.Windows.Forms.ToolStripButton();
            this.ButtonInsVedio = new System.Windows.Forms.ToolStripButton();
            this.ButtonInsFlash = new System.Windows.Forms.ToolStripButton();
            this.ButtonOpenPPT = new System.Windows.Forms.ToolStripButton();
            this.ButtonOpenPDF = new System.Windows.Forms.ToolStripButton();
            this.ButtonExit = new System.Windows.Forms.ToolStripButton();
            this.ButtonHelp = new System.Windows.Forms.ToolStripButton();
            this.ButtonSharePalette = new System.Windows.Forms.ToolStripButton();
            this.ButtonLefTools = new System.Windows.Forms.ToolStripButton();
            this.ButtonCamera = new System.Windows.Forms.ToolStripButton();
            this.DrawPlace = new KidSparkPainting.DrawAreaCtrl();
            this.comboBoxColorPickerFillColor = new KidSparkPainting.ColorPicker.ComboBoxColorPicker();
            this.TexturePenColorPickerMain = new KidSparkPainting.ColorPicker.ComboBoxColorPicker();
            this.TexturePenColorPickerInsert = new KidSparkPainting.ColorPicker.ComboBoxColorPicker();
            this.ColorPickerPenColor = new KidSparkPainting.ColorPicker.OfficeColorPicker();
            this.tabControlLeft.SuspendLayout();
            this.Tab_Property.SuspendLayout();
            this.panelEraser.SuspendLayout();
            this.panelEraserIn.SuspendLayout();
            this.panelDrawFill.SuspendLayout();
            this.panelDrawFillIn.SuspendLayout();
            this.panelTexturePen.SuspendLayout();
            this.panelTexturePenIn.SuspendLayout();
            this.panellabi.SuspendLayout();
            this.panellabiin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxlabicu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLabizhong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLabixi)).BeginInit();
            this.panelPenColor.SuspendLayout();
            this.panelInkFlow.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarInkFlow)).BeginInit();
            this.panelPenWidth.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarPenWidth)).BeginInit();
            this.panelpriview.SuspendLayout();
            this.toolStripTools.SuspendLayout();
            this.SuspendLayout();
            // 
            // Tab_Imgbase
            // 
            this.Tab_Imgbase.AutoScroll = true;
            this.Tab_Imgbase.BackColor = System.Drawing.Color.White;
            this.Tab_Imgbase.Location = new System.Drawing.Point(4, 4);
            this.Tab_Imgbase.Name = "Tab_Imgbase";
            this.Tab_Imgbase.Padding = new System.Windows.Forms.Padding(3);
            this.Tab_Imgbase.Size = new System.Drawing.Size(205, 808);
            this.Tab_Imgbase.TabIndex = 1;
            this.Tab_Imgbase.Text = "Resource";
            this.Tab_Imgbase.UseVisualStyleBackColor = true;
            // 
            // EraserRectangle
            // 
            this.EraserRectangle.Location = new System.Drawing.Point(99, 5);
            this.EraserRectangle.Name = "EraserRectangle";
            this.EraserRectangle.Size = new System.Drawing.Size(39, 26);
            this.EraserRectangle.Click += new System.EventHandler(this.EraserRectangle_Click);
            // 
            // EraserEllipse
            // 
            this.EraserEllipse.Location = new System.Drawing.Point(49, 4);
            this.EraserEllipse.Name = "EraserEllipse";
            this.EraserEllipse.Size = new System.Drawing.Size(28, 28);
            this.EraserEllipse.Click += new System.EventHandler(this.EraserEllipse_Click);
            // 
            // NotFill
            // 
            this.NotFill.Location = new System.Drawing.Point(97, 25);
            this.NotFill.Name = "NotFill";
            this.NotFill.Size = new System.Drawing.Size(55, 28);
            this.NotFill.Click += new System.EventHandler(this.NotFill_Click);
            // 
            // Fill
            // 
            this.Fill.BackColor = System.Drawing.Color.Black;
            this.Fill.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.Fill.FillColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Fill.Location = new System.Drawing.Point(29, 26);
            this.Fill.Name = "Fill";
            this.Fill.Size = new System.Drawing.Size(55, 28);
            this.Fill.Click += new System.EventHandler(this.Fill_Click);
            // 
            // ShapePenPriview
            // 
            this.ShapePenPriview.BackColor = System.Drawing.Color.Black;
            this.ShapePenPriview.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.ShapePenPriview.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.ShapePenPriview.FillColor = System.Drawing.Color.Transparent;
            this.ShapePenPriview.Location = new System.Drawing.Point(47, 18);
            this.ShapePenPriview.Name = "ShapePenPriview";
            this.ShapePenPriview.SelectionColor = System.Drawing.SystemColors.ControlText;
            this.ShapePenPriview.Size = new System.Drawing.Size(77, 74);
            // 
            // tabControlLeft
            // 
            this.tabControlLeft.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tabControlLeft.Controls.Add(this.Tab_Property);
            this.tabControlLeft.Controls.Add(this.Tab_DrawedBoard);
            this.tabControlLeft.Controls.Add(this.Tab_Imgbase);
            this.tabControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.tabControlLeft.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControlLeft.Location = new System.Drawing.Point(0, 43);
            this.tabControlLeft.Multiline = true;
            this.tabControlLeft.Name = "tabControlLeft";
            this.tabControlLeft.SelectedIndex = 0;
            this.tabControlLeft.Size = new System.Drawing.Size(213, 837);
            this.tabControlLeft.TabIndex = 2;
            // 
            // Tab_Property
            // 
            this.Tab_Property.AutoScroll = true;
            this.Tab_Property.BackColor = System.Drawing.Color.White;
            this.Tab_Property.BackgroundImage = global::KidSparkPainting.Properties.Resources.BackgroundLeft;
            this.Tab_Property.Controls.Add(this.panelEraser);
            this.Tab_Property.Controls.Add(this.panelDrawFill);
            this.Tab_Property.Controls.Add(this.panelTexturePen);
            this.Tab_Property.Controls.Add(this.panellabi);
            this.Tab_Property.Controls.Add(this.panelPenColor);
            this.Tab_Property.Controls.Add(this.panelInkFlow);
            this.Tab_Property.Controls.Add(this.panelPenWidth);
            this.Tab_Property.Controls.Add(this.panelpriview);
            this.Tab_Property.Location = new System.Drawing.Point(4, 4);
            this.Tab_Property.Name = "Tab_Property";
            this.Tab_Property.Padding = new System.Windows.Forms.Padding(3);
            this.Tab_Property.Size = new System.Drawing.Size(205, 808);
            this.Tab_Property.TabIndex = 0;
            this.Tab_Property.Text = "Properties";
            // 
            // panelEraser
            // 
            this.panelEraser.BackColor = System.Drawing.Color.Transparent;
            this.panelEraser.Controls.Add(this.labelEraser);
            this.panelEraser.Controls.Add(this.panelEraserIn);
            this.panelEraser.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelEraser.Location = new System.Drawing.Point(3, 958);
            this.panelEraser.Name = "panelEraser";
            this.panelEraser.Size = new System.Drawing.Size(182, 75);
            this.panelEraser.TabIndex = 25;
            // 
            // labelEraser
            // 
            this.labelEraser.AutoSize = true;
            this.labelEraser.BackColor = System.Drawing.Color.Transparent;
            this.labelEraser.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold);
            this.labelEraser.ForeColor = System.Drawing.Color.Teal;
            this.labelEraser.Location = new System.Drawing.Point(7, 3);
            this.labelEraser.Name = "labelEraser";
            this.labelEraser.Size = new System.Drawing.Size(109, 19);
            this.labelEraser.TabIndex = 17;
            this.labelEraser.Text = "Eraser Shapes";
            // 
            // panelEraserIn
            // 
            this.panelEraserIn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelEraserIn.Controls.Add(this.shapeContainer3);
            this.panelEraserIn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelEraserIn.Location = new System.Drawing.Point(0, 31);
            this.panelEraserIn.Name = "panelEraserIn";
            this.panelEraserIn.Size = new System.Drawing.Size(182, 44);
            this.panelEraserIn.TabIndex = 18;
            // 
            // shapeContainer3
            // 
            this.shapeContainer3.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer3.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer3.Name = "shapeContainer3";
            this.shapeContainer3.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.EraserRectangle,
            this.EraserEllipse});
            this.shapeContainer3.Size = new System.Drawing.Size(180, 42);
            this.shapeContainer3.TabIndex = 0;
            this.shapeContainer3.TabStop = false;
            // 
            // panelDrawFill
            // 
            this.panelDrawFill.BackColor = System.Drawing.Color.Transparent;
            this.panelDrawFill.Controls.Add(this.panelDrawFillIn);
            this.panelDrawFill.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDrawFill.Location = new System.Drawing.Point(3, 823);
            this.panelDrawFill.Name = "panelDrawFill";
            this.panelDrawFill.Size = new System.Drawing.Size(182, 135);
            this.panelDrawFill.TabIndex = 24;
            // 
            // panelDrawFillIn
            // 
            this.panelDrawFillIn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelDrawFillIn.Controls.Add(this.labelFill);
            this.panelDrawFillIn.Controls.Add(this.label1);
            this.panelDrawFillIn.Controls.Add(this.comboBoxColorPickerFillColor);
            this.panelDrawFillIn.Controls.Add(this.shapeContainer2);
            this.panelDrawFillIn.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDrawFillIn.Location = new System.Drawing.Point(0, 0);
            this.panelDrawFillIn.Name = "panelDrawFillIn";
            this.panelDrawFillIn.Size = new System.Drawing.Size(182, 122);
            this.panelDrawFillIn.TabIndex = 15;
            // 
            // labelFill
            // 
            this.labelFill.AutoSize = true;
            this.labelFill.BackColor = System.Drawing.Color.Transparent;
            this.labelFill.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold);
            this.labelFill.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.labelFill.Location = new System.Drawing.Point(6, 2);
            this.labelFill.Name = "labelFill";
            this.labelFill.Size = new System.Drawing.Size(67, 19);
            this.labelFill.TabIndex = 14;
            this.labelFill.Text = "Is Filled";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Green;
            this.label1.Location = new System.Drawing.Point(57, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 19);
            this.label1.TabIndex = 6;
            this.label1.Text = "Fill Color";
            // 
            // shapeContainer2
            // 
            this.shapeContainer2.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer2.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer2.Name = "shapeContainer2";
            this.shapeContainer2.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.NotFill,
            this.Fill});
            this.shapeContainer2.Size = new System.Drawing.Size(180, 120);
            this.shapeContainer2.TabIndex = 0;
            this.shapeContainer2.TabStop = false;
            // 
            // panelTexturePen
            // 
            this.panelTexturePen.BackColor = System.Drawing.Color.Transparent;
            this.panelTexturePen.Controls.Add(this.panelTexturePenIn);
            this.panelTexturePen.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTexturePen.Location = new System.Drawing.Point(3, 610);
            this.panelTexturePen.Name = "panelTexturePen";
            this.panelTexturePen.Size = new System.Drawing.Size(182, 213);
            this.panelTexturePen.TabIndex = 23;
            // 
            // panelTexturePenIn
            // 
            this.panelTexturePenIn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelTexturePenIn.Controls.Add(this.labelwenlihuabi);
            this.panelTexturePenIn.Controls.Add(this.label5);
            this.panelTexturePenIn.Controls.Add(this.label4);
            this.panelTexturePenIn.Controls.Add(this.TexturePenColorPickerMain);
            this.panelTexturePenIn.Controls.Add(this.labelTextureMain);
            this.panelTexturePenIn.Controls.Add(this.labelTextureInsert);
            this.panelTexturePenIn.Controls.Add(this.TexturePenColorPickerInsert);
            this.panelTexturePenIn.Controls.Add(this.labelTexturePenMore);
            this.panelTexturePenIn.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTexturePenIn.Location = new System.Drawing.Point(0, 0);
            this.panelTexturePenIn.Name = "panelTexturePenIn";
            this.panelTexturePenIn.Size = new System.Drawing.Size(182, 207);
            this.panelTexturePenIn.TabIndex = 12;
            // 
            // labelwenlihuabi
            // 
            this.labelwenlihuabi.AutoSize = true;
            this.labelwenlihuabi.BackColor = System.Drawing.Color.Transparent;
            this.labelwenlihuabi.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold);
            this.labelwenlihuabi.ForeColor = System.Drawing.Color.Purple;
            this.labelwenlihuabi.Location = new System.Drawing.Point(6, 4);
            this.labelwenlihuabi.Name = "labelwenlihuabi";
            this.labelwenlihuabi.Size = new System.Drawing.Size(131, 19);
            this.labelwenlihuabi.TabIndex = 13;
            this.labelwenlihuabi.Text = "Texture Pen Type";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label5.Location = new System.Drawing.Point(41, 122);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 19);
            this.label5.TabIndex = 6;
            this.label5.Text = "Embed Color";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(44, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 19);
            this.label4.TabIndex = 5;
            this.label4.Text = "Main Color";
            // 
            // labelTextureMain
            // 
            this.labelTextureMain.BackColor = System.Drawing.Color.Black;
            this.labelTextureMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelTextureMain.Location = new System.Drawing.Point(72, 33);
            this.labelTextureMain.Name = "labelTextureMain";
            this.labelTextureMain.Size = new System.Drawing.Size(50, 22);
            this.labelTextureMain.TabIndex = 3;
            // 
            // labelTextureInsert
            // 
            this.labelTextureInsert.BackColor = System.Drawing.Color.White;
            this.labelTextureInsert.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelTextureInsert.Location = new System.Drawing.Point(50, 42);
            this.labelTextureInsert.Name = "labelTextureInsert";
            this.labelTextureInsert.Size = new System.Drawing.Size(50, 22);
            this.labelTextureInsert.TabIndex = 2;
            // 
            // labelTexturePenMore
            // 
            this.labelTexturePenMore.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelTexturePenMore.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.labelTexturePenMore.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold);
            this.labelTexturePenMore.ForeColor = System.Drawing.Color.Olive;
            this.labelTexturePenMore.Location = new System.Drawing.Point(0, 177);
            this.labelTexturePenMore.Name = "labelTexturePenMore";
            this.labelTexturePenMore.Size = new System.Drawing.Size(180, 28);
            this.labelTexturePenMore.TabIndex = 0;
            this.labelTexturePenMore.Text = "More Texture Pen...";
            this.labelTexturePenMore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labelTexturePenMore.Click += new System.EventHandler(this.labelTexturePenMore_Click);
            // 
            // panellabi
            // 
            this.panellabi.BackColor = System.Drawing.Color.Transparent;
            this.panellabi.Controls.Add(this.panellabiin);
            this.panellabi.Dock = System.Windows.Forms.DockStyle.Top;
            this.panellabi.Location = new System.Drawing.Point(3, 442);
            this.panellabi.Name = "panellabi";
            this.panellabi.Size = new System.Drawing.Size(182, 168);
            this.panellabi.TabIndex = 22;
            // 
            // panellabiin
            // 
            this.panellabiin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panellabiin.Controls.Add(this.labellabi);
            this.panellabiin.Controls.Add(this.pictureBoxlabicu);
            this.panellabiin.Controls.Add(this.pictureBoxLabizhong);
            this.panellabiin.Controls.Add(this.pictureBoxLabixi);
            this.panellabiin.Dock = System.Windows.Forms.DockStyle.Top;
            this.panellabiin.Location = new System.Drawing.Point(0, 0);
            this.panellabiin.Name = "panellabiin";
            this.panellabiin.Size = new System.Drawing.Size(182, 153);
            this.panellabiin.TabIndex = 11;
            // 
            // labellabi
            // 
            this.labellabi.AutoSize = true;
            this.labellabi.BackColor = System.Drawing.Color.Transparent;
            this.labellabi.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold);
            this.labellabi.ForeColor = System.Drawing.Color.Red;
            this.labellabi.Location = new System.Drawing.Point(12, 8);
            this.labellabi.Name = "labellabi";
            this.labellabi.Size = new System.Drawing.Size(94, 19);
            this.labellabi.TabIndex = 10;
            this.labellabi.Text = "Crayon Type";
            // 
            // pictureBoxlabicu
            // 
            this.pictureBoxlabicu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxlabicu.Image = global::KidSparkPainting.Properties.Resources.labicu;
            this.pictureBoxlabicu.Location = new System.Drawing.Point(29, 114);
            this.pictureBoxlabicu.Name = "pictureBoxlabicu";
            this.pictureBoxlabicu.Size = new System.Drawing.Size(122, 27);
            this.pictureBoxlabicu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxlabicu.TabIndex = 2;
            this.pictureBoxlabicu.TabStop = false;
            this.pictureBoxlabicu.Click += new System.EventHandler(this.pictureBoxlabicu_Click);
            // 
            // pictureBoxLabizhong
            // 
            this.pictureBoxLabizhong.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxLabizhong.Image = global::KidSparkPainting.Properties.Resources.labizhong;
            this.pictureBoxLabizhong.Location = new System.Drawing.Point(29, 78);
            this.pictureBoxLabizhong.Name = "pictureBoxLabizhong";
            this.pictureBoxLabizhong.Size = new System.Drawing.Size(122, 27);
            this.pictureBoxLabizhong.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxLabizhong.TabIndex = 1;
            this.pictureBoxLabizhong.TabStop = false;
            this.pictureBoxLabizhong.Click += new System.EventHandler(this.pictureBoxLabizhong_Click);
            // 
            // pictureBoxLabixi
            // 
            this.pictureBoxLabixi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxLabixi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxLabixi.Image = global::KidSparkPainting.Properties.Resources.labixi;
            this.pictureBoxLabixi.Location = new System.Drawing.Point(29, 40);
            this.pictureBoxLabixi.Name = "pictureBoxLabixi";
            this.pictureBoxLabixi.Size = new System.Drawing.Size(124, 29);
            this.pictureBoxLabixi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxLabixi.TabIndex = 0;
            this.pictureBoxLabixi.TabStop = false;
            this.pictureBoxLabixi.Click += new System.EventHandler(this.pictureBoxLabixi_Click);
            // 
            // panelPenColor
            // 
            this.panelPenColor.BackColor = System.Drawing.Color.Transparent;
            this.panelPenColor.Controls.Add(this.labelPenColor);
            this.panelPenColor.Controls.Add(this.ColorPickerPenColor);
            this.panelPenColor.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelPenColor.Location = new System.Drawing.Point(3, 272);
            this.panelPenColor.Name = "panelPenColor";
            this.panelPenColor.Size = new System.Drawing.Size(182, 170);
            this.panelPenColor.TabIndex = 21;
            // 
            // labelPenColor
            // 
            this.labelPenColor.AutoSize = true;
            this.labelPenColor.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPenColor.ForeColor = System.Drawing.Color.Green;
            this.labelPenColor.Location = new System.Drawing.Point(12, 9);
            this.labelPenColor.Name = "labelPenColor";
            this.labelPenColor.Size = new System.Drawing.Size(71, 19);
            this.labelPenColor.TabIndex = 1;
            this.labelPenColor.Text = "Pen Color";
            // 
            // panelInkFlow
            // 
            this.panelInkFlow.BackColor = System.Drawing.Color.Transparent;
            this.panelInkFlow.Controls.Add(this.labelInkFlow);
            this.panelInkFlow.Controls.Add(this.trackBarInkFlow);
            this.panelInkFlow.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelInkFlow.Location = new System.Drawing.Point(3, 199);
            this.panelInkFlow.Name = "panelInkFlow";
            this.panelInkFlow.Size = new System.Drawing.Size(182, 73);
            this.panelInkFlow.TabIndex = 20;
            // 
            // labelInkFlow
            // 
            this.labelInkFlow.AutoSize = true;
            this.labelInkFlow.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInkFlow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.labelInkFlow.Location = new System.Drawing.Point(12, 12);
            this.labelInkFlow.Name = "labelInkFlow";
            this.labelInkFlow.Size = new System.Drawing.Size(68, 19);
            this.labelInkFlow.TabIndex = 7;
            this.labelInkFlow.Text = "Ink Flow";
            // 
            // trackBarInkFlow
            // 
            this.trackBarInkFlow.AutoSize = false;
            this.trackBarInkFlow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(200)))), ((int)(((byte)(227)))));
            this.trackBarInkFlow.Location = new System.Drawing.Point(8, 40);
            this.trackBarInkFlow.Maximum = 255;
            this.trackBarInkFlow.Minimum = 2;
            this.trackBarInkFlow.Name = "trackBarInkFlow";
            this.trackBarInkFlow.Size = new System.Drawing.Size(147, 23);
            this.trackBarInkFlow.TabIndex = 6;
            this.trackBarInkFlow.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBarInkFlow.Value = 153;
            this.trackBarInkFlow.Scroll += new System.EventHandler(this.trackBarInkFlow_Scroll);
            // 
            // panelPenWidth
            // 
            this.panelPenWidth.BackColor = System.Drawing.Color.Transparent;
            this.panelPenWidth.Controls.Add(this.labelPenWidth);
            this.panelPenWidth.Controls.Add(this.trackBarPenWidth);
            this.panelPenWidth.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelPenWidth.Location = new System.Drawing.Point(3, 126);
            this.panelPenWidth.Name = "panelPenWidth";
            this.panelPenWidth.Size = new System.Drawing.Size(182, 73);
            this.panelPenWidth.TabIndex = 19;
            // 
            // labelPenWidth
            // 
            this.labelPenWidth.AutoSize = true;
            this.labelPenWidth.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPenWidth.ForeColor = System.Drawing.Color.Purple;
            this.labelPenWidth.Location = new System.Drawing.Point(13, 10);
            this.labelPenWidth.Name = "labelPenWidth";
            this.labelPenWidth.Size = new System.Drawing.Size(79, 19);
            this.labelPenWidth.TabIndex = 0;
            this.labelPenWidth.Text = "Pen Width";
            // 
            // trackBarPenWidth
            // 
            this.trackBarPenWidth.AutoSize = false;
            this.trackBarPenWidth.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(197)))), ((int)(((byte)(226)))));
            this.trackBarPenWidth.Location = new System.Drawing.Point(8, 38);
            this.trackBarPenWidth.Maximum = 150;
            this.trackBarPenWidth.Minimum = 1;
            this.trackBarPenWidth.Name = "trackBarPenWidth";
            this.trackBarPenWidth.Size = new System.Drawing.Size(147, 23);
            this.trackBarPenWidth.TabIndex = 2;
            this.trackBarPenWidth.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBarPenWidth.Value = 3;
            this.trackBarPenWidth.Scroll += new System.EventHandler(this.trackBarPenWidth_Scroll);
            // 
            // panelpriview
            // 
            this.panelpriview.BackColor = System.Drawing.Color.Transparent;
            this.panelpriview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelpriview.Controls.Add(this.shapeContainer1);
            this.panelpriview.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelpriview.Location = new System.Drawing.Point(3, 3);
            this.panelpriview.Name = "panelpriview";
            this.panelpriview.Size = new System.Drawing.Size(182, 123);
            this.panelpriview.TabIndex = 8;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.ShapePenPriview});
            this.shapeContainer1.Size = new System.Drawing.Size(180, 121);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            // 
            // Tab_DrawedBoard
            // 
            this.Tab_DrawedBoard.AutoScroll = true;
            this.Tab_DrawedBoard.BackColor = System.Drawing.Color.White;
            this.Tab_DrawedBoard.BackgroundImage = global::KidSparkPainting.Properties.Resources.BackgroundLeft;
            this.Tab_DrawedBoard.Location = new System.Drawing.Point(4, 4);
            this.Tab_DrawedBoard.Name = "Tab_DrawedBoard";
            this.Tab_DrawedBoard.Size = new System.Drawing.Size(205, 808);
            this.Tab_DrawedBoard.TabIndex = 2;
            this.Tab_DrawedBoard.Text = "Board";
            this.Tab_DrawedBoard.UseVisualStyleBackColor = true;
            // 
            // skinEngine
            // 
            this.skinEngine.SerialNumber = "";
            this.skinEngine.SkinFile = null;
            // 
            // toolStripTools
            // 
            this.toolStripTools.BackgroundImage = global::KidSparkPainting.Properties.Resources.BackgroundTop;
            this.toolStripTools.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.toolStripTools.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStripTools.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ButtonOpen,
            this.ButtonNew,
            this.ButtonSaveAs,
            this.ButtonPoint,
            this.ButtonDrawLine,
            this.ButtonRec,
            this.ButtonEllipse,
            this.ButtonClean,
            this.ButtonPic,
            this.ButtonMoviePic,
            this.ButtonSLine,
            this.ButtonCrayon,
            this.ButtonTexturePen,
            this.ButtonInkPainting,
            this.ButtonChineseBrush,
            this.ButtonInsVedio,
            this.ButtonInsFlash,
            this.ButtonOpenPPT,
            this.ButtonOpenPDF,
            this.ButtonExit,
            this.ButtonHelp,
            this.ButtonSharePalette,
            this.ButtonLefTools,
            this.ButtonCamera});
            this.toolStripTools.Location = new System.Drawing.Point(0, 0);
            this.toolStripTools.Name = "toolStripTools";
            this.toolStripTools.Size = new System.Drawing.Size(1079, 43);
            this.toolStripTools.TabIndex = 1;
            this.toolStripTools.Text = "toolStrip1";
            // 
            // ButtonOpen
            // 
            this.ButtonOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonOpen.Image = global::KidSparkPainting.Properties.Resources.OPEN;
            this.ButtonOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonOpen.Margin = new System.Windows.Forms.Padding(10, 1, 0, 2);
            this.ButtonOpen.Name = "ButtonOpen";
            this.ButtonOpen.Size = new System.Drawing.Size(41, 40);
            this.ButtonOpen.Text = "Open";
            this.ButtonOpen.Click += new System.EventHandler(this.ButtonOpen_Click);
            // 
            // ButtonNew
            // 
            this.ButtonNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonNew.Image = global::KidSparkPainting.Properties.Resources.NEW;
            this.ButtonNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonNew.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonNew.Margin = new System.Windows.Forms.Padding(5, 1, 0, 2);
            this.ButtonNew.Name = "ButtonNew";
            this.ButtonNew.Size = new System.Drawing.Size(32, 40);
            this.ButtonNew.Text = "New";
            this.ButtonNew.Click += new System.EventHandler(this.ButtonNew_Click);
            // 
            // ButtonSaveAs
            // 
            this.ButtonSaveAs.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonSaveAs.Image = global::KidSparkPainting.Properties.Resources.SAVE;
            this.ButtonSaveAs.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonSaveAs.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonSaveAs.Margin = new System.Windows.Forms.Padding(5, 1, 0, 2);
            this.ButtonSaveAs.Name = "ButtonSaveAs";
            this.ButtonSaveAs.Size = new System.Drawing.Size(44, 40);
            this.ButtonSaveAs.Text = "Save";
            this.ButtonSaveAs.Click += new System.EventHandler(this.ButtonSave_Click);
            // 
            // ButtonPoint
            // 
            this.ButtonPoint.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonPoint.Image = global::KidSparkPainting.Properties.Resources.POINT;
            this.ButtonPoint.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonPoint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonPoint.Margin = new System.Windows.Forms.Padding(5, 1, 0, 2);
            this.ButtonPoint.Name = "ButtonPoint";
            this.ButtonPoint.Size = new System.Drawing.Size(35, 40);
            this.ButtonPoint.Text = "Point";
            this.ButtonPoint.Click += new System.EventHandler(this.ButtonPoint_Click);
            // 
            // ButtonDrawLine
            // 
            this.ButtonDrawLine.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonDrawLine.Image = global::KidSparkPainting.Properties.Resources.PENCIL;
            this.ButtonDrawLine.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonDrawLine.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonDrawLine.Margin = new System.Windows.Forms.Padding(5, 1, 0, 2);
            this.ButtonDrawLine.Name = "ButtonDrawLine";
            this.ButtonDrawLine.Size = new System.Drawing.Size(35, 40);
            this.ButtonDrawLine.Text = "Pencil";
            this.ButtonDrawLine.Click += new System.EventHandler(this.ButtonDrawLine_Click);
            // 
            // ButtonRec
            // 
            this.ButtonRec.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonRec.Image = global::KidSparkPainting.Properties.Resources.REC;
            this.ButtonRec.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonRec.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonRec.Margin = new System.Windows.Forms.Padding(5, 1, 0, 2);
            this.ButtonRec.Name = "ButtonRec";
            this.ButtonRec.Size = new System.Drawing.Size(41, 40);
            this.ButtonRec.Text = "Rectangle";
            this.ButtonRec.Click += new System.EventHandler(this.ButtonRec_Click);
            // 
            // ButtonEllipse
            // 
            this.ButtonEllipse.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonEllipse.Image = global::KidSparkPainting.Properties.Resources.ELLIPSE;
            this.ButtonEllipse.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonEllipse.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonEllipse.Margin = new System.Windows.Forms.Padding(5, 1, 0, 2);
            this.ButtonEllipse.Name = "ButtonEllipse";
            this.ButtonEllipse.Size = new System.Drawing.Size(35, 40);
            this.ButtonEllipse.Text = "Ellipse";
            this.ButtonEllipse.Click += new System.EventHandler(this.ButtonEllipse_Click);
            // 
            // ButtonClean
            // 
            this.ButtonClean.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonClean.Image = global::KidSparkPainting.Properties.Resources.ERASER;
            this.ButtonClean.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonClean.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonClean.Margin = new System.Windows.Forms.Padding(3, 1, 0, 2);
            this.ButtonClean.Name = "ButtonClean";
            this.ButtonClean.Size = new System.Drawing.Size(40, 40);
            this.ButtonClean.Text = "Eraser";
            this.ButtonClean.Click += new System.EventHandler(this.ButtonClean_Click);
            // 
            // ButtonPic
            // 
            this.ButtonPic.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonPic.Image = global::KidSparkPainting.Properties.Resources.INSPIC;
            this.ButtonPic.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonPic.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonPic.Margin = new System.Windows.Forms.Padding(5, 1, 0, 2);
            this.ButtonPic.Name = "ButtonPic";
            this.ButtonPic.Size = new System.Drawing.Size(32, 40);
            this.ButtonPic.Text = "Immovable Picture";
            this.ButtonPic.Click += new System.EventHandler(this.ButtonPic_Click);
            // 
            // ButtonMoviePic
            // 
            this.ButtonMoviePic.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonMoviePic.Image = global::KidSparkPainting.Properties.Resources.INSMOVEPIC;
            this.ButtonMoviePic.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonMoviePic.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonMoviePic.Margin = new System.Windows.Forms.Padding(5, 1, 0, 2);
            this.ButtonMoviePic.Name = "ButtonMoviePic";
            this.ButtonMoviePic.Size = new System.Drawing.Size(36, 40);
            this.ButtonMoviePic.Text = "Removable Picture";
            this.ButtonMoviePic.Click += new System.EventHandler(this.ButtonMoviePic_Click);
            // 
            // ButtonSLine
            // 
            this.ButtonSLine.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonSLine.Image = global::KidSparkPainting.Properties.Resources.SLINE;
            this.ButtonSLine.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonSLine.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonSLine.Margin = new System.Windows.Forms.Padding(2, 1, 0, 2);
            this.ButtonSLine.Name = "ButtonSLine";
            this.ButtonSLine.Size = new System.Drawing.Size(49, 40);
            this.ButtonSLine.Text = "Beeline";
            this.ButtonSLine.Click += new System.EventHandler(this.ButtonSLine_Click);
            // 
            // ButtonCrayon
            // 
            this.ButtonCrayon.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonCrayon.Image = global::KidSparkPainting.Properties.Resources.CRAYON;
            this.ButtonCrayon.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonCrayon.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonCrayon.Margin = new System.Windows.Forms.Padding(3, 1, 0, 2);
            this.ButtonCrayon.Name = "ButtonCrayon";
            this.ButtonCrayon.Size = new System.Drawing.Size(34, 40);
            this.ButtonCrayon.Text = "Crayon";
            this.ButtonCrayon.Click += new System.EventHandler(this.ButtonCrayon_Click);
            // 
            // ButtonTexturePen
            // 
            this.ButtonTexturePen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonTexturePen.Image = global::KidSparkPainting.Properties.Resources.TEXTUREPEN;
            this.ButtonTexturePen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonTexturePen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonTexturePen.Margin = new System.Windows.Forms.Padding(5, 1, 0, 2);
            this.ButtonTexturePen.Name = "ButtonTexturePen";
            this.ButtonTexturePen.Size = new System.Drawing.Size(33, 40);
            this.ButtonTexturePen.Text = "Texture Pen";
            this.ButtonTexturePen.Click += new System.EventHandler(this.ButtonTexturePen_Click);
            // 
            // ButtonInkPainting
            // 
            this.ButtonInkPainting.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonInkPainting.Image = global::KidSparkPainting.Properties.Resources.INKPAINT;
            this.ButtonInkPainting.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonInkPainting.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonInkPainting.Margin = new System.Windows.Forms.Padding(2, 1, 0, 2);
            this.ButtonInkPainting.Name = "ButtonInkPainting";
            this.ButtonInkPainting.Size = new System.Drawing.Size(51, 40);
            this.ButtonInkPainting.Text = "Brush Pen ";
            this.ButtonInkPainting.Click += new System.EventHandler(this.ButtonInkPainting_Click);
            // 
            // ButtonChineseBrush
            // 
            this.ButtonChineseBrush.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonChineseBrush.Image = global::KidSparkPainting.Properties.Resources.ChineseBrush;
            this.ButtonChineseBrush.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonChineseBrush.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonChineseBrush.Margin = new System.Windows.Forms.Padding(6, 1, 0, 2);
            this.ButtonChineseBrush.Name = "ButtonChineseBrush";
            this.ButtonChineseBrush.Size = new System.Drawing.Size(23, 40);
            this.ButtonChineseBrush.Text = "Brush";
            this.ButtonChineseBrush.Click += new System.EventHandler(this.ButtonChineseBrush_Click);
            // 
            // ButtonInsVedio
            // 
            this.ButtonInsVedio.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonInsVedio.Image = global::KidSparkPainting.Properties.Resources.INSVEDIO;
            this.ButtonInsVedio.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonInsVedio.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonInsVedio.Margin = new System.Windows.Forms.Padding(7, 1, 0, 2);
            this.ButtonInsVedio.Name = "ButtonInsVedio";
            this.ButtonInsVedio.Size = new System.Drawing.Size(31, 40);
            this.ButtonInsVedio.Text = "Insert Video";
            this.ButtonInsVedio.Click += new System.EventHandler(this.ButtonInsVedio_Click);
            // 
            // ButtonInsFlash
            // 
            this.ButtonInsFlash.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonInsFlash.Image = global::KidSparkPainting.Properties.Resources.INSFLASH;
            this.ButtonInsFlash.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonInsFlash.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonInsFlash.Margin = new System.Windows.Forms.Padding(7, 1, 0, 2);
            this.ButtonInsFlash.Name = "ButtonInsFlash";
            this.ButtonInsFlash.Size = new System.Drawing.Size(31, 40);
            this.ButtonInsFlash.Text = "Insert Flash";
            this.ButtonInsFlash.Click += new System.EventHandler(this.ButtonInsFlash_Click);
            // 
            // ButtonOpenPPT
            // 
            this.ButtonOpenPPT.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonOpenPPT.Image = global::KidSparkPainting.Properties.Resources.OPENPPT;
            this.ButtonOpenPPT.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonOpenPPT.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonOpenPPT.Margin = new System.Windows.Forms.Padding(6, 1, 0, 2);
            this.ButtonOpenPPT.Name = "ButtonOpenPPT";
            this.ButtonOpenPPT.Size = new System.Drawing.Size(47, 40);
            this.ButtonOpenPPT.Text = "Open PPT";
            this.ButtonOpenPPT.Click += new System.EventHandler(this.ButtonOpenPPT_Click);
            // 
            // ButtonOpenPDF
            // 
            this.ButtonOpenPDF.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonOpenPDF.Image = global::KidSparkPainting.Properties.Resources.OPENPDF;
            this.ButtonOpenPDF.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonOpenPDF.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonOpenPDF.Margin = new System.Windows.Forms.Padding(6, 1, 0, 2);
            this.ButtonOpenPDF.Name = "ButtonOpenPDF";
            this.ButtonOpenPDF.Size = new System.Drawing.Size(32, 40);
            this.ButtonOpenPDF.Text = "Open PDF";
            this.ButtonOpenPDF.Click += new System.EventHandler(this.ButtonOpenPDF_Click);
            // 
            // ButtonExit
            // 
            this.ButtonExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.ButtonExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonExit.Image = global::KidSparkPainting.Properties.Resources.Exit1;
            this.ButtonExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonExit.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.ButtonExit.Name = "ButtonExit";
            this.ButtonExit.Size = new System.Drawing.Size(36, 40);
            this.ButtonExit.Text = "Exit";
            this.ButtonExit.Click += new System.EventHandler(this.ButtonExit_Click);
            // 
            // ButtonHelp
            // 
            this.ButtonHelp.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.ButtonHelp.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonHelp.Image = global::KidSparkPainting.Properties.Resources.HELP;
            this.ButtonHelp.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonHelp.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonHelp.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.ButtonHelp.Name = "ButtonHelp";
            this.ButtonHelp.Size = new System.Drawing.Size(26, 40);
            this.ButtonHelp.Text = "Help";
            this.ButtonHelp.Click += new System.EventHandler(this.ButtonHelp_Click);
            // 
            // ButtonSharePalette
            // 
            this.ButtonSharePalette.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonSharePalette.Image = global::KidSparkPainting.Properties.Resources.SHAREDESKTOP;
            this.ButtonSharePalette.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonSharePalette.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonSharePalette.Margin = new System.Windows.Forms.Padding(6, 1, 0, 2);
            this.ButtonSharePalette.Name = "ButtonSharePalette";
            this.ButtonSharePalette.Size = new System.Drawing.Size(33, 40);
            this.ButtonSharePalette.Text = "Share Board";
            this.ButtonSharePalette.Click += new System.EventHandler(this.ButtonSharePalette_Click);
            // 
            // ButtonLefTools
            // 
            this.ButtonLefTools.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.ButtonLefTools.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonLefTools.Image = global::KidSparkPainting.Properties.Resources.SHOWTOOLS;
            this.ButtonLefTools.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonLefTools.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonLefTools.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.ButtonLefTools.Name = "ButtonLefTools";
            this.ButtonLefTools.Size = new System.Drawing.Size(47, 40);
            this.ButtonLefTools.Text = "Hide Left Tools";
            this.ButtonLefTools.Click += new System.EventHandler(this.ButtonLefTools_Click);
            // 
            // ButtonCamera
            // 
            this.ButtonCamera.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonCamera.Image = global::KidSparkPainting.Properties.Resources.SHOWFACE;
            this.ButtonCamera.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonCamera.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonCamera.Margin = new System.Windows.Forms.Padding(6, 1, 0, 2);
            this.ButtonCamera.Name = "ButtonCamera";
            this.ButtonCamera.Size = new System.Drawing.Size(36, 40);
            this.ButtonCamera.Text = "Video Chat";
            this.ButtonCamera.Click += new System.EventHandler(this.ButtonCamera_Click);
            // 
            // DrawPlace
            // 
            this.DrawPlace.BackColor = System.Drawing.Color.White;
            this.DrawPlace.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.DrawPlace.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DrawPlace.Location = new System.Drawing.Point(213, 43);
            this.DrawPlace.Name = "DrawPlace";
            this.DrawPlace.Size = new System.Drawing.Size(866, 837);
            this.DrawPlace.TabIndex = 3;
            this.DrawPlace.Text = "drawAreaCtrl1";
            // 
            // comboBoxColorPickerFillColor
            // 
            this.comboBoxColorPickerFillColor.Color = System.Drawing.Color.Black;
            this.comboBoxColorPickerFillColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxColorPickerFillColor.DropDownHeight = 1;
            this.comboBoxColorPickerFillColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxColorPickerFillColor.DropDownWidth = 1;
            this.comboBoxColorPickerFillColor.FormattingEnabled = true;
            this.comboBoxColorPickerFillColor.IntegralHeight = false;
            this.comboBoxColorPickerFillColor.ItemHeight = 16;
            this.comboBoxColorPickerFillColor.Items.AddRange(new object[] {
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color"});
            this.comboBoxColorPickerFillColor.Location = new System.Drawing.Point(34, 93);
            this.comboBoxColorPickerFillColor.Name = "comboBoxColorPickerFillColor";
            this.comboBoxColorPickerFillColor.Size = new System.Drawing.Size(116, 22);
            this.comboBoxColorPickerFillColor.TabIndex = 1;
            this.comboBoxColorPickerFillColor.SelectedColorChanged += new System.EventHandler(this.comboBoxColorPickerFillColor_SelectedColorChanged);
            // 
            // TexturePenColorPickerMain
            // 
            this.TexturePenColorPickerMain.Color = System.Drawing.Color.Black;
            this.TexturePenColorPickerMain.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.TexturePenColorPickerMain.DropDownHeight = 1;
            this.TexturePenColorPickerMain.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TexturePenColorPickerMain.DropDownWidth = 1;
            this.TexturePenColorPickerMain.FormattingEnabled = true;
            this.TexturePenColorPickerMain.IntegralHeight = false;
            this.TexturePenColorPickerMain.ItemHeight = 16;
            this.TexturePenColorPickerMain.Items.AddRange(new object[] {
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color"});
            this.TexturePenColorPickerMain.Location = new System.Drawing.Point(29, 94);
            this.TexturePenColorPickerMain.Name = "TexturePenColorPickerMain";
            this.TexturePenColorPickerMain.Size = new System.Drawing.Size(116, 22);
            this.TexturePenColorPickerMain.TabIndex = 4;
            this.TexturePenColorPickerMain.SelectedColorChanged += new System.EventHandler(this.TexturePenColorPickerMain_SelectedColorChanged);
            // 
            // TexturePenColorPickerInsert
            // 
            this.TexturePenColorPickerInsert.Color = System.Drawing.Color.Black;
            this.TexturePenColorPickerInsert.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.TexturePenColorPickerInsert.DropDownHeight = 1;
            this.TexturePenColorPickerInsert.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TexturePenColorPickerInsert.DropDownWidth = 1;
            this.TexturePenColorPickerInsert.FormattingEnabled = true;
            this.TexturePenColorPickerInsert.IntegralHeight = false;
            this.TexturePenColorPickerInsert.ItemHeight = 16;
            this.TexturePenColorPickerInsert.Items.AddRange(new object[] {
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color",
            "Color"});
            this.TexturePenColorPickerInsert.Location = new System.Drawing.Point(29, 146);
            this.TexturePenColorPickerInsert.Name = "TexturePenColorPickerInsert";
            this.TexturePenColorPickerInsert.Size = new System.Drawing.Size(116, 22);
            this.TexturePenColorPickerInsert.TabIndex = 1;
            this.TexturePenColorPickerInsert.SelectedColorChanged += new System.EventHandler(this.TexturePenColorPickerInsert_SelectedColorChanged);
            // 
            // ColorPickerPenColor
            // 
            this.ColorPickerPenColor.Color = System.Drawing.Color.Black;
            this.ColorPickerPenColor.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold);
            this.ColorPickerPenColor.Location = new System.Drawing.Point(11, 39);
            this.ColorPickerPenColor.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ColorPickerPenColor.Name = "ColorPickerPenColor";
            this.ColorPickerPenColor.Size = new System.Drawing.Size(147, 127);
            this.ColorPickerPenColor.TabIndex = 16;
            this.ColorPickerPenColor.SelectedColorChanged += new System.EventHandler(this.ColorPickerPenColor_SelectedColorChanged);
            // 
            // WinForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1079, 880);
            this.Controls.Add(this.DrawPlace);
            this.Controls.Add(this.tabControlLeft);
            this.Controls.Add(this.toolStripTools);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "WinForm";
            this.Text = "KidBoard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.WinForm_Load);
            this.tabControlLeft.ResumeLayout(false);
            this.Tab_Property.ResumeLayout(false);
            this.panelEraser.ResumeLayout(false);
            this.panelEraser.PerformLayout();
            this.panelEraserIn.ResumeLayout(false);
            this.panelDrawFill.ResumeLayout(false);
            this.panelDrawFillIn.ResumeLayout(false);
            this.panelDrawFillIn.PerformLayout();
            this.panelTexturePen.ResumeLayout(false);
            this.panelTexturePenIn.ResumeLayout(false);
            this.panelTexturePenIn.PerformLayout();
            this.panellabi.ResumeLayout(false);
            this.panellabiin.ResumeLayout(false);
            this.panellabiin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxlabicu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLabizhong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLabixi)).EndInit();
            this.panelPenColor.ResumeLayout(false);
            this.panelPenColor.PerformLayout();
            this.panelInkFlow.ResumeLayout(false);
            this.panelInkFlow.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarInkFlow)).EndInit();
            this.panelPenWidth.ResumeLayout(false);
            this.panelPenWidth.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarPenWidth)).EndInit();
            this.panelpriview.ResumeLayout(false);
            this.toolStripTools.ResumeLayout(false);
            this.toolStripTools.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStripTools;
        private System.Windows.Forms.ToolStripButton ButtonDrawLine;
        private System.Windows.Forms.ToolStripButton ButtonRec;
        private System.Windows.Forms.ToolStripButton ButtonEllipse;
        private System.Windows.Forms.ToolStripButton ButtonClean;
        private System.Windows.Forms.ToolStripButton ButtonSaveAs;
        private System.Windows.Forms.ToolStripButton ButtonPic;
        private System.Windows.Forms.ToolStripButton ButtonPoint;
        private System.Windows.Forms.ToolStripButton ButtonSLine;
        private System.Windows.Forms.ToolStripButton ButtonCrayon;
        private System.Windows.Forms.ToolStripButton ButtonInkPainting;
        private System.Windows.Forms.ToolStripButton ButtonInsVedio;
        private System.Windows.Forms.ToolStripButton ButtonChineseBrush;
        private System.Windows.Forms.ToolStripButton ButtonInsFlash;
        private System.Windows.Forms.ToolStripButton ButtonOpenPPT;
        private System.Windows.Forms.ToolStripButton ButtonOpenPDF;
        private System.Windows.Forms.ToolStripButton ButtonMoviePic;
        private System.Windows.Forms.ToolStripButton ButtonNew;
        private System.Windows.Forms.TabPage Tab_Imgbase;
        private System.Windows.Forms.TabPage Tab_Property;
        private System.Windows.Forms.TabPage Tab_DrawedBoard;
        private System.Windows.Forms.TabControl tabControlLeft;
        private System.Windows.Forms.ToolStripButton ButtonLefTools;
        private System.Windows.Forms.Label labelPenWidth;
        private System.Windows.Forms.Label labelPenColor;
        private System.Windows.Forms.TrackBar trackBarPenWidth;
        private System.Windows.Forms.Label labelInkFlow;
        private System.Windows.Forms.TrackBar trackBarInkFlow;
        private System.Windows.Forms.Panel panelpriview;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ShapePenPriview;
        private System.Windows.Forms.Label labellabi;
        private System.Windows.Forms.Panel panellabiin;
        private System.Windows.Forms.PictureBox pictureBoxLabixi;
        private System.Windows.Forms.PictureBox pictureBoxlabicu;
        private System.Windows.Forms.PictureBox pictureBoxLabizhong;
        private System.Windows.Forms.Panel panelTexturePenIn;
        private System.Windows.Forms.Label labelTexturePenMore;
        private KidSparkPainting.ColorPicker.ComboBoxColorPicker TexturePenColorPickerInsert;
        private System.Windows.Forms.Label labelTextureInsert;
        private System.Windows.Forms.Label labelTextureMain;
        private KidSparkPainting.ColorPicker.ComboBoxColorPicker TexturePenColorPickerMain;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelwenlihuabi;
        private System.Windows.Forms.Label labelFill;
        private System.Windows.Forms.Panel panelDrawFillIn;
        private KidSparkPainting.ColorPicker.OfficeColorPicker ColorPickerPenColor;
        private System.Windows.Forms.ToolStripButton ButtonTexturePen;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer2;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape NotFill;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape Fill;
        private KidSparkPainting.ColorPicker.ComboBoxColorPicker comboBoxColorPickerFillColor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelEraser;
        private System.Windows.Forms.Panel panelEraserIn;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer3;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape EraserRectangle;
        private Microsoft.VisualBasic.PowerPacks.OvalShape EraserEllipse;
        private System.Windows.Forms.Panel panelPenWidth;
        private System.Windows.Forms.Panel panelInkFlow;
        private System.Windows.Forms.Panel panelPenColor;
        private System.Windows.Forms.Panel panellabi;
        private System.Windows.Forms.Panel panelTexturePen;
        private System.Windows.Forms.Panel panelDrawFill;
        private System.Windows.Forms.Panel panelEraser;
        private System.Windows.Forms.ToolStripButton ButtonOpen;
        private System.Windows.Forms.ToolStripButton ButtonExit;
        private System.Windows.Forms.ToolStripButton ButtonHelp;
        private System.Windows.Forms.ToolStripButton ButtonSharePalette;
        private System.Windows.Forms.ToolStripButton ButtonCamera;
        private Sunisoft.IrisSkin.SkinEngine skinEngine;
        public DrawAreaCtrl DrawPlace;
    }
}