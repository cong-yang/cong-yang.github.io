﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace KidSparkPainting
{
    public partial class MediaPlayer : UserControl
    {
        public MediaPlayer()
        {
            InitializeComponent();
        }

        public string path = "";//记录文件完整路径
        //string duration = "";//当前文件播放的时间
        private Dictionary<string, string> pathList = new Dictionary<string, string>();
        private const int mediadelta = 10;
        private bool playorprase = true;

        public void StartPlayMedia(string mediapath)
        {
            //开始播放视频
            axWmp.URL = mediapath;
            timerMediaPlayer.Start();
        }

        private void play_Click(object sender, EventArgs e)
        {
            if (playorprase)
            {
                //暂停播放
                this.axWmp.Ctlcontrols.pause();
                playorprase = false;
                play.Image = global::KidSparkPainting.Properties.Resources.PAUSE;
            }
            else
            {
                //播放文件
                this.axWmp.Ctlcontrols.play();
                playorprase = true;
                play.Image = global::KidSparkPainting.Properties.Resources.PLAY;
            }

        }

        private void stop_Click(object sender, EventArgs e)
        {
            //停止播放
            this.axWmp.Ctlcontrols.stop();
            //清除图像，等待就须状态
            this.axWmp.close();
            playorprase = false;
        }

        private void risingvoice_Click(object sender, EventArgs e)
        {
            //升高音量
            this.axWmp.settings.volume += 5;
        }

        private void downvoice_Click(object sender, EventArgs e)
        {
            //降低音量
            this.axWmp.settings.volume -= 5;
        }

        private void mute_Click(object sender, EventArgs e)
        {
            //静音
            if (this.axWmp.settings.mute == true)
            {
                //true代表静音
                this.axWmp.settings.mute = false;
                mute.Image = global::KidSparkPainting.Properties.Resources.VOICE;
            }
            else if (this.axWmp.settings.mute == false)
            {
                this.axWmp.settings.mute = true;
                mute.Image = global::KidSparkPainting.Properties.Resources.NOVOICE;
            }
        }

        //销毁该对象
        private void exit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        //隐藏视频工具栏
        private void HidePanel_Click(object sender, EventArgs e)
        {
            //panelOperate.Visible = false;
            panelOperate.Height = 0;
            panelMain.Location = new Point(0,0);
            this.Width = panelMain.Width;
            this.Height = panelMain.Height;
        }

        private void axWmp_MouseDownEvent(object sender, AxWMPLib._WMPOCXEvents_MouseDownEvent e)
        {
            panelOperate.Height = 31;
            this.Width = panelMain.Width + 2 * mediadelta;
            this.Height = panelMain.Height + 2 * mediadelta;
            panelMain.Location = new Point(mediadelta, mediadelta);
        }

    }
}