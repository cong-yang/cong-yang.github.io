﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using AxShockwaveFlashObjects;

namespace KidSparkPainting
{
    public partial class FlashPlayer : UserControl
    {
        // 支持的文件格式
        private const string SurpportExt = ".swf";
        // 播放状态
        private PlayMode mPlayMode = PlayMode.Stop;
        // 要等待开始播放的url
        private string mWaitUrl = "";
        private const int Flashdelta = 10;

        public FlashPlayer()
        {
            InitializeComponent();
        }
        /// 播放状态
        private enum PlayMode
        {
            /// <summary>
            /// 播放
            /// </summary>
            Play,
            /// <summary>
            /// 暂停
            /// </summary>
            Pause,
            /// <summary>
            /// 停止
            /// </summary>
            Stop,
        } ;

        //开启定时器
        private void UpdateTimerStart()
        {
            mFlashPlayerTimer.Interval = 500;
            if (mFlashPlayerTimer != null)
            {
                if (!mFlashPlayerTimer.Enabled)
                {
                    mFlashPlayerTimer.Start();
                }
            }
        }

        //停止定时器
        private void UpdateTimerStop()
        {
            if (mFlashPlayerTimer != null)
            {
                if (mFlashPlayerTimer.Enabled)
                {
                    mFlashPlayerTimer.Stop();
                }
            }
        }

        /// <summary>
        /// flash播放器播放
        /// </summary>
        private void FlashPlayerPlay()
        {
            AxFlashPlayer.Play();
            mPlayMode = PlayMode.Play;
            UpdateTimerStart();
        }

        //用来判断所选择的文件是否为flash
        private static bool IsFileFlash(string url)
        {
            string ext = Path.GetExtension(url);
            if (ext.Equals(SurpportExt))
            {
                return true;
            }
            return false;
        }

        /// 打开并选择flash,对外主接口
        public void StartPlayFlash(string flashpath)
        {
            if (IsFileFlash(flashpath))
            {
                mWaitUrl = flashpath;
                AxFlashPlayer.Movie = mWaitUrl;
                FlashPlayerPlay();
                mPlayMode = PlayMode.Play;
            }
            else
            {
                MessageBox.Show("flash文件打开失败");
            }
        }

        //播放
        private void Play_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(mWaitUrl))
            {
                AxFlashPlayer.Movie = mWaitUrl;
                FlashPlayerPlay();
                mPlayMode = PlayMode.Play;
            }
        }


        //暂停
        private void Pause_Click(object sender, EventArgs e)
        {
            if (mPlayMode == PlayMode.Pause || mPlayMode == PlayMode.Stop)
            {
                if (!string.IsNullOrEmpty(mWaitUrl))
                {
                    AxFlashPlayer.Movie = mWaitUrl;
                    FlashPlayerPlay();
                }
            }
            else
            {
                FlashPlayerPause();
            }
        }

        /// flash播放器暂停
        private void FlashPlayerPause()
        {
            AxFlashPlayer.Stop();
            mPlayMode = PlayMode.Pause;
            UpdateTimerStop();
        }

        //停止
        private void Stop_Click(object sender, EventArgs e)
        {
            FlashPlayerStop();
        }

        /// flash播放器停止
        private void FlashPlayerStop()
        {
            FlashPlayerFirstFrame();
            UpdateTimerStop();
        }

        /// 第一帧
        private void FlashPlayerFirstFrame()
        {
            AxFlashPlayer.Rewind();
        }

        //删除
        private void Delete_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        //隐藏工具栏
        private void HidePanel_Click(object sender, EventArgs e)
        {
            panelOperate.Height = 11;
            panelMain.Location = new Point(0, 0);
            this.Width = panelMain.Width;
            this.Height = panelMain.Height;

            ShowTools.Visible = true;
            Play.Visible = false;
            Stop.Visible = false;
            Delete.Visible = false;
            HidePanel.Visible = false;
        }

        //显示工具栏
        private void ShowTools_Click(object sender, EventArgs e)
        {
            ShowTools.Visible = false;
            Play.Visible = true;
            Stop.Visible = true;
            Delete.Visible = true;
            HidePanel.Visible = true;
            panelOperate.Height = 31;
            this.Width = panelMain.Width + 2 * Flashdelta;
            this.Height = panelMain.Height + 2 * Flashdelta;
            panelMain.Location = new Point(Flashdelta, Flashdelta);
        }
    }
}