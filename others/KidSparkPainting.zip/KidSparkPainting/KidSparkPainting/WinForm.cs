﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using System.Runtime.InteropServices;

namespace KidSparkPainting
{
    public partial class WinForm : Form
    {
        public WinForm()
        {
            InitializeComponent();
            //this.skinEngine.SkinFile = "MP10.ssk";    //变换皮肤
        }

        #region 画板参数

        public int picnamenumber = 0;  //保存画板的编号参数
        public string boardsaveimgpath = Application.StartupPath + @"\Data\"; //画板保存文件所在路径
        private bool showlefttools = true;  //是否显示右侧的工具栏

        #endregion 画板参数

        #region 页面加载内容

        private void WinForm_Load(object sender, EventArgs e)
        {
            setDrawPlaceLocationAndSize();  //设置画板的大小和位置
            //加载资源文件
            ArrayList piclist = new ArrayList();
            //将所需的文件类型添加进去
            piclist.Add(".GIF");
            //调用方法，用来显示图片列表
            this.loadgifpic(Application.StartupPath + @"\Resources", piclist);

            //初始化笔触大小与颜色
            DrawPlace.m_ColorBack = Color.White; //初始化画板背景色
            DrawPlace.Pen_Color = Color.White;   //初始化画笔颜色为黑色
            DrawPlace.PenSize = 3;               //初始化画笔宽度
            DrawPlace.InkFlow = 255;            //初始化墨水流量

            DrawPlace.TexturePen_MainColor = Color.Black;   //初始化纹理画笔主颜色
            DrawPlace.TexturePen_InsertColor = Color.White; //初始化纹理画笔插入颜色

            DrawPlace.FillColor = Color.Black;  //设置填充框内的默认填充颜色

            DrawPlace.m_enDrawMode = DrawAreaCtrl.WHITEBOARD_DRAW_MODE.enModePencil;    //设置默认为铅笔
            ActivatProper("Pencil");    //初始化属性面板

            picboxpriviewset(); //初始化属性框内的所有控件
        }

        #endregion 页面加载内容

        #region 设置画板大小和位置

        //设置画板的大小和位置
        private void setDrawPlaceLocationAndSize()
        {
            try
            {
                int screenwidth = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width;   //获取主显示器的宽度
                int screenheight = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height; //获取主显示器的高度

                double ratio = (screenwidth * 1.0) / (screenheight * 1.0);//屏幕宽高比，如果在1.8~1.5之间，则为宽屏，如果在1.4~1.2之间，则为窄屏
                if (ratio > 1.5 && ratio < 1.8) //如果是宽屏
                {
                    tabControlLeft.Width = 200;
                }
                else if (ratio > 1.2 && ratio < 1.4) //如果是窄屏
                {
                    tabControlLeft.Width = 220;
                }
                else
                {
                    tabControlLeft.Width = 240;
                }

                //DrawPlace.NewWhiteBoard(0, 0, DrawPlace.Width + tabControlLeft.Width + 30, 
                //DrawPlace.Height + toolStripTools.Height + 30);   //初始化画板背景颜色

                Image backimg = global::KidSparkPainting.Properties.Resources.blackboard;
                DrawPlace.InsertMovePic(0, 0, DrawPlace.Width, DrawPlace.Height, backimg);
                backimg.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("KidBoard Initialization Error:" + ex.Message.ToString());
            }
        }

        #endregion 设置画板大小和位置

        #region 调用工具

        //打开图片
        private void ButtonOpen_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog OpenJpgDialog = new OpenFileDialog();
                OpenJpgDialog.Title = "Select Your Board Document";
                OpenJpgDialog.Filter = "jpg files (*.jpg)|*.jpg|bmp files (*.bmp)|*.bmp";
                if (OpenJpgDialog.ShowDialog() == DialogResult.OK)
                {
                    Image changeboard = Image.FromFile(OpenJpgDialog.FileName);
                    DrawPlace.InsertMovePic(0, 0, changeboard.Width, changeboard.Height, changeboard);
                    changeboard.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        //鼠标工具
        private void ButtonPoint_Click(object sender, EventArgs e)
        {
            DrawPlace.m_enDrawMode = DrawAreaCtrl.WHITEBOARD_DRAW_MODE.enModePoint;
            ActivatProper("Point");
        }

        //铅笔工具
        private void ButtonDrawLine_Click(object sender, EventArgs e)
        {
            DrawPlace.m_enDrawMode = DrawAreaCtrl.WHITEBOARD_DRAW_MODE.enModePencil;
            ActivatProper("Pencil");
        }

        //画矩形
        private void ButtonRec_Click(object sender, EventArgs e)
        {
            DrawPlace.fillornot = DrawAreaCtrl.FillorNot.NotFill;   //默认为不填充模式
            DrawPlace.m_enDrawMode = DrawAreaCtrl.WHITEBOARD_DRAW_MODE.enModeRect;  //启动矩形工具
            ActivatProper("Rectangle");
        }

        //画椭圆
        private void ButtonEllipse_Click(object sender, EventArgs e)
        {
            DrawPlace.fillornot = DrawAreaCtrl.FillorNot.NotFill;   //默认为不填充模式
            DrawPlace.m_enDrawMode = DrawAreaCtrl.WHITEBOARD_DRAW_MODE.enModeEllipse;
            ActivatProper("Ellipse");
        }

        //插入图片
        private void ButtonPic_Click(object sender, EventArgs e)
        {
            DrawPlace.m_enDrawMode = DrawAreaCtrl.WHITEBOARD_DRAW_MODE.enModeInsertPic;
            ActivatProper("InsPic");
        }

        //橡皮擦工具
        private void ButtonClean_Click(object sender, EventArgs e)
        {
            DrawPlace.m_enDrawMode = DrawAreaCtrl.WHITEBOARD_DRAW_MODE.enModeEraser;    //启动橡皮擦工具
            DrawPlace.erasertype = DrawAreaCtrl.EraserType.EraserEllipse;   //默认为椭圆形橡皮擦
            ActivatProper("Eraser");
        }

        //保存
        private void ButtonSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog SaveFileDlg = new SaveFileDialog();
            SaveFileDlg.Filter = "Image Files(*.BMP;*.JPG;*.GIF)|*.BMP;*.JPG;*.GIF|All files (*.*)|*.*";
            SaveFileDlg.FilterIndex = 1;
            SaveFileDlg.RestoreDirectory = true;
            string StrFileName = "";
            if (SaveFileDlg.ShowDialog() == DialogResult.OK)
            {
                StrFileName = SaveFileDlg.FileName;
                DrawPlace.BitmapCanvas.Save(StrFileName);
                //MessageBox.Show(StrFileName);
            }
        }

        //画直线
        private void ButtonSLine_Click(object sender, EventArgs e)
        {
            DrawPlace.m_enDrawMode = DrawAreaCtrl.WHITEBOARD_DRAW_MODE.enModeStraightline;
            ActivatProper("StreatLine");
        }

        //蜡笔效果
        private void ButtonCrayon_Click(object sender, EventArgs e)
        {
            DrawPlace.m_enDrawMode = DrawAreaCtrl.WHITEBOARD_DRAW_MODE.enModeCrayon;
            DrawPlace.CrayonMode = DrawAreaCtrl.CrayonWidth.Thin;   //默认蜡笔效果为细蜡笔
            ActivatProper("Crayon");
        }

        //纹理画笔
        private void ButtonTexturePen_Click(object sender, EventArgs e)
        {
            DrawPlace.m_enDrawMode = DrawAreaCtrl.WHITEBOARD_DRAW_MODE.enModeTexturePen;
            ActivatProper("TexturePen");
        }

        //水墨画
        private void ButtonInkPainting_Click(object sender, EventArgs e)
        {
            DrawPlace.m_enDrawMode = DrawAreaCtrl.WHITEBOARD_DRAW_MODE.enModeInkPainting;
            ActivatProper("InkPainting");
        }

        //饱和毛笔
        private void ButtonChineseBrush_Click(object sender, EventArgs e)
        {
            DrawPlace.m_enDrawMode = DrawAreaCtrl.WHITEBOARD_DRAW_MODE.enModeChineseBrush;
            ActivatProper("ChineseBrush");
        }

        //插入视频
        private void ButtonInsVedio_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog OpenVedioDialog = new OpenFileDialog();
                OpenVedioDialog.Title = "Select Your Vedio";
                OpenVedioDialog.Filter = "Vedio files (*.wmv)|*.wmv|music files (*.mp3)|*.mp3|All files (*.*)|*.*";
                if (OpenVedioDialog.ShowDialog() == DialogResult.OK)
                {
                    getnewmediaplayer(OpenVedioDialog.FileName);
                    ActivatProper("InsVedio");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        //插入flash
        private void ButtonInsFlash_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog OpenFlashDialog = new OpenFileDialog();
                OpenFlashDialog.Title = "Select Your Flash";
                OpenFlashDialog.Filter = "Flash files (*.swf)|*.swf";
                if (OpenFlashDialog.ShowDialog() == DialogResult.OK)
                {
                    getnewflash(OpenFlashDialog.FileName);
                    ActivatProper("InsFlash");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        //添加动态图片
        private void ButtonMoviePic_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog OpenMovePicDialog = new OpenFileDialog();
                OpenMovePicDialog.Title = "Select Your Picture";
                OpenMovePicDialog.Filter = "jpg files (*.jpg)|*.jpg|bmp files (*.bmp)|*.bmp|All files (*.*)|*.*";
                if (OpenMovePicDialog.ShowDialog() == DialogResult.OK)
                {
                    PictureBox movepic = new PictureBox();  //新建图片框
                    movepic.Image = Image.FromFile(OpenMovePicDialog.FileName); //为图片框读取图片
                    movepic.SizeMode = PictureBoxSizeMode.StretchImage; //图片大小自适应图片框的大小
                    movepic.Size = new Size(movepic.Image.Width, movepic.Image.Height); //初始图片框的大小与原始图片大小相同
                    //movepic.BorderStyle = BorderStyle.FixedSingle;
                    this.DrawPlace.Controls.Add(movepic);   //将图片框加入到画图板中

                    movepic.MouseDown += new System.Windows.Forms.MouseEventHandler(MyMouseDown);   //为图片框增加动作
                    movepic.MouseLeave += new System.EventHandler(MyMouseLeave);
                    movepic.MouseMove += new System.Windows.Forms.MouseEventHandler(MyMouseMove);
                    movepic.DoubleClick += new EventHandler(movepic_DoubleClick);   //图片框双击后图片嵌入到背景

                    ActivatProper("InsMovePic");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        //新建白板
        private void ButtonNew_Click(object sender, EventArgs e)
        {
            try
            {
                //将第一个白板保存到临时文件夹中
                string savedimgname = boardsaveimgpath + picnamenumber.ToString() + ".BMP";
                DrawPlace.BitmapCanvas.Save(savedimgname);   //将临时画图保存在Data文件夹中
                //Image picboximg = Image.FromFile(savedimgname);

                //新建一个白板
                //DrawPlace.NewWhiteBoard(0, 0, DrawPlace.Width + tabControlLeft.Width + 30, DrawPlace.Height + toolStripTools.Height + 30);
                Image backimg = global::KidSparkPainting.Properties.Resources.blackboard;
                DrawPlace.InsertMovePic(0, 0, DrawPlace.Width, DrawPlace.Height, backimg);
                backimg.Dispose();


                //在左侧的图片中显示已画图片的缩略图
                PictureBox picdrawn = new PictureBox();
                picdrawn.Name = picnamenumber.ToString();
                picdrawn.Image = Image.FromFile(savedimgname);
                picdrawn.SizeMode = PictureBoxSizeMode.StretchImage;
                picdrawn.Size = new Size(140, 110);
                picdrawn.BorderStyle = BorderStyle.FixedSingle;
                picdrawn.Cursor = Cursors.Hand; //鼠标样式
                Tab_DrawedBoard.Controls.Add(picdrawn);
                int picdrawnleft = (int)((tabControlLeft.Width - picdrawn.Width) / 3);
                picdrawn.Location = new Point(picdrawnleft, picnamenumber * picdrawn.Height + 20);
                //MessageBox.Show((picnamenumber * picdrawn.Height).ToString());
                picdrawn.MouseClick += new MouseEventHandler(picdrawn_MouseClick);  //为图片增加单击事件

                picnamenumber++;    //名称加一
            }
            catch (Exception ex)
            {
                MessageBox.Show("Creat New Board Error:" + ex.Message.ToString());
            }
        }

        //打开PPT
        private void ButtonOpenPPT_Click(object sender, EventArgs e)
        {
            //HideAllForm();
            try
            {
                OpenDocWinForm openppt = new OpenDocWinForm();
                OpenFileDialog OpenPPTDialog = new OpenFileDialog();
                OpenPPTDialog.Title = "Select PPT Document";
                OpenPPTDialog.Filter = "PPT Files (*.ppt;*.pptx;*.pot)|*.ppt;*.pptx;*.pot";
                if (OpenPPTDialog.ShowDialog() == DialogResult.OK)
                {
                    //将被转换的ppt位置+名称以及被转换ppt类型，有.ppt/.pot/.pptx传送过去
                    openppt.GetDoc(OpenPPTDialog.FileName, Path.GetFileName(OpenPPTDialog.FileName), Path.GetExtension(OpenPPTDialog.FileName.ToLower()));
                    openppt.Text = OpenPPTDialog.FileName;
                    openppt.Show();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        //打开PDF
        private void ButtonOpenPDF_Click(object sender, EventArgs e)
        {
            try
            {
                OpenDocWinForm opendoc = new OpenDocWinForm();
                OpenFileDialog OpenPDFDialog = new OpenFileDialog();
                OpenPDFDialog.Title = "Select PDF Document";
                OpenPDFDialog.Filter = "Pdf Files (*.pdf)|*.pdf";
                if (OpenPDFDialog.ShowDialog() == DialogResult.OK)
                {
                    //将被转换的ppt位置+名称以及被转换ppt类型，有.pdf或者.PDF传送过去
                    opendoc.GetDoc(OpenPDFDialog.FileName, Path.GetFileName(OpenPDFDialog.FileName), Path.GetExtension(OpenPDFDialog.FileName.ToLower()));
                    opendoc.Text = OpenPDFDialog.FileName;
                    opendoc.Show();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        //显示摄像头FLASH
        private void ButtonCamera_Click(object sender, EventArgs e)
        {
            /*int camaravedionumber = 0;  //用来记录画板中的视频聊天窗口数量
            foreach (Control cameraflash in DrawPlace.Controls)
            {
                if (cameraflash.Name == "FlashVedioCamera")
                {
                    camaravedionumber++;
                }
            }

            if (camaravedionumber == 0) //如果画板中没有视频聊天窗口
            {
                CamaraVedio camaravedio = new CamaraVedio();
                camaravedio.Name = "FlashVedioCamera";
                DrawPlace.Controls.Add(camaravedio);
                camaravedio.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
                camaravedio.Size = new Size(348,348);
                camaravedio.Location = new Point(DrawPlace.Width - camaravedio.Width, 0);
                //camaravedio.StartPlayFlash(@"F:\working\puzzle.swf");
                //MessageBox.Show(camaravedionumber.ToString());
            }
            else
            {
                return;
            }*/

            //FormCameraVedio cameravedio = new FormCameraVedio();
            //cameravedio.Show();
            try
            {
                System.Diagnostics.Process process = new System.Diagnostics.Process();
                process.StartInfo.FileName = Application.StartupPath + @"\Camera\Camera.exe";
                process.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Camera Error:" + ex.Message.ToString());
            }
        }

        //退出
        private void ButtonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //左侧工具栏是否显示
        private void ButtonLefTools_Click(object sender, EventArgs e)
        {
            /*if (showlefttools)
            {
                tabControlLeft.Visible = false;
                showlefttools = false;
                ButtonLefTools.Image = global::KidSparkPainting.Properties.Resources.NOTSHOWTOOLS;
                ButtonLefTools.Text = "Show Left Tools";
            }
            else
            {
                tabControlLeft.Visible = true;
                showlefttools = true;
                ButtonLefTools.Image = global::KidSparkPainting.Properties.Resources.SHOWTOOLS;
                ButtonLefTools.Text = "Hide Ledt Tools";
            }*/
            this.WindowState = FormWindowState.Minimized;
        }

        //帮助
        private void ButtonHelp_Click(object sender, EventArgs e)
        {

        }

        //启动桌面共享程序
        private void ButtonSharePalette_Click(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Process process = new System.Diagnostics.Process();
                process.StartInfo.FileName = Application.StartupPath + @"\ShareDeskTop\client.exe";
                process.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Share Error:" + ex.Message.ToString());
            }
        }

        #endregion 调用工具

        #region 左侧属性面板控制

        //笔触宽度滑动按钮
        private void trackBarPenWidth_Scroll(object sender, EventArgs e)
        {
            ShapePenPriview.Width = trackBarPenWidth.Value;
            ShapePenPriview.Height = trackBarPenWidth.Value;
            ShapePenPriview.Left = (int)((panelpriview.Width - ShapePenPriview.Width) / 2);
            ShapePenPriview.Top = (int)((panelpriview.Height - ShapePenPriview.Height) / 2);
            labelPenWidth.Text = "Pen Width   " + trackBarPenWidth.Value.ToString();
            DrawPlace.PenSize = trackBarPenWidth.Value; //将笔触宽度值赋值
        }

        //选择笔触颜色
        private void ColorPickerPenColor_SelectedColorChanged(object sender, EventArgs e)
        {
            ShapePenPriview.BackColor = ColorPickerPenColor.Color;
            DrawPlace.Pen_Color = ColorPickerPenColor.Color;
        }

        //墨水流量控制
        private void trackBarInkFlow_Scroll(object sender, EventArgs e)
        {
            double inkflowvalue = ((trackBarInkFlow.Value * 1.0) / (trackBarInkFlow.Maximum * 1.0)) * 100;
            labelInkFlow.Text = "Ink Flow   " + inkflowvalue.ToString("##.") + "%";
            DrawPlace.InkFlow = trackBarInkFlow.Value;
        }

        #region 选择蜡笔粗细
        //选择细蜡笔
        private void pictureBoxLabixi_Click(object sender, EventArgs e)
        {
            pictureBoxLabixi.BorderStyle = BorderStyle.FixedSingle;
            pictureBoxLabizhong.BorderStyle = BorderStyle.None;
            pictureBoxlabicu.BorderStyle = BorderStyle.None;
            DrawPlace.CrayonMode = DrawAreaCtrl.CrayonWidth.Thin;   //选择细蜡笔
        }

        //选择中蜡笔
        private void pictureBoxLabizhong_Click(object sender, EventArgs e)
        {
            pictureBoxLabixi.BorderStyle = BorderStyle.None;
            pictureBoxLabizhong.BorderStyle = BorderStyle.FixedSingle;
            pictureBoxlabicu.BorderStyle = BorderStyle.None;
            DrawPlace.CrayonMode = DrawAreaCtrl.CrayonWidth.Middle;   //选择中等蜡笔
        }

        //选择粗蜡笔
        private void pictureBoxlabicu_Click(object sender, EventArgs e)
        {
            pictureBoxLabixi.BorderStyle = BorderStyle.None;
            pictureBoxLabizhong.BorderStyle = BorderStyle.None;
            pictureBoxlabicu.BorderStyle = BorderStyle.FixedSingle;
            DrawPlace.CrayonMode = DrawAreaCtrl.CrayonWidth.Thick;   //选择粗蜡笔
        }
        #endregion 选择蜡笔粗细

        #region 纹理画笔属性选择
        //纹理画笔主色选择
        private void TexturePenColorPickerMain_SelectedColorChanged(object sender, EventArgs e)
        {
            labelTextureMain.BackColor = TexturePenColorPickerMain.Color;
            DrawPlace.TexturePen_MainColor = TexturePenColorPickerMain.Color;
            DrawPlace.ChangeTexturePen(DrawPlace.TexturePen_Hatchstyle, TexturePenColorPickerMain.Color, DrawPlace.TexturePen_InsertColor);
        }

        //纹理画笔嵌入色选择
        private void TexturePenColorPickerInsert_SelectedColorChanged(object sender, EventArgs e)
        {
            labelTextureInsert.BackColor = TexturePenColorPickerInsert.Color;
            DrawPlace.TexturePen_InsertColor = TexturePenColorPickerInsert.Color;
            DrawPlace.ChangeTexturePen(DrawPlace.TexturePen_Hatchstyle, DrawPlace.TexturePen_MainColor, TexturePenColorPickerInsert.Color);
        }

        //更多纹理画笔
        private void labelTexturePenMore_Click(object sender, EventArgs e)
        {
            MoreTexturePen moretesturepen = new MoreTexturePen();
            moretesturepen.ShowDialog(this);
        }

        #endregion 纹理画笔属性选择

        #region 填充属性

        //选择填充的颜色
        private void comboBoxColorPickerFillColor_SelectedColorChanged(object sender, EventArgs e)
        {
            Fill.BackColor = comboBoxColorPickerFillColor.Color;
            DrawPlace.FillColor = comboBoxColorPickerFillColor.Color;
        }

        //用填充模式画圆或者矩形
        private void Fill_Click(object sender, EventArgs e)
        {
            DrawPlace.fillornot = DrawAreaCtrl.FillorNot.Fill;  //启动填充模式
        }

        //用非填充模式画圆或者矩形
        private void NotFill_Click(object sender, EventArgs e)
        {
            DrawPlace.fillornot = DrawAreaCtrl.FillorNot.NotFill;   //关闭填充模式
        }

        #endregion 填充属性

        #region 橡皮擦属性

        //圆形橡皮擦
        private void EraserEllipse_Click(object sender, EventArgs e)
        {
            DrawPlace.erasertype = DrawAreaCtrl.EraserType.EraserEllipse;   //椭圆形橡皮擦
            DrawPlace.Cursor = new Cursor(Application.StartupPath + @"\ERASEReLLIPSE.cur");
        }

        //矩形橡皮擦
        private void EraserRectangle_Click(object sender, EventArgs e)
        {
            DrawPlace.erasertype = DrawAreaCtrl.EraserType.EraserRectangle; //矩形橡皮擦
            DrawPlace.Cursor = new Cursor(Application.StartupPath + @"\ERASERRectangle.cur");
        }

        #endregion 橡皮擦属性

        #endregion 左侧属性面板控制

        #region 具体方法函数

        //添加视频
        private void getnewmediaplayer(string path)
        {
            MediaPlayer mediaplayer = new MediaPlayer();
            //this.SuspendLayout();
            this.DrawPlace.Controls.Add(mediaplayer);
            mediaplayer.StartPlayMedia(path);
            mediaplayer.MouseDown += new System.Windows.Forms.MouseEventHandler(MediaMouseDown);
            mediaplayer.MouseLeave += new System.EventHandler(MediaMouseLeave);
            mediaplayer.MouseMove += new System.Windows.Forms.MouseEventHandler(MediaMouseMove);
        }

        //添加flash
        private void getnewflash(string flashpath)
        {
            FlashPlayer flashplayer = new FlashPlayer();
            this.SuspendLayout();
            this.DrawPlace.Controls.Add(flashplayer);
            flashplayer.StartPlayFlash(flashpath);
            flashplayer.MouseDown += new System.Windows.Forms.MouseEventHandler(FlashMouseDown);
            flashplayer.MouseLeave += new System.EventHandler(FlashMouseLeave);
            flashplayer.MouseMove += new System.Windows.Forms.MouseEventHandler(FlashMouseMove);
        }

        //双击固定移动变换后的图片
        private void movepic_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                PictureBox picbox = (PictureBox)sender;
                //MessageBox.Show(picbox.Top.ToString() + "  " + picbox.Left.ToString() + "  " + picbox.Width.ToString() + "  " + picbox.Height.ToString());
                this.DrawPlace.InsertMovePic(picbox.Left, picbox.Top, picbox.Width, picbox.Height, picbox.Image);
                picbox.Dispose();
                this.Cursor = System.Windows.Forms.Cursors.Default;
            }
            catch (Exception pic_Click_Error)
            {
                MessageBox.Show(pic_Click_Error.ToString());
            }
        }

        //单击左侧画板缩略图
        private void picdrawn_MouseClick(object sender, MouseEventArgs e)
        {
            PictureBox picboxleft = (PictureBox)sender;
            //MessageBox.Show(picboxleft.Name);
            Image changeboard = Image.FromFile(boardsaveimgpath + picboxleft.Name + ".BMP");
            DrawPlace.InsertMovePic(0, 0, changeboard.Width, changeboard.Height, changeboard);
            changeboard.Dispose();
        }

        //显示资源文件夹下的资源
        private void loadgifpic(string strPath, ArrayList lstExtend)
        {
            DirectoryInfo fdir = new DirectoryInfo(strPath);
            FileInfo[] file = fdir.GetFiles();
            int pictop = 10;
            foreach (FileInfo f in file)
            {
                //如果文件的扩展名包含于该ArrayList内
                if (lstExtend.Contains(f.Extension.ToUpper()))
                {
                    PictureBox picresources = new PictureBox();  //新建画板

                    picresources.Name = f.Name.ToString();
                    Image resourcesimg = Image.FromFile(f.FullName.ToString());
                    picresources.Image = resourcesimg;
                    picresources.SizeMode = PictureBoxSizeMode.StretchImage;
                    picresources.Size = new Size(resourcesimg.Width, resourcesimg.Height);
                    Tab_Imgbase.Controls.Add(picresources);
                    int picresourcesleft = (int)((Tab_Imgbase.Width - picresources.Width) / 3);
                    picresources.Location = new Point(picresourcesleft, pictop + 5);
                    picresources.Cursor = Cursors.Hand;
                    picresources.MouseClick += new MouseEventHandler(picresources_MouseClick);
                    pictop += picresources.Height;
                }
            }
        }

        //将资源图片添加到画板中
        private void picresources_MouseClick(object sender, MouseEventArgs e)
        {
            try
            {
                PictureBox picboxresources = (PictureBox)sender;    //读取被单击对象
                PictureBox movepic = new PictureBox();  //新建图片框
                movepic.Image = Image.FromFile(Application.StartupPath + @"\Resources\" + picboxresources.Name); //为图片框读取图片
                movepic.SizeMode = PictureBoxSizeMode.StretchImage; //图片大小自适应图片框的大小
                movepic.Size = new Size(movepic.Image.Width, movepic.Image.Height); //初始图片框的大小与原始图片大小相同
                movepic.BorderStyle = BorderStyle.FixedSingle;
                this.DrawPlace.Controls.Add(movepic);   //将图片框加入到画图板中

                //为图片增加移动效果
                movepic.MouseDown += new System.Windows.Forms.MouseEventHandler(MyMouseDown);   //为图片框增加动作
                movepic.MouseLeave += new System.EventHandler(MyMouseLeave);
                movepic.MouseMove += new System.Windows.Forms.MouseEventHandler(MyMouseMove);
                movepic.DoubleClick += new EventHandler(movepic_DoubleClick);   //图片框双击后图片嵌入到背景
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        //笔触预览，笔触大小
        private void picboxpriviewset()
        {
            trackBarPenWidth.Value = DrawPlace.PenSize;
            ShapePenPriview.Width = trackBarPenWidth.Value;
            ShapePenPriview.Height = trackBarPenWidth.Value;
            ShapePenPriview.BackColor = DrawPlace.Pen_Color;
            ShapePenPriview.Left = (int)((panelpriview.Width - ShapePenPriview.Width) / 2);
            ShapePenPriview.Top = (int)((panelpriview.Height - ShapePenPriview.Height) / 2);
            labelPenWidth.Text = "Pen Width   " + trackBarPenWidth.Value.ToString();

            trackBarInkFlow.Value = DrawPlace.InkFlow;
            double inkflowvalue = ((trackBarInkFlow.Value * 1.0) / (trackBarInkFlow.Maximum * 1.0)) * 100;
            labelInkFlow.Text = "Ink Flow   " + inkflowvalue.ToString("##.") + "%";

            ColorPickerPenColor.Color = DrawPlace.Pen_Color;    //除过纹理画笔外的其他画笔默认颜色

            TexturePenColorPickerMain.Color = DrawPlace.TexturePen_MainColor;   //纹理画笔主色选择框颜色
            labelTextureMain.BackColor = DrawPlace.TexturePen_MainColor;    //纹理画笔主色预览颜色

            TexturePenColorPickerInsert.Color = DrawPlace.TexturePen_InsertColor;   //纹理画笔插入色选择框颜色
            labelTextureInsert.BackColor = DrawPlace.TexturePen_InsertColor;        //纹理画笔插入色预览颜色

            comboBoxColorPickerFillColor.Color = DrawPlace.FillColor;    //填充颜色选择框颜色
            Fill.BackColor = DrawPlace.FillColor;   //填充颜色预览框颜色
        }

        //属性面板激活
        private void ActivatProper(string drawtype)
        {
            /*
             this.Cursor如果你有 动画光标(*.ani),静态光标(*.cur).可以使用 
             * this.Cursor = new Cursor(文件名);
             */
            string programpath = Application.StartupPath + @"\";
            switch (drawtype)
            {
                #region 鼠标工具
                case "Point":           //鼠标工具
                    Properuseless();        //所有属性失效
                    DrawPlace.Cursor = new Cursor(programpath + "Point.cur");
                    break;
                #endregion 鼠标工具
                #region 铅笔工具
                case "Pencil":      //铅笔工具
                    Properuseless();                    //所有属性失效
                    panelpriview.Visible = true;        //画笔预览面板
                    panelPenWidth.Visible = true;       //笔触宽度面板
                    panelInkFlow.Visible = true;        //墨水流量面板
                    panelPenColor.Visible = true;       //颜色选择面板
                    DrawPlace.Cursor = new Cursor(programpath + "Pencil.cur");
                    break;
                #endregion 铅笔工具
                #region 矩形工具
                case "Rectangle":   //矩形工具
                    Properuseless();                    //所有属性失效
                    panelpriview.Visible = true;        //画笔预览面板
                    panelPenWidth.Visible = true;       //笔触宽度面板
                    panelInkFlow.Visible = true;        //墨水流量面板
                    panelPenColor.Visible = true;       //颜色选择面板
                    panelDrawFill.Visible = true;     //填充控制面板
                    DrawPlace.Cursor = new Cursor(programpath + "Rectangle.cur");
                    break;
                #endregion 矩形工具
                #region 椭圆工具
                case "Ellipse":     //椭圆工具
                    Properuseless();                    //所有属性失效
                    panelpriview.Visible = true;        //画笔预览面板
                    panelPenWidth.Visible = true;       //笔触宽度面板
                    panelInkFlow.Visible = true;        //墨水流量面板
                    panelPenColor.Visible = true;       //颜色选择面板
                    panelDrawFill.Visible = true;       //填充控制面板
                    DrawPlace.Cursor = new Cursor(programpath + "Ellipse.cur");
                    break;
                #endregion 椭圆工具
                #region 橡皮擦工具
                case "Eraser":      //橡皮擦工具
                    Properuseless();                    //所有属性失效
                    panelpriview.Visible = true;        //画笔预览面板
                    panelPenWidth.Visible = true;       //笔触宽度面板
                    panelEraser.Visible = true;         //橡皮擦控制面板
                    DrawPlace.Cursor = new Cursor(programpath + "ERASEReLLIPSE.cur");
                    break;
                #endregion 橡皮擦工具
                #region 插入普通图片
                case "InsPic":      //插入普通图片
                    Properuseless();                    //所有属性失效
                    DrawPlace.Cursor = new Cursor(programpath + "Hand.cur");
                    break;
                #endregion 插入普通图片
                #region 插入动态图片
                case "InsMovePic":  //插入动态图片
                    //Properuseless();                    //所有属性失效
                    break;
                #endregion 插入动态图片
                #region 直线工具
                case "StreatLine":  //直线工具
                    Properuseless();                    //所有属性失效
                    panelpriview.Visible = true;        //画笔预览面板
                    panelPenWidth.Visible = true;       //笔触宽度面板
                    panelInkFlow.Visible = true;        //墨水流量面板
                    panelPenColor.Visible = true;       //颜色选择面板
                    DrawPlace.Cursor = new Cursor(programpath + "Line.cur");
                    break;
                #endregion 直线工具
                #region 蜡笔工具
                case "Crayon":      //蜡笔工具
                    Properuseless();                    //所有属性失效
                    panelInkFlow.Visible = true;        //墨水流量面板
                    panelPenColor.Visible = true;       //颜色选择面板
                    panellabi.Visible = true;           //蜡笔样式面板
                    DrawPlace.Cursor = new Cursor(programpath + "Labi.cur");
                    break;
                #endregion 蜡笔工具
                #region 纹理画笔
                case "TexturePen":  //纹理画笔
                    Properuseless();                    //所有属性失效
                    panelpriview.Visible = true;        //画笔预览面板
                    panelPenWidth.Visible = true;       //笔触宽度面板
                    panelTexturePen.Visible = true;     //纹理画笔面板
                    DrawPlace.PenSize = 20;             //初始化纹理画笔的宽度
                    trackBarPenWidth.Value = 20;        //同步滑动条与现实标签
                    labelPenWidth.Text = "Pen Width   " + trackBarPenWidth.Value.ToString();
                    ShapePenPriview.Width = 20;
                    ShapePenPriview.Height = 20;
                    ShapePenPriview.Left = (int)((panelpriview.Width - 20) / 2);
                    ShapePenPriview.Top = (int)((panelpriview.Height - 20) / 2);
                    DrawPlace.Cursor = new Cursor(programpath + "wenlihuabi.cur");
                    break;
                #endregion 纹理画笔
                #region 水墨画
                case "InkPainting": //水墨画
                    Properuseless();                    //所有属性失效
                    panelpriview.Visible = true;        //画笔预览面板
                    panelPenWidth.Visible = true;       //笔触宽度面板
                    panelPenColor.Visible = true;       //颜色选择面板
                    DrawPlace.PenSize = 27;             //初始化水墨画笔的宽度
                    trackBarPenWidth.Value = 27;        //同步滑动条与现实标签
                    labelPenWidth.Text = "Pen Width   " + trackBarPenWidth.Value.ToString();
                    ShapePenPriview.Width = 27;
                    ShapePenPriview.Height = 27;
                    ShapePenPriview.Left = (int)((panelpriview.Width - 27) / 2);
                    ShapePenPriview.Top = (int)((panelpriview.Height - 27) / 2);
                    DrawPlace.Cursor = new Cursor(programpath + "ChineseBruse.cur");
                    break;
                #endregion 水墨画
                #region 饱和毛笔
                case "ChineseBrush"://饱和毛笔
                    Properuseless();                    //所有属性失效
                    panelpriview.Visible = true;        //画笔预览面板
                    panelPenWidth.Visible = true;       //笔触宽度面板
                    panelInkFlow.Visible = true;        //墨水流量面板
                    panelPenColor.Visible = true;       //颜色选择面板
                    DrawPlace.Cursor = new Cursor(programpath + "baohemaobi.cur");
                    break;
                #endregion 饱和毛笔
                #region 插入视频
                case "InsVedio":    //插入视频
                    //Properuseless();                    //所有属性失效
                    break;
                #endregion 插入视频
                #region 插入Flash
                case "InsFlash":    //插入Flash
                    //Properuseless();                    //所有属性失效
                    break;
                #endregion 插入Flash
            }
        }

        //属性面板所有控件不可用
        private void Properuseless()
        {
            foreach (Control c in Tab_Property.Controls)
            {
                c.Visible = false;
            }
        }

        #endregion 具体函数

        #region 移动效果

        #region 图片移动

        //1、定义一个枚举类型，描述光标状态
        private enum EnumMousePointPosition
        {
            MouseSizeNone = 0, //'无
            MouseSizeRight = 1, //'拉伸右边框
            MouseSizeLeft = 2, //'拉伸左边框
            MouseSizeBottom = 3, //'拉伸下边框
            MouseSizeTop = 4, //'拉伸上边框
            MouseSizeTopLeft = 5, //'拉伸左上角
            MouseSizeTopRight = 6, //'拉伸右上角
            MouseSizeBottomLeft = 7, //'拉伸左下角
            MouseSizeBottomRight = 8, //'拉伸右下角
            MouseDrag = 9 // '鼠标拖动
        }

        //2、定义几个变量
        const int Band = 5;
        const int MinWidth = 10;
        const int MinHeight = 10;
        private EnumMousePointPosition m_MousePointPosition;
        private Point p, p1;

        //3、定义自己的MyMouseDown事件
        private void MyMouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            p.X = e.X;
            p.Y = e.Y;

            p1.X = e.X;
            p1.Y = e.Y;
        }

        //4、定义自己的MyMouseLeave事件
        private void MyMouseLeave(object sender, System.EventArgs e)
        {
            m_MousePointPosition = EnumMousePointPosition.MouseSizeNone;
            this.Cursor = Cursors.Arrow;
        }

        //5、设计一个函数，确定光标在控件不同位置的样式
        private EnumMousePointPosition MousePointPosition(Size size, System.Windows.Forms.MouseEventArgs e)
        {

            if ((e.X >= -1 * Band) | (e.X <= size.Width) | (e.Y >= -1 * Band) | (e.Y <= size.Height))
            {
                if (e.X < Band)
                {
                    if (e.Y < Band) { return EnumMousePointPosition.MouseSizeTopLeft; }
                    else
                    {
                        if (e.Y > -1 * Band + size.Height)
                        { return EnumMousePointPosition.MouseSizeBottomLeft; }
                        else
                        { return EnumMousePointPosition.MouseSizeLeft; }
                    }
                }
                else
                {
                    if (e.X > -1 * Band + size.Width)
                    {
                        if (e.Y < Band)
                        { return EnumMousePointPosition.MouseSizeTopRight; }
                        else
                        {
                            if (e.Y > -1 * Band + size.Height)
                            { return EnumMousePointPosition.MouseSizeBottomRight; }
                            else
                            { return EnumMousePointPosition.MouseSizeRight; }
                        }
                    }
                    else
                    {
                        if (e.Y < Band)
                        { return EnumMousePointPosition.MouseSizeTop; }
                        else
                        {
                            if (e.Y > -1 * Band + size.Height)
                            { return EnumMousePointPosition.MouseSizeBottom; }
                            else
                            { return EnumMousePointPosition.MouseDrag; }
                        }
                    }
                }
            }
            else
            {
                return EnumMousePointPosition.MouseSizeNone;
            }
        }

        //6、定义自己的MyMouseMove事件，在这个事件里，会使用上面设计的函数
        private void MyMouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            Control lCtrl = (sender as Control);

            if (e.Button == MouseButtons.Left)
            {
                switch (m_MousePointPosition)
                {
                    case EnumMousePointPosition.MouseDrag:
                        lCtrl.Left = lCtrl.Left + e.X - p.X;
                        lCtrl.Top = lCtrl.Top + e.Y - p.Y;
                        break;
                    case EnumMousePointPosition.MouseSizeBottom:
                        lCtrl.Height = lCtrl.Height + e.Y - p1.Y;
                        p1.X = e.X;
                        p1.Y = e.Y; //'记录光标拖动的当前点
                        break;
                    case EnumMousePointPosition.MouseSizeBottomRight:
                        lCtrl.Width = lCtrl.Width + e.X - p1.X;
                        lCtrl.Height = lCtrl.Height + e.Y - p1.Y;
                        p1.X = e.X;
                        p1.Y = e.Y; //'记录光标拖动的当前点
                        break;
                    case EnumMousePointPosition.MouseSizeRight:
                        lCtrl.Width = lCtrl.Width + e.X - p1.X;
                        //      lCtrl.Height = lCtrl.Height + e.Y - p1.Y;
                        p1.X = e.X;
                        p1.Y = e.Y; //'记录光标拖动的当前点
                        break;
                    case EnumMousePointPosition.MouseSizeTop:
                        lCtrl.Top = lCtrl.Top + (e.Y - p.Y);
                        lCtrl.Height = lCtrl.Height - (e.Y - p.Y);
                        break;
                    case EnumMousePointPosition.MouseSizeLeft:
                        lCtrl.Left = lCtrl.Left + e.X - p.X;
                        lCtrl.Width = lCtrl.Width - (e.X - p.X);
                        break;
                    case EnumMousePointPosition.MouseSizeBottomLeft:
                        lCtrl.Left = lCtrl.Left + e.X - p.X;
                        lCtrl.Width = lCtrl.Width - (e.X - p.X);
                        lCtrl.Height = lCtrl.Height + e.Y - p1.Y;
                        p1.X = e.X;
                        p1.Y = e.Y; //'记录光标拖动的当前点
                        break;
                    case EnumMousePointPosition.MouseSizeTopRight:
                        lCtrl.Top = lCtrl.Top + (e.Y - p.Y);
                        lCtrl.Width = lCtrl.Width + (e.X - p1.X);
                        lCtrl.Height = lCtrl.Height - (e.Y - p.Y);
                        p1.X = e.X;
                        p1.Y = e.Y; //'记录光标拖动的当前点
                        break;
                    case EnumMousePointPosition.MouseSizeTopLeft:
                        lCtrl.Left = lCtrl.Left + e.X - p.X;
                        lCtrl.Top = lCtrl.Top + (e.Y - p.Y);
                        lCtrl.Width = lCtrl.Width - (e.X - p.X);
                        lCtrl.Height = lCtrl.Height - (e.Y - p.Y);
                        break;
                    default:
                        break;
                }
                if (lCtrl.Width < MinWidth) lCtrl.Width = MinWidth;
                if (lCtrl.Height < MinHeight) lCtrl.Height = MinHeight;

            }
            else
            {
                m_MousePointPosition = MousePointPosition(lCtrl.Size, e); //'判断光标的位置状态
                switch (m_MousePointPosition) //'改变光标
                {
                    case EnumMousePointPosition.MouseSizeNone:
                        this.Cursor = Cursors.Arrow;       //'箭头
                        break;
                    case EnumMousePointPosition.MouseDrag:
                        this.Cursor = Cursors.SizeAll;     //'四方向
                        break;
                    case EnumMousePointPosition.MouseSizeBottom:
                        this.Cursor = Cursors.SizeNS;      //'南北
                        break;
                    case EnumMousePointPosition.MouseSizeTop:
                        this.Cursor = Cursors.SizeNS;      //'南北
                        break;
                    case EnumMousePointPosition.MouseSizeLeft:
                        this.Cursor = Cursors.SizeWE;      //'东西
                        break;
                    case EnumMousePointPosition.MouseSizeRight:
                        this.Cursor = Cursors.SizeWE;      //'东西
                        break;
                    case EnumMousePointPosition.MouseSizeBottomLeft:
                        this.Cursor = Cursors.SizeNESW;    //'东北到南西
                        break;
                    case EnumMousePointPosition.MouseSizeBottomRight:
                        this.Cursor = Cursors.SizeNWSE;    //'东南到西北
                        break;
                    case EnumMousePointPosition.MouseSizeTopLeft:
                        this.Cursor = Cursors.SizeNWSE;    //'东南到西北
                        break;
                    case EnumMousePointPosition.MouseSizeTopRight:
                        this.Cursor = Cursors.SizeNESW;    //'东北到南西
                        break;
                    default:
                        break;
                }
            }
        }

        #endregion 图片移动

        #region 视频移动

        private enum MediaEnumMousePointPosition
        {
            MouseSizeNone = 0, //'无
            MouseSizeRight = 1, //'拉伸右边框
            MouseSizeLeft = 2, //'拉伸左边框
            MouseSizeBottom = 3, //'拉伸下边框
            MouseSizeTop = 4, //'拉伸上边框
            MouseSizeTopLeft = 5, //'拉伸左上角
            MouseSizeTopRight = 6, //'拉伸右上角
            MouseSizeBottomLeft = 7, //'拉伸左下角
            MouseSizeBottomRight = 8, //'拉伸右下角
            MouseDrag = 9 // '鼠标拖动
        }
        const int mediaBand = 5;
        const int mediaMinWidth = 20;
        const int mediaMinHeight = 20;
        private const int mediadelta = 10;
        private MediaEnumMousePointPosition media_MousePointPosition;
        private Point mediap, mediap1;
        //private static bool Isbegin=false;




        //MyMouseDown事件
        private void MediaMouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            //MessageBox.Show("mousedown");
            mediap.X = e.X;
            mediap.Y = e.Y;

            mediap1.X = e.X;
            mediap1.Y = e.Y;
        }

        //MyMouseLeave事件
        private void MediaMouseLeave(object sender, System.EventArgs e)
        {
            media_MousePointPosition = MediaEnumMousePointPosition.MouseSizeNone;
            this.Cursor = Cursors.Arrow;
        }

        //函数，确定光标在控件不同位置的样式
        private MediaEnumMousePointPosition MediaMousePointPosition(Size size, System.Windows.Forms.MouseEventArgs e)
        {

            if ((e.X >= -1 * mediaBand) | (e.X <= size.Width) | (e.Y >= -1 * mediaBand) | (e.Y <= size.Height))
            {
                if (e.X < mediaBand)
                {
                    if (e.Y < mediaBand) { return MediaEnumMousePointPosition.MouseSizeTopLeft; }
                    else
                    {
                        if (e.Y > -1 * mediaBand + size.Height)
                        { return MediaEnumMousePointPosition.MouseSizeBottomLeft; }
                        else
                        { return MediaEnumMousePointPosition.MouseSizeLeft; }
                    }
                }
                else
                {
                    if (e.X > -1 * mediaBand + size.Width)
                    {
                        if (e.Y < mediaBand)
                        { return MediaEnumMousePointPosition.MouseSizeTopRight; }
                        else
                        {
                            if (e.Y > -1 * mediaBand + size.Height)
                            { return MediaEnumMousePointPosition.MouseSizeBottomRight; }
                            else
                            { return MediaEnumMousePointPosition.MouseSizeRight; }
                        }
                    }
                    else
                    {
                        if (e.Y < mediaBand)
                        { return MediaEnumMousePointPosition.MouseSizeTop; }
                        else
                        {
                            if (e.Y > -1 * mediaBand + size.Height)
                            { return MediaEnumMousePointPosition.MouseSizeBottom; }
                            else
                            { return MediaEnumMousePointPosition.MouseDrag; }
                        }
                    }
                }
            }
            else
            {
                return MediaEnumMousePointPosition.MouseSizeNone;
            }
        }

        //MyMouseMove事件，在这个事件里，会使用上面设计的函数
        private void MediaMouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            Control lCtrl = (sender as Control);
            MediaPlayer mp = (MediaPlayer)sender;
            if (e.Button == MouseButtons.Left)
            {
                switch (media_MousePointPosition)
                {
                    case MediaEnumMousePointPosition.MouseDrag:
                        lCtrl.Left = lCtrl.Left + e.X - mediap.X;
                        lCtrl.Top = lCtrl.Top + e.Y - mediap.Y;
                        break;
                    case MediaEnumMousePointPosition.MouseSizeBottom:
                        lCtrl.Height = lCtrl.Height + e.Y - mediap1.Y;
                        mp.panelMain.Height = mp.panelMain.Height + e.Y - mediap1.Y;
                        mediap1.X = e.X;
                        mediap1.Y = e.Y; //'记录光标拖动的当前点
                        break;
                    case MediaEnumMousePointPosition.MouseSizeBottomRight:
                        lCtrl.Width = lCtrl.Width + e.X - mediap1.X;
                        lCtrl.Height = lCtrl.Height + e.Y - mediap1.Y;
                        mp.panelMain.Width = mp.panelMain.Width + e.X - mediap1.X;
                        mp.panelMain.Height = mp.panelMain.Height + e.Y - mediap1.Y;
                        mediap1.X = e.X;
                        mediap1.Y = e.Y; //'记录光标拖动的当前点
                        break;
                    case MediaEnumMousePointPosition.MouseSizeRight:
                        lCtrl.Width = lCtrl.Width + e.X - mediap1.X;
                        //      lCtrl.Height = lCtrl.Height + e.Y - p1.Y;
                        mp.panelMain.Width = mp.panelMain.Width + e.X - mediap1.X;
                        mediap1.X = e.X;
                        mediap1.Y = e.Y; //'记录光标拖动的当前点
                        break;
                    case MediaEnumMousePointPosition.MouseSizeTop:
                        lCtrl.Top = lCtrl.Top + (e.Y - mediap.Y);
                        lCtrl.Height = lCtrl.Height - (e.Y - mediap.Y);
                        mp.panelMain.Height = mp.panelMain.Height - (e.Y - mediap.Y);
                        break;
                    case MediaEnumMousePointPosition.MouseSizeLeft:
                        lCtrl.Left = lCtrl.Left + e.X - mediap.X;
                        lCtrl.Width = lCtrl.Width - (e.X - mediap.X);
                        mp.panelMain.Width = mp.panelMain.Width - (e.X - mediap.X);
                        break;
                    case MediaEnumMousePointPosition.MouseSizeBottomLeft:
                        lCtrl.Left = lCtrl.Left + e.X - mediap.X;
                        lCtrl.Width = lCtrl.Width - (e.X - mediap.X);
                        lCtrl.Height = lCtrl.Height + e.Y - mediap1.Y;
                        mp.panelMain.Width = mp.panelMain.Width - (e.X - mediap.X);
                        mp.panelMain.Height = mp.panelMain.Height + e.Y - mediap1.Y;

                        mediap1.X = e.X;
                        mediap1.Y = e.Y; //'记录光标拖动的当前点
                        break;
                    case MediaEnumMousePointPosition.MouseSizeTopRight:
                        lCtrl.Top = lCtrl.Top + (e.Y - mediap.Y);
                        lCtrl.Width = lCtrl.Width + (e.X - mediap1.X);
                        lCtrl.Height = lCtrl.Height - (e.Y - mediap.Y);

                        mp.panelMain.Width = mp.panelMain.Width + (e.X - mediap1.X);
                        mp.panelMain.Height = mp.panelMain.Height - (e.Y - mediap.Y);
                        mediap1.X = e.X;
                        mediap1.Y = e.Y; //'记录光标拖动的当前点
                        break;
                    case MediaEnumMousePointPosition.MouseSizeTopLeft:
                        lCtrl.Left = lCtrl.Left + e.X - mediap.X;
                        lCtrl.Top = lCtrl.Top + (e.Y - mediap.Y);
                        lCtrl.Width = lCtrl.Width - (e.X - mediap.X);
                        lCtrl.Height = lCtrl.Height - (e.Y - mediap.Y);

                        mp.panelMain.Width = mp.panelMain.Width - (e.X - mediap.X);
                        mp.panelMain.Height = mp.panelMain.Height - (e.Y - mediap.Y);
                        break;
                    default:
                        break;
                }
                if (lCtrl.Width < mediaMinWidth)
                {
                    lCtrl.Width = mediaMinWidth;
                    mp.panelMain.Width = 0;
                }
                if (lCtrl.Height < mediaMinHeight)
                {
                    lCtrl.Height = mediaMinHeight;
                    mp.panelMain.Height = 0;
                }

            }
            else
            {
                media_MousePointPosition = MediaMousePointPosition(lCtrl.Size, e); //'判断光标的位置状态
                switch (media_MousePointPosition) //'改变光标
                {
                    case MediaEnumMousePointPosition.MouseSizeNone:
                        this.Cursor = Cursors.Arrow;       //'箭头
                        break;
                    case MediaEnumMousePointPosition.MouseDrag:
                        this.Cursor = Cursors.SizeAll;     //'四方向
                        break;
                    case MediaEnumMousePointPosition.MouseSizeBottom:
                        this.Cursor = Cursors.SizeNS;      //'南北
                        break;
                    case MediaEnumMousePointPosition.MouseSizeTop:
                        this.Cursor = Cursors.SizeNS;      //'南北
                        break;
                    case MediaEnumMousePointPosition.MouseSizeLeft:
                        this.Cursor = Cursors.SizeWE;      //'东西
                        break;
                    case MediaEnumMousePointPosition.MouseSizeRight:
                        this.Cursor = Cursors.SizeWE;      //'东西
                        break;
                    case MediaEnumMousePointPosition.MouseSizeBottomLeft:
                        this.Cursor = Cursors.SizeNESW;    //'东北到南西
                        break;
                    case MediaEnumMousePointPosition.MouseSizeBottomRight:
                        this.Cursor = Cursors.SizeNWSE;    //'东南到西北
                        break;
                    case MediaEnumMousePointPosition.MouseSizeTopLeft:
                        this.Cursor = Cursors.SizeNWSE;    //'东南到西北
                        break;
                    case MediaEnumMousePointPosition.MouseSizeTopRight:
                        this.Cursor = Cursors.SizeNESW;    //'东北到南西
                        break;
                    default:
                        break;
                }
            }
        }
        #endregion 视频移动

        #region Flash移动

        private enum FlashEnumMousePointPosition
        {
            MouseSizeNone = 0, //'无
            MouseSizeRight = 1, //'拉伸右边框
            MouseSizeLeft = 2, //'拉伸左边框
            MouseSizeBottom = 3, //'拉伸下边框
            MouseSizeTop = 4, //'拉伸上边框
            MouseSizeTopLeft = 5, //'拉伸左上角
            MouseSizeTopRight = 6, //'拉伸右上角
            MouseSizeBottomLeft = 7, //'拉伸左下角
            MouseSizeBottomRight = 8, //'拉伸右下角
            MouseDrag = 9 // '鼠标拖动
        }

        const int fBand = 5;
        const int fMinWidth = 20;
        const int fMinHeight = 20;
        private const int fdelta = 10;
        private FlashEnumMousePointPosition f_MousePointPosition;
        private Point fp, fp1;

        //MyMouseDown事件
        private void FlashMouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            //MessageBox.Show("mousedown");
            fp.X = e.X;
            fp.Y = e.Y;

            fp1.X = e.X;
            fp1.Y = e.Y;
        }

        //MyMouseLeave事件
        private void FlashMouseLeave(object sender, System.EventArgs e)
        {
            f_MousePointPosition = FlashEnumMousePointPosition.MouseSizeNone;
            this.Cursor = Cursors.Arrow;
        }

        //函数，确定光标在控件不同位置的样式
        private FlashEnumMousePointPosition FlashMousePointPosition(Size size, System.Windows.Forms.MouseEventArgs e)
        {

            if ((e.X >= -1 * fBand) | (e.X <= size.Width) | (e.Y >= -1 * fBand) | (e.Y <= size.Height))
            {
                if (e.X < fBand)
                {
                    if (e.Y < fBand) { return FlashEnumMousePointPosition.MouseSizeTopLeft; }
                    else
                    {
                        if (e.Y > -1 * fBand + size.Height)
                        { return FlashEnumMousePointPosition.MouseSizeBottomLeft; }
                        else
                        { return FlashEnumMousePointPosition.MouseSizeLeft; }
                    }
                }
                else
                {
                    if (e.X > -1 * fBand + size.Width)
                    {
                        if (e.Y < fBand)
                        { return FlashEnumMousePointPosition.MouseSizeTopRight; }
                        else
                        {
                            if (e.Y > -1 * fBand + size.Height)
                            { return FlashEnumMousePointPosition.MouseSizeBottomRight; }
                            else
                            { return FlashEnumMousePointPosition.MouseSizeRight; }
                        }
                    }
                    else
                    {
                        if (e.Y < fBand)
                        { return FlashEnumMousePointPosition.MouseSizeTop; }
                        else
                        {
                            if (e.Y > -1 * fBand + size.Height)
                            { return FlashEnumMousePointPosition.MouseSizeBottom; }
                            else
                            { return FlashEnumMousePointPosition.MouseDrag; }
                        }
                    }
                }
            }
            else
            {
                return FlashEnumMousePointPosition.MouseSizeNone;
            }
        }

        //MyMouseMove事件，在这个事件里，会使用上面设计的函数
        private void FlashMouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            Control lCtrl = (sender as Control);
            FlashPlayer fpflash = (FlashPlayer)sender;
            if (e.Button == MouseButtons.Left)
            {
                switch (f_MousePointPosition)
                {
                    case FlashEnumMousePointPosition.MouseDrag:
                        lCtrl.Left = lCtrl.Left + e.X - fp.X;
                        lCtrl.Top = lCtrl.Top + e.Y - fp.Y;
                        break;
                    case FlashEnumMousePointPosition.MouseSizeBottom:
                        lCtrl.Height = lCtrl.Height + e.Y - fp1.Y;
                        fpflash.panelMain.Height = fpflash.panelMain.Height + e.Y - fp1.Y;
                        fp1.X = e.X;
                        fp1.Y = e.Y; //'记录光标拖动的当前点
                        break;
                    case FlashEnumMousePointPosition.MouseSizeBottomRight:
                        lCtrl.Width = lCtrl.Width + e.X - fp1.X;
                        lCtrl.Height = lCtrl.Height + e.Y - fp1.Y;
                        fpflash.panelMain.Width = fpflash.panelMain.Width + e.X - fp1.X;
                        fpflash.panelMain.Height = fpflash.panelMain.Height + e.Y - fp1.Y;
                        fp1.X = e.X;
                        fp1.Y = e.Y; //'记录光标拖动的当前点
                        break;
                    case FlashEnumMousePointPosition.MouseSizeRight:
                        lCtrl.Width = lCtrl.Width + e.X - fp1.X;
                        //      lCtrl.Height = lCtrl.Height + e.Y - p1.Y;
                        fpflash.panelMain.Width = fpflash.panelMain.Width + e.X - fp1.X;
                        fp1.X = e.X;
                        fp1.Y = e.Y; //'记录光标拖动的当前点
                        break;
                    case FlashEnumMousePointPosition.MouseSizeTop:
                        lCtrl.Top = lCtrl.Top + (e.Y - fp.Y);
                        lCtrl.Height = lCtrl.Height - (e.Y - fp.Y);
                        fpflash.panelMain.Height = fpflash.panelMain.Height - (e.Y - fp.Y);
                        break;
                    case FlashEnumMousePointPosition.MouseSizeLeft:
                        lCtrl.Left = lCtrl.Left + e.X - fp.X;
                        lCtrl.Width = lCtrl.Width - (e.X - fp.X);
                        fpflash.panelMain.Width = fpflash.panelMain.Width - (e.X - fp.X);
                        break;
                    case FlashEnumMousePointPosition.MouseSizeBottomLeft:
                        lCtrl.Left = lCtrl.Left + e.X - fp.X;
                        lCtrl.Width = lCtrl.Width - (e.X - fp.X);
                        lCtrl.Height = lCtrl.Height + e.Y - fp1.Y;
                        fpflash.panelMain.Width = fpflash.panelMain.Width - (e.X - fp.X);
                        fpflash.panelMain.Height = fpflash.panelMain.Height + e.Y - fp1.Y;

                        fp1.X = e.X;
                        fp1.Y = e.Y; //'记录光标拖动的当前点
                        break;
                    case FlashEnumMousePointPosition.MouseSizeTopRight:
                        lCtrl.Top = lCtrl.Top + (e.Y - fp.Y);
                        lCtrl.Width = lCtrl.Width + (e.X - fp1.X);
                        lCtrl.Height = lCtrl.Height - (e.Y - fp.Y);

                        fpflash.panelMain.Width = fpflash.panelMain.Width + (e.X - fp1.X);
                        fpflash.panelMain.Height = fpflash.panelMain.Height - (e.Y - fp.Y);
                        fp1.X = e.X;
                        fp1.Y = e.Y; //'记录光标拖动的当前点
                        break;
                    case FlashEnumMousePointPosition.MouseSizeTopLeft:
                        lCtrl.Left = lCtrl.Left + e.X - fp.X;
                        lCtrl.Top = lCtrl.Top + (e.Y - fp.Y);
                        lCtrl.Width = lCtrl.Width - (e.X - fp.X);
                        lCtrl.Height = lCtrl.Height - (e.Y - fp.Y);

                        fpflash.panelMain.Width = fpflash.panelMain.Width - (e.X - fp.X);
                        fpflash.panelMain.Height = fpflash.panelMain.Height - (e.Y - fp.Y);
                        break;
                    default:
                        break;
                }
                if (lCtrl.Width < fMinWidth)
                {
                    lCtrl.Width = fMinWidth;
                    fpflash.panelMain.Width = 0;
                }
                if (lCtrl.Height < fMinHeight)
                {
                    lCtrl.Height = fMinHeight;
                    fpflash.panelMain.Height = 0;
                }

            }
            else
            {
                f_MousePointPosition = FlashMousePointPosition(lCtrl.Size, e); //'判断光标的位置状态
                switch (f_MousePointPosition) //'改变光标
                {
                    case FlashEnumMousePointPosition.MouseSizeNone:
                        this.Cursor = Cursors.Arrow;       //'箭头
                        break;
                    case FlashEnumMousePointPosition.MouseDrag:
                        this.Cursor = Cursors.SizeAll;     //'四方向
                        break;
                    case FlashEnumMousePointPosition.MouseSizeBottom:
                        this.Cursor = Cursors.SizeNS;      //'南北
                        break;
                    case FlashEnumMousePointPosition.MouseSizeTop:
                        this.Cursor = Cursors.SizeNS;      //'南北
                        break;
                    case FlashEnumMousePointPosition.MouseSizeLeft:
                        this.Cursor = Cursors.SizeWE;      //'东西
                        break;
                    case FlashEnumMousePointPosition.MouseSizeRight:
                        this.Cursor = Cursors.SizeWE;      //'东西
                        break;
                    case FlashEnumMousePointPosition.MouseSizeBottomLeft:
                        this.Cursor = Cursors.SizeNESW;    //'东北到南西
                        break;
                    case FlashEnumMousePointPosition.MouseSizeBottomRight:
                        this.Cursor = Cursors.SizeNWSE;    //'东南到西北
                        break;
                    case FlashEnumMousePointPosition.MouseSizeTopLeft:
                        this.Cursor = Cursors.SizeNWSE;    //'东南到西北
                        break;
                    case FlashEnumMousePointPosition.MouseSizeTopRight:
                        this.Cursor = Cursors.SizeNESW;    //'东北到南西
                        break;
                    default:
                        break;
                }
            }
        }

        #endregion Flash移动

        #endregion 移动效果
 
    }
}