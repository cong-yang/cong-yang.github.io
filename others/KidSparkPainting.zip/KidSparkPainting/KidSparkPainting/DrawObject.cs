﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.Serialization;

namespace KidSparkPainting
{
    /// <summary>
    /// Base class for all draw objects
    /// 所有绘制对象的基类
    /// </summary>
    abstract class DrawObject   //抽象类
    {
        #region Members

        // 对象属性
        private bool selected;  //是否被选择
        private Color color;    //颜色
        private int penWidth;   //笔触宽度

        // Allows to write Undo - Redo functions and don't care about
        // objects order in the list.
        //允许写撤销——重做方法却并不关注对象在列表中的顺序
        int id;

        // Last used property values (may be kept in the Registry)
        //最后使用的对象属性（可能是存储在注册表中）
        private static Color lastUsedColor = Color.Black;
        private static int lastUsedPenWidth = 1;

        // Entry names for serialization
        //入口名称序列化
        private const string entryColor = "Color";
        private const string entryPenWidth = "PenWidth";

        #endregion

        /// <summary>
        /// 此处用到了哈希函数
        /// 哈希函数用于快速生成一个与对象的值相对应的数字（哈希代码）。
        /// 哈希函数通常是特定于每个 Type 的，而且，必须至少使用一个实例字段作为输入。 
        /// 哈希函数必须具有以下特点：
        /// 如果两个类型相同的对象表示相同的值，则哈希函数必须为两个对象返回相同的常数值。
        /// 为了获得最佳性能，哈希函数必须为所有输入生成随机分布。
        /// 不论对该对象进行什么样的更改，哈希函数都必须返回完全相同的值。
        /// 例如，String 类提供的 GetHashCode 实现为唯一的字符串值返回唯一的哈希代码。
        /// 因此，如果两个 String 对象表示相同的字符串值，则它们返回相同的哈希代码。另外，
        /// 该方法使用字符串中的所有字符生成相当随机的分布式输出，即使当输入集中在某些范围内
        /// 时（例如，许多用户可能有只包含低位 128 个 ASCII 字符的字符串，即使字符串可以包含 65,535 个
        /// Unicode 字符中的任何字符）。 GetHashCode 对于对象的给定实例必须总是返回相同的值。
        /// 对于 Object 的派生类，当且仅当此派生类将值相等定义为引用相等并且类型不是值类型时，
        /// GetHashCode 才可以委托给 Object.GetHashCode 实现。 在类上提供好的哈希函数可以显著影响
        /// 将这些对象添加到哈希表的性能。在具有好的哈希函数实现的哈希表中，搜索元素所用的时间是固
        /// 定的（例如 O(1) 操作）。而在具有不好的哈希函数实现的哈希表中，搜索性能取决于哈希表中的
        /// 项数（例如 O(n) 操作，其中的 n 是哈希表中的项数）。哈希函数的计算成本也必须不高。
        /// GetHashCode 的实现必须不会导致循环引用。例如，如果 ClassA.GetHashCode 调用 
        /// ClassB.GetHashCode，ClassB.GetHashCode 必须不直接或间接调用 ClassA.GetHashCode。
        /// GetHashCode 的实现必须不引发异常。 重写 GetHashCode 的派生类还必须重写 Equals，
        /// 以保证被视为相等的两个对象具有相同的哈希代码；否则，Hashtable 可能不会正常工作。
        /// </summary>
        public DrawObject()
        {
            id = this.GetHashCode();
        }

        #region Properties

        /// <summary>
        /// Selection flag
        /// 对象是否被选择标志
        /// </summary>
        public bool Selected
        {
            get
            {
                return selected;
            }
            set
            {
                selected = value;
            }
        }

        /// <summary>
        /// Color
        /// 颜色
        /// </summary>
        public Color Color
        {
            get
            {
                return color;
            }
            set
            {
                color = value;
            }
        }

        /// <summary>
        /// Pen width
        /// 笔触宽度
        /// </summary>
        public int PenWidth
        {
            get
            {
                return penWidth;
            }
            set
            {
                penWidth = value;
            }
        }

        /// <summary>
        /// Number of handles
        /// 句柄数量
        /// </summary>
        public virtual int HandleCount
        {
            get
            {
                return 0;
            }
        }

        /// <summary>
        /// Object ID
        /// 对象ID
        /// </summary>
        public int ID
        {
            get { return id; }
            set { id = value; }
        }


        /// <summary>
        /// Last used color
        /// 最后一次使用的颜色
        /// 调用的时候是从注册表里面加载的
        /// </summary>
        public static Color LastUsedColor
        {
            get
            {
                return lastUsedColor;
            }
            set
            {
                lastUsedColor = value;
            }
        }

        /// <summary>
        /// Last used pen width
        /// 最后一次使用笔触的宽度
        /// 调用的时候是从注册表里面加载的
        /// </summary>
        public static int LastUsedPenWidth
        {
            get
            {
                return lastUsedPenWidth;
            }
            set
            {
                lastUsedPenWidth = value;
            }
        }

        #endregion

        #region Virtual Functions

        /// <summary>
        /// Clone this instance.
        /// 复制实例
        /// </summary>
        public abstract DrawObject Clone();

        /// <summary>
        /// 绘制对象
        /// </summary>
        /// <param name="g"></param>
        public virtual void Draw(Graphics g)
        {
        }

        /// <summary>
        /// Get handle point by 1-based number
        /// 依据1-based数目得到处理点
        /// </summary>
        /// <param name="handleNumber"></param>
        /// <returns></returns>
        public virtual Point GetHandle(int handleNumber)
        {
            return new Point(0, 0);
        }

        /// <summary>
        /// Get handle rectangle by 1-based number
        /// 依据1-based数目得到处理矩形，也就是在对象上面绘制小矩形
        /// </summary>
        /// <param name="handleNumber"></param>
        /// <returns></returns>
        public virtual Rectangle GetHandleRectangle(int handleNumber)
        {
            Point point = GetHandle(handleNumber);

            return new Rectangle(point.X - 3, point.Y - 3, 7, 7);
        }

        /// <summary>
        /// Draw tracker for selected object
        /// 为选中的对象画追踪器，也就是选中某个画图对象的时候在对象上面出现的小矩形
        /// </summary>
        /// <param name="g"></param>
        public virtual void DrawTracker(Graphics g)
        {
            if (!Selected)
                return;

            SolidBrush brush = new SolidBrush(Color.Black);

            for (int i = 1; i <= HandleCount; i++)
            {
                g.FillRectangle(brush, GetHandleRectangle(i));
            }

            brush.Dispose();
        }

        /// <summary>
        /// Hit test.
        /// 点击测试
        /// Return value: -1 - no hit
        ///                0 - hit anywhere
        ///                > 1 - handle number
        /// </summary>
        /// <param name="point"></param>
        /// <returns></returns>
        public virtual int HitTest(Point point)
        {
            return -1;
        }


        /// <summary>
        /// Test whether point is inside of the object
        /// 测试鼠标所点击的点是否在对象内
        /// </summary>
        /// <param name="point"></param>
        /// <returns></returns>
        protected virtual bool PointInObject(Point point)
        {
            return false;
        }


        /// <summary>
        /// Get cursor for the handle
        /// 为方法设置光标外观
        /// </summary>
        /// <param name="handleNumber"></param>
        /// <returns></returns>
        public virtual Cursor GetHandleCursor(int handleNumber)
        {
            return Cursors.Default;
        }

        /// <summary>
        /// Test whether object intersects with rectangle
        /// 测试对象是否与矩形相交
        /// </summary>
        /// <param name="rectangle"></param>
        /// <returns></returns>
        public virtual bool IntersectsWith(Rectangle rectangle)
        {
            return false;
        }

        /// <summary>
        /// Move object
        /// 移动对象
        /// </summary>
        /// <param name="deltaX"></param>
        /// <param name="deltaY"></param>
        public virtual void Move(int deltaX, int deltaY)
        {
        }

        /// <summary>
        /// Move handle to the point
        /// </summary>
        /// <param name="point"></param>
        /// <param name="handleNumber"></param>
        public virtual void MoveHandleTo(Point point, int handleNumber)
        {
        }

        /// <summary>
        /// Dump (for debugging)
        /// </summary>
        public virtual void Dump()
        {
            Trace.WriteLine(this.GetType().Name);
            Trace.WriteLine("Selected = " +
                selected.ToString(CultureInfo.InvariantCulture)
                + " ID = " + id.ToString(CultureInfo.InvariantCulture));
        }

        /// <summary>
        /// Normalize object.
        /// 规范对象
        /// Call this function in the end of object resizing.
        /// 在对象被重新设置大小的时候调用此函数
        /// </summary>
        public virtual void Normalize()
        {
        }


        /// <summary>
        /// Save object to serialization stream
        /// 将对象保存为序列化流
        /// </summary>
        /// <param name="info"></param>
        /// <param name="orderNumber"></param>
        public virtual void SaveToStream(SerializationInfo info, int orderNumber)
        {
            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                    "{0}{1}",
                    entryColor, orderNumber),
                Color.ToArgb());

            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                "{0}{1}",
                entryPenWidth, orderNumber),
                PenWidth);
        }

        /// <summary>
        /// Load object from serialization stream
        /// </summary>
        /// <param name="info"></param>
        /// <param name="orderNumber"></param>
        public virtual void LoadFromStream(SerializationInfo info, int orderNumber)
        {
            int n = info.GetInt32(
                String.Format(CultureInfo.InvariantCulture,
                    "{0}{1}",
                    entryColor, orderNumber));

            Color = Color.FromArgb(n);

            PenWidth = info.GetInt32(
                String.Format(CultureInfo.InvariantCulture,
                "{0}{1}",
                entryPenWidth, orderNumber));

            id = this.GetHashCode();
        }

        #endregion

        #region Other functions

        /// <summary>
        /// Initialization
        /// </summary>
        protected void Initialize()
        {
            color = lastUsedColor;
            penWidth = LastUsedPenWidth;
        }

        /// <summary>
        /// Copy fields from this instance to cloned instance drawObject.
        /// Called from Clone functions of derived classes.
        /// </summary>
        protected void FillDrawObjectFields(DrawObject drawObject)
        {
            drawObject.selected = this.selected;
            drawObject.color = this.color;
            drawObject.penWidth = this.penWidth;
            drawObject.ID = this.ID;
        }

        #endregion
    }
}
