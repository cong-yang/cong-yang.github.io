﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Microsoft.Office.Core;
using Microsoft.Office.Interop.PowerPoint;
using System.Threading;
using System.Collections;
using O2S.Components.PDFRender4NET;

namespace KidSparkPainting
{
    public partial class OpenDocWinForm : Form
    {
        public OpenDocWinForm()
        {
            InitializeComponent();
        }

        private string Docsrc;      //被转换的文档位置+名称
        private string Docname;     //被转换的文档名称
        private string targetjpg;   //转换目标文件夹
        private string Doctype;     //被转换文档类型，有.ppt/.pot/.pptx/.doc/.docx/.pdf
        ApplicationClass application; //启动对象

        #region 获取屏幕宽度高度
        private int ScreenWidth = Screen.PrimaryScreen.Bounds.Width;    //当前屏幕的宽度
        private int ScreenHeight = Screen.PrimaryScreen.Bounds.Height;  //当前屏幕的高度
        #endregion 获取屏幕宽度高度

        private int pagenumber = 0; //用来记录页数与总页码
        private int pagenow = 1;    //用来记录当前显示的页码
        private int pageall = 0;    //用来记录页码总数

        private void OpenDocWinForm_Load(object sender, EventArgs e)
        {
            //docDraw1.PenSize = 10;
            //docDraw1.Pen_Color = Color.Black;

            //docDraw1.m_enDrawMode = DocDraw.WHITEBOARD_DRAW_MODE.enModePencil;
        }

        //公共接口,用来获取从前端传送过来的文档信息
        public void GetDoc(string Filepath,string Filename, string Filesuffix)
        {
            this.Docsrc = Filepath;      //被转换的ppt位置+名称
            this.Doctype = Filesuffix;   //被转换ppt类型，有.ppt/.pot/.pptx
            this.Docname = Filename;     //被转换文件的名称
            this.targetjpg = System.Windows.Forms.Application.StartupPath + @"\Temporary";

            switch (Filesuffix)
            { 
                case ".ppt":
                    StartConvertPPT(); //开启PPT转换
                    break;
                case ".pot":
                    StartConvertPPT(); //开启PPT转换
                    break;
                case ".pptx":
                    StartConvertPPT(); //开启PPT转换
                    break;
                case ".doc":
                    MessageBox.Show("Start Word 2003");
                    break;
                case ".docx":
                    MessageBox.Show("Start Word 2007");
                    break;
                case ".pdf":
                    //MessageBox.Show("启动pdf转换");
                    StartConvertPDF();
                    break;
            }            
        }

        #region 图片导入引擎
        private void ImportPic(String JpgFolderpath)
        {
            try
            {
                //获取文件夹下的所有文件
                DirectoryInfo fdir = new DirectoryInfo(JpgFolderpath);
                FileInfo[] file = fdir.GetFiles();

                //开始遍历
                foreach (FileInfo f in file)
                {
                    pagenumber++;
                    docdraw = new DocDraw();    //定义新的画板
                    Image piccy = Image.FromFile(f.FullName.ToString());    //用来读取要插入的图片
                    docdraw.Size = new Size(piccy.Width, piccy.Height);     //用来确定画板的大小
                    docdraw.Name = "Page" + pagenumber.ToString();    //为每一个画板命名
                    docdraw.Tag = pagenumber;   //将当前页码加入到自定义数据
                    docdraw.Cursor = new Cursor(System.Windows.Forms.Application.StartupPath + @"\Pencil.cur");
                    docdraw.Location = new Point((int)((ScreenWidth - piccy.Width) / 2),
                        (int)((ScreenHeight - OpenDocTools.Height - piccy.Height) / 4)); //定义打开文档的位置，处于屏幕中央
                    docdraw.InsertPic(piccy);   //将图片插入到画板中
                    docdraw.Visible = false;    //先使所有的页面都不可见
                    if (pagenumber == 1)    //如果是第一张，则显示在屏幕上
                    {
                        docdraw.Visible = true;
                    }
                    PanelMain.Controls.Add(docdraw);    //将画板插入到面板中
                    ButtonGotoPage.Items.Add(docdraw.Name);
                    Thread.Sleep(50);
                }
                pageall = pagenumber;   //将总页数传递给pageall变量
                LableShowPage.Text = "Page " + pagenow.ToString() + " / " + pageall.ToString() + "   ";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Import Error:" + ex.Message.ToString());
            }
        }
        #endregion 图片导入引擎

        #region 临时文件删除

        //删除临时文件夹(转换后的图片文件夹)
        private void DeleteFolder(string dir)
        {
            foreach (string d in Directory.GetFileSystemEntries(dir))
            {
                if (File.Exists(d))
                {
                    FileInfo fi = new FileInfo(d);
                    if (fi.Attributes.ToString().IndexOf("ReadOnly") != -1)
                        fi.Attributes = FileAttributes.Normal;
                    File.Delete(d); //直接删除其中的文件   
                }
                else
                    DeleteFolder(d);    //递归删除子文件夹
            }
            Directory.Delete(dir);  //删除已空文件夹   
        }

        #endregion 临时文件删除

        #region PPT转换引擎

        //启动PPT转换
        private void StartConvertPPT()
        {
            try
            {
                application = new ApplicationClass();
                ThreadPool.QueueUserWorkItem(new WaitCallback(ConvertPPT));    //启动PPT转换
                MessageBox.Show("Open Completely!");
                ImportPic(targetjpg + @"\" + Docname.Substring(0, Docname.Length - 4));
            }
            catch (Exception ex)
            {
                MessageBox.Show("Start PPT Conversion Error:" + ex.Message.ToString());
            }
        }

        //用来进行ppt向jpg的转换
        private void ConvertPPT(Object stateInfo)
        {
            switch (Doctype)
            {
                case ".ppt":
                    ppttojpg();     //启动ppt转换引擎
                    break;
                case ".pot":
                    pottojpg();     //启动pot转换引擎
                    break;
                case ".pptx":
                    pptxtojpg();    //启动pptx转换引擎
                    break;
            }
        }

        #region typeconvert

        //转换ppt
        private void ppttojpg()
        {
            try
            {
                string fullDir = Path.Combine(targetjpg, Docname);     //将选定目录和ppt的名字组合，为了创建文件夹方便
                fullDir = fullDir.Substring(0, fullDir.Length - 4);
                Directory.CreateDirectory(fullDir);                     //创建转换后图片所在文件夹
                Presentation p = application.Presentations.Open(Docsrc, MsoTriState.msoCTrue, MsoTriState.msoCTrue, MsoTriState.msoFalse);  //读取ppt
                p.SaveAs(fullDir, PpSaveAsFileType.ppSaveAsJPG, MsoTriState.msoCTrue);  //进行转换
                p.Close();  //关闭读取
            }
            catch (Exception ex)
            {
                MessageBox.Show("PPT 2003 Conversion Error:" + ex.Message.ToString());
            }
        }

        //转换pot
        private void pottojpg()
        {
            try
            {
                string fullDir = Path.Combine(targetjpg, Docname);
                fullDir = fullDir.Substring(0, fullDir.Length - 4);
                Directory.CreateDirectory(fullDir);
                Presentation p = application.Presentations.Open(Docsrc, MsoTriState.msoCTrue, MsoTriState.msoCTrue, MsoTriState.msoFalse);
                p.SaveAs(fullDir, PpSaveAsFileType.ppSaveAsJPG, MsoTriState.msoCTrue);
                p.Close();
                //MessageBox.Show("ok");
            }
            catch (Exception ex)
            {
                MessageBox.Show("POT 2003 Conversion Error:" + ex.Message.ToString());
            }
        }

        //转换pptx
        private void pptxtojpg()
        {
            try
            {
                string fullDir = Path.Combine(targetjpg, Docname);
                fullDir = fullDir.Substring(0, fullDir.Length - 4);
                Directory.CreateDirectory(fullDir);
                Presentation p = application.Presentations.Open2007(Docsrc, MsoTriState.msoCTrue, MsoTriState.msoCTrue, MsoTriState.msoFalse, MsoTriState.msoFalse);
                p.SaveAs(fullDir, PpSaveAsFileType.ppSaveAsJPG, MsoTriState.msoCTrue);
                p.Close();
                //MessageBox.Show("ok");
            }
            catch (Exception ex)
            {
                MessageBox.Show("PPT 2007 Conversion Error.Probably your computer did not installed Microsoft Office 2007:" + ex.Message.ToString());
            }
        }

        #endregion typeconvert

        #endregion PPT转换引擎

        #region PDF转换引擎

        //启动PDF转换
        private void StartConvertPDF()
        {
            try
            {
                ConvertPDF(Docsrc, targetjpg);
                ImportPic(targetjpg + @"\" + Docname);
            }
            catch (Exception ex)
            {
                MessageBox.Show("PDF Conversion Error:" + ex.Message.ToString());
            }
        }

        private void ConvertPDF(string sourcePath, string targetPath)
        {
            PDFFile pdfdoc = PDFFile.Open(sourcePath);
            try
            {
                string fullDir = Path.Combine(targetjpg, Docname);
                Directory.CreateDirectory(fullDir);
                int PageCount = pdfdoc.PageCount;
                //Console.WriteLine(PageCount);
                for (int i = 0; i < PageCount; i++)
                {

                    using (Bitmap img = pdfdoc.GetPageImage(i, 99))
                    {
                        Console.WriteLine(targetjpg);
                        string jpgname = targetjpg + "//" + Docname + "//" + i + ".jpg";
                        img.Save(jpgname);
                    }
                }

                MessageBox.Show("Open Completely!");
            }
            catch (System.Runtime.InteropServices.ExternalException)
            {
                return;
            }
            finally
            {
                pdfdoc.Dispose();
            }
        }

        #endregion PDF转换引擎

        #region 文档工具

        //保存
        private void ButtonSave_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog SaveFileDlg = new SaveFileDialog();
                SaveFileDlg.Filter = "Image Files(*.BMP;*.JPG;*.GIF)|*.BMP;*.JPG;*.GIF|All files (*.*)|*.*";
                SaveFileDlg.FilterIndex = 1;
                SaveFileDlg.RestoreDirectory = true;
                string StrFileName = "";
                if (SaveFileDlg.ShowDialog() == DialogResult.OK)
                {
                    string savepage = "Page" + pagenow.ToString();    //当前要保存的画板名称
                    foreach (Control savepic in PanelMain.Controls)
                    {
                        if (savepic.Name == savepage)
                        {
                            DocDraw docsave = (DocDraw)savepic;     //实例化被保存的画板
                            StrFileName = SaveFileDlg.FileName;
                            docsave.BitmapCanvas.Save(StrFileName); //保存画板
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Save Error:" + ex.Message.ToString());
            }
        }

        //保存全部
        private void ButtonSaveAll_Click(object sender, EventArgs e)
        {
            try
            {
                FolderBrowserDialog SaveAllFileFolder = new FolderBrowserDialog();
                SaveAllFileFolder.Description = "Select Your Target Folder";
                SaveAllFileFolder.ShowNewFolderButton = true;
                String StrFileName = "";
                if (SaveAllFileFolder.ShowDialog() == DialogResult.OK)
                {
                    String SaveFileTargetFolder = SaveAllFileFolder.SelectedPath;
                    foreach (Control savepic in PanelMain.Controls)
                    {
                        DocDraw docsave = (DocDraw)savepic;     //实例化被保存的画板
                        StrFileName = SaveFileTargetFolder + @"\" + docsave.Name + ".BMP";
                        //MessageBox.Show(StrFileName);
                        docsave.BitmapCanvas.Save(StrFileName); //保存画板
                        Thread.Sleep(500);
                    }
                    MessageBox.Show("Save All Successfully!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("保存全部文档时出错，错误信息：" + ex.Message.ToString());
            }
        }

        //鼠标工具
        private void ButtonPoint_Click(object sender, EventArgs e)
        {
            string NowDoc = "Page" + pagenow.ToString();    //当前要保存的画板名称
            foreach (Control Nowpic in PanelMain.Controls)
            {
                if (Nowpic.Name == NowDoc)
                {
                    DocDraw docdraw = (DocDraw)Nowpic;     //实例化被保存的画板
                    docdraw.m_enDrawMode = DocDraw.WHITEBOARD_DRAW_MODE.enModePoint;
                    docdraw.Cursor = new Cursor(System.Windows.Forms.Application.StartupPath + @"\Point.cur");
                }
            }
        }

        //启动铅笔工具
        private void ButtonPencil_Click(object sender, EventArgs e)
        {
            string NowDoc = "Page" + pagenow.ToString();    //当前要保存的画板名称
            foreach (Control Nowpic in PanelMain.Controls)
            {
                if (Nowpic.Name == NowDoc)
                {
                    DocDraw docdraw = (DocDraw)Nowpic;     //实例化被保存的画板
                    docdraw.m_enDrawMode = DocDraw.WHITEBOARD_DRAW_MODE.enModePencil;
                    docdraw.Cursor = new Cursor(System.Windows.Forms.Application.StartupPath + @"\Pencil.cur");
                }
            }
        }

        //启动毡尖笔工具
        private void ButtonNiteWriterPen_Click(object sender, EventArgs e)
        {
            string NowDoc = "Page" + pagenow.ToString();    //当前要保存的画板名称
            foreach (Control Nowpic in PanelMain.Controls)
            {
                if (Nowpic.Name == NowDoc)
                {
                    DocDraw docdraw = (DocDraw)Nowpic;     //实例化被保存的画板
                    docdraw.m_enDrawMode = DocDraw.WHITEBOARD_DRAW_MODE.enModeChineseBrush;
                    docdraw.Cursor = new Cursor(System.Windows.Forms.Application.StartupPath + @"\baohemaobi.cur");
                }
            }
        }

        //粗画笔
        private void PenThick_Click(object sender, EventArgs e)
        {
            string NowDoc = "Page" + pagenow.ToString();    //当前要保存的画板名称
            foreach (Control Nowpic in PanelMain.Controls)
            {
                if (Nowpic.Name == NowDoc)
                {
                    DocDraw docdraw = (DocDraw)Nowpic;     //实例化被保存的画板
                    docdraw.ChangePenWidth(DocDraw.PenWidthMode.ThickPen);
                }
            }
        }

        //中等宽度画笔
        private void PenMiddle_Click(object sender, EventArgs e)
        {
            string NowDoc = "Page" + pagenow.ToString();    //当前要保存的画板名称
            foreach (Control Nowpic in PanelMain.Controls)
            {
                if (Nowpic.Name == NowDoc)
                {
                    DocDraw docdraw = (DocDraw)Nowpic;     //实例化被保存的画板
                    docdraw.ChangePenWidth(DocDraw.PenWidthMode.MiddlePen);
                }
            }
        }

        //细画笔
        private void PenThin_Click(object sender, EventArgs e)
        {
            string NowDoc = "Page" + pagenow.ToString();    //当前要保存的画板名称
            foreach (Control Nowpic in PanelMain.Controls)
            {
                if (Nowpic.Name == NowDoc)
                {
                    DocDraw docdraw = (DocDraw)Nowpic;     //实例化被保存的画板
                    docdraw.ChangePenWidth(DocDraw.PenWidthMode.ThinPen);
                }
            }
        }

        //笔触颜色
        private void ButtonPenColor_Click(object sender, EventArgs e)
        {
            string NowDoc = "Page" + pagenow.ToString();    //当前要保存的画板名称
            foreach (Control Nowpic in PanelMain.Controls)
            {
                if (Nowpic.Name == NowDoc)
                {
                    DocDraw docdraw = (DocDraw)Nowpic;     //实例化被保存的画板
                    ColorDialog DialogPenColor = new ColorDialog();
                    DialogPenColor.Color = docdraw.Pen_Color;
                    if (DialogPenColor.ShowDialog(this) == DialogResult.OK)
                    {
                        docdraw.ChangePenColor(DialogPenColor.Color);
                    }
                }
            }
        }

        //上一页
        private void ButtonPrePage_Click(object sender, EventArgs e)
        {
            try
            {
                if (pagenow > 1)
                {
                    int PrePageNumber = pagenow - 1;
                    string str = "Page" + PrePageNumber.ToString();    //为每一个画板命名
                    //递归遍历
                    foreach (Control c in PanelMain.Controls)
                    {
                        if (c.Name == str)
                        {
                            HideAllPic();   //隐藏所有
                            c.Visible = true;   //只显示当前选择的页
                            pagenow = (int)c.Tag;   //将图片的Tag值传递给当前页码变量
                            ButtonGotoPage.Text = str;  //页数选择框与页码同步
                            LableShowPage.Text = "Page " + pagenow.ToString() + " / " + pageall.ToString() + "   ";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Goto Page Error:" + ex.Message.ToString());
            }
        }

        //下一页
        private void ButtonNextPage_Click(object sender, EventArgs e)
        {
            try
            {
                if (pagenow < pageall)
                {
                    int PrePageNumber = pagenow + 1;
                    string str = "Page" + PrePageNumber.ToString();    //为每一个画板命名
                    //递归遍历
                    foreach (Control c in PanelMain.Controls)
                    {
                        if (c.Name == str)
                        {
                            HideAllPic();   //隐藏所有
                            c.Visible = true;   //只显示当前选择的页
                            pagenow = (int)c.Tag;   //将图片的Tag值传递给当前页码变量
                            ButtonGotoPage.Text = str;  //页数选择框与页码同步
                            LableShowPage.Text = "Page " + pagenow.ToString() + " / " + pageall.ToString() + "   ";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Goto Page Error:" + ex.Message.ToString());
            }
        }

        //定位至幻灯片
        private void GotoPage_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string str = ButtonGotoPage.Text.ToString().Trim();
                //递归遍历
                foreach (Control c in PanelMain.Controls)
                {
                    if (c.Name == str)
                    {
                        HideAllPic();   //隐藏所有
                        c.Visible = true;   //只显示当前选择的页
                        pagenow = (int)c.Tag;   //将图片的Tag值传递给当前页码变量
                        LableShowPage.Text = "Page " + pagenow.ToString() + " / " + pageall.ToString() + "   ";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Goto Page Error:" + ex.Message.ToString());
            }
        }

        #endregion 文档工具

        #region 具体方法函数

        //隐藏所有转换后图片
        private void HideAllPic()
        {
            foreach (Control pic in PanelMain.Controls)
            {
                pic.Visible = false;
            }
        }

        #endregion 具体方法函数

    }
}
