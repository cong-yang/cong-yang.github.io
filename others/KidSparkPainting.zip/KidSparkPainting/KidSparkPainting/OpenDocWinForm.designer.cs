﻿namespace KidSparkPainting
{
    partial class OpenDocWinForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OpenDocWinForm));
            this.OpenDocTools = new System.Windows.Forms.ToolStrip();
            this.ButtonGotoPage = new System.Windows.Forms.ToolStripComboBox();
            this.LableShowPage = new System.Windows.Forms.ToolStripLabel();
            this.PanelMain = new System.Windows.Forms.Panel();
            this.ButtonSave = new System.Windows.Forms.ToolStripButton();
            this.ButtonSaveAll = new System.Windows.Forms.ToolStripButton();
            this.ButtonPenColor = new System.Windows.Forms.ToolStripButton();
            this.ButtonPenWidth = new System.Windows.Forms.ToolStripDropDownButton();
            this.PenThick = new System.Windows.Forms.ToolStripMenuItem();
            this.PenMiddle = new System.Windows.Forms.ToolStripMenuItem();
            this.PenThin = new System.Windows.Forms.ToolStripMenuItem();
            this.ButtonNextPage = new System.Windows.Forms.ToolStripButton();
            this.ButtonPrePage = new System.Windows.Forms.ToolStripButton();
            this.ButtonPencil = new System.Windows.Forms.ToolStripButton();
            this.ButtonChineseBrush = new System.Windows.Forms.ToolStripButton();
            this.ButtonPoint = new System.Windows.Forms.ToolStripButton();
            this.OpenDocTools.SuspendLayout();
            this.SuspendLayout();
            // 
            // OpenDocTools
            // 
            this.OpenDocTools.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(201)))), ((int)(((byte)(215)))), ((int)(((byte)(235)))));
            this.OpenDocTools.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.OpenDocTools.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.OpenDocTools.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ButtonSave,
            this.ButtonSaveAll,
            this.ButtonPenColor,
            this.ButtonPenWidth,
            this.ButtonNextPage,
            this.ButtonGotoPage,
            this.ButtonPrePage,
            this.ButtonPencil,
            this.ButtonChineseBrush,
            this.LableShowPage,
            this.ButtonPoint});
            this.OpenDocTools.Location = new System.Drawing.Point(0, 608);
            this.OpenDocTools.Name = "OpenDocTools";
            this.OpenDocTools.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.OpenDocTools.Size = new System.Drawing.Size(1073, 38);
            this.OpenDocTools.TabIndex = 0;
            // 
            // ButtonGotoPage
            // 
            this.ButtonGotoPage.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.ButtonGotoPage.AutoSize = false;
            this.ButtonGotoPage.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold);
            this.ButtonGotoPage.Name = "ButtonGotoPage";
            this.ButtonGotoPage.Size = new System.Drawing.Size(100, 27);
            this.ButtonGotoPage.Text = "GoTo Page";
            this.ButtonGotoPage.SelectedIndexChanged += new System.EventHandler(this.GotoPage_SelectedIndexChanged);
            // 
            // LableShowPage
            // 
            this.LableShowPage.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.LableShowPage.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold);
            this.LableShowPage.Name = "LableShowPage";
            this.LableShowPage.Size = new System.Drawing.Size(100, 35);
            this.LableShowPage.Text = "Page 0 / 0   ";
            // 
            // PanelMain
            // 
            this.PanelMain.AutoScroll = true;
            this.PanelMain.AutoScrollMinSize = new System.Drawing.Size(255, 255);
            this.PanelMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(153)))), ((int)(((byte)(174)))));
            this.PanelMain.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PanelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelMain.Location = new System.Drawing.Point(0, 0);
            this.PanelMain.Name = "PanelMain";
            this.PanelMain.Size = new System.Drawing.Size(1073, 608);
            this.PanelMain.TabIndex = 1;
            // 
            // ButtonSave
            // 
            this.ButtonSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(201)))), ((int)(((byte)(215)))), ((int)(((byte)(235)))));
            this.ButtonSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonSave.Image = global::KidSparkPainting.Properties.Resources.SAVE;
            this.ButtonSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonSave.Margin = new System.Windows.Forms.Padding(10, 1, 0, 2);
            this.ButtonSave.Name = "ButtonSave";
            this.ButtonSave.Size = new System.Drawing.Size(44, 35);
            this.ButtonSave.Text = "Save";
            this.ButtonSave.Click += new System.EventHandler(this.ButtonSave_Click);
            // 
            // ButtonSaveAll
            // 
            this.ButtonSaveAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonSaveAll.Image = global::KidSparkPainting.Properties.Resources.SAVEALL;
            this.ButtonSaveAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonSaveAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonSaveAll.Name = "ButtonSaveAll";
            this.ButtonSaveAll.Size = new System.Drawing.Size(41, 35);
            this.ButtonSaveAll.Text = "Save All";
            this.ButtonSaveAll.Click += new System.EventHandler(this.ButtonSaveAll_Click);
            // 
            // ButtonPenColor
            // 
            this.ButtonPenColor.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonPenColor.Image = global::KidSparkPainting.Properties.Resources.COLOR;
            this.ButtonPenColor.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonPenColor.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonPenColor.Margin = new System.Windows.Forms.Padding(5, 1, 0, 2);
            this.ButtonPenColor.Name = "ButtonPenColor";
            this.ButtonPenColor.Size = new System.Drawing.Size(36, 35);
            this.ButtonPenColor.Text = "Pen Color";
            this.ButtonPenColor.Click += new System.EventHandler(this.ButtonPenColor_Click);
            // 
            // ButtonPenWidth
            // 
            this.ButtonPenWidth.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPenWidth.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonPenWidth.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.PenThick,
            this.PenMiddle,
            this.PenThin});
            this.ButtonPenWidth.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPenWidth.Image")));
            this.ButtonPenWidth.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonPenWidth.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonPenWidth.Margin = new System.Windows.Forms.Padding(5, 1, 0, 2);
            this.ButtonPenWidth.Name = "ButtonPenWidth";
            this.ButtonPenWidth.Size = new System.Drawing.Size(95, 35);
            this.ButtonPenWidth.Text = "Pen Width";
            // 
            // PenThick
            // 
            this.PenThick.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold);
            this.PenThick.Image = global::KidSparkPainting.Properties.Resources.PENWIDTHTHICK;
            this.PenThick.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.PenThick.Name = "PenThick";
            this.PenThick.Size = new System.Drawing.Size(142, 24);
            this.PenThick.Text = "Thick";
            this.PenThick.Click += new System.EventHandler(this.PenThick_Click);
            // 
            // PenMiddle
            // 
            this.PenMiddle.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold);
            this.PenMiddle.Image = global::KidSparkPainting.Properties.Resources.PENWIDTHMIDDLE;
            this.PenMiddle.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.PenMiddle.Name = "PenMiddle";
            this.PenMiddle.Size = new System.Drawing.Size(142, 24);
            this.PenMiddle.Text = "Middle";
            this.PenMiddle.Click += new System.EventHandler(this.PenMiddle_Click);
            // 
            // PenThin
            // 
            this.PenThin.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold);
            this.PenThin.Image = global::KidSparkPainting.Properties.Resources.PENWIDTHTHIN;
            this.PenThin.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.PenThin.Name = "PenThin";
            this.PenThin.Size = new System.Drawing.Size(142, 24);
            this.PenThin.Text = "Thin";
            this.PenThin.Click += new System.EventHandler(this.PenThin_Click);
            // 
            // ButtonNextPage
            // 
            this.ButtonNextPage.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.ButtonNextPage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonNextPage.Image = global::KidSparkPainting.Properties.Resources.NOTSHOWTOOLS;
            this.ButtonNextPage.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonNextPage.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonNextPage.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.ButtonNextPage.Name = "ButtonNextPage";
            this.ButtonNextPage.Size = new System.Drawing.Size(47, 35);
            this.ButtonNextPage.Text = "下一页";
            this.ButtonNextPage.Click += new System.EventHandler(this.ButtonNextPage_Click);
            // 
            // ButtonPrePage
            // 
            this.ButtonPrePage.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.ButtonPrePage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonPrePage.Image = global::KidSparkPainting.Properties.Resources.SHOWTOOLS;
            this.ButtonPrePage.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonPrePage.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonPrePage.Name = "ButtonPrePage";
            this.ButtonPrePage.Size = new System.Drawing.Size(47, 35);
            this.ButtonPrePage.Text = "上一页";
            this.ButtonPrePage.Click += new System.EventHandler(this.ButtonPrePage_Click);
            // 
            // ButtonPencil
            // 
            this.ButtonPencil.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonPencil.Image = global::KidSparkPainting.Properties.Resources.PENCIL;
            this.ButtonPencil.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonPencil.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonPencil.Name = "ButtonPencil";
            this.ButtonPencil.Size = new System.Drawing.Size(35, 35);
            this.ButtonPencil.Text = "Pencil";
            this.ButtonPencil.Click += new System.EventHandler(this.ButtonPencil_Click);
            // 
            // ButtonChineseBrush
            // 
            this.ButtonChineseBrush.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonChineseBrush.Image = global::KidSparkPainting.Properties.Resources.Brush;
            this.ButtonChineseBrush.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonChineseBrush.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonChineseBrush.Name = "ButtonChineseBrush";
            this.ButtonChineseBrush.Size = new System.Drawing.Size(28, 35);
            this.ButtonChineseBrush.Text = "Brush";
            this.ButtonChineseBrush.Click += new System.EventHandler(this.ButtonNiteWriterPen_Click);
            // 
            // ButtonPoint
            // 
            this.ButtonPoint.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonPoint.Image = global::KidSparkPainting.Properties.Resources.POINT;
            this.ButtonPoint.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ButtonPoint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonPoint.Name = "ButtonPoint";
            this.ButtonPoint.Size = new System.Drawing.Size(35, 35);
            this.ButtonPoint.Text = "Point";
            this.ButtonPoint.Click += new System.EventHandler(this.ButtonPoint_Click);
            // 
            // OpenDocWinForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1073, 646);
            this.Controls.Add(this.PanelMain);
            this.Controls.Add(this.OpenDocTools);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "OpenDocWinForm";
            this.Text = "KidSparkDocument";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.OpenDocWinForm_Load);
            this.OpenDocTools.ResumeLayout(false);
            this.OpenDocTools.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip OpenDocTools;
        private System.Windows.Forms.ToolStripButton ButtonSave;
        private System.Windows.Forms.ToolStripButton ButtonPenColor;
        private System.Windows.Forms.ToolStripButton ButtonPrePage;
        private System.Windows.Forms.ToolStripButton ButtonNextPage;
        private System.Windows.Forms.Panel PanelMain;
        private System.Windows.Forms.ToolStripComboBox ButtonGotoPage;
        private System.Windows.Forms.ToolStripButton ButtonSaveAll;
        private System.Windows.Forms.ToolStripDropDownButton ButtonPenWidth;
        private System.Windows.Forms.ToolStripMenuItem PenThick;
        private System.Windows.Forms.ToolStripMenuItem PenMiddle;
        private System.Windows.Forms.ToolStripMenuItem PenThin;
        private System.Windows.Forms.ToolStripButton ButtonPencil;
        private System.Windows.Forms.ToolStripButton ButtonChineseBrush;
        private System.Windows.Forms.ToolStripLabel LableShowPage;
        private System.Windows.Forms.ToolStripButton ButtonPoint;
        public DocDraw docdraw;

    }
}