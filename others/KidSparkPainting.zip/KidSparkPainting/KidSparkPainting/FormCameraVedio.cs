﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;


namespace KidSparkPainting
{
    public partial class FormCameraVedio : Form
    {
        public FormCameraVedio()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;    //窗口位于屏幕的中央位置
            this.skinEngine.SkinFile = "MP10.ssk";    //变换皮肤
        }

        //加载Flash用参数
        Process process = null;
        IntPtr appWin;
        private string exeName = "";

        //加载
        private void FormCameraVedio_Load(object sender, EventArgs e)
        {
            this.exeName = Application.StartupPath + @"\Camera\Camera.exe";
            try
            {
                // Start the process 
                process = System.Diagnostics.Process.Start(this.exeName);

                // Wait for process to be created and enter idle condition 
                process.WaitForInputIdle();

                // Get the main handle
                appWin = process.MainWindowHandle;

                // Put it into this form
                SetParent(appWin, this.Handle);

                // Remove border and whatnot
                SetWindowLong(appWin, GWL_STYLE, WS_VISIBLE);

                // Move the window to overlay it on this window
                MoveWindow(appWin, 0, 0, this.Width, this.Height, true);

                //页面改变大小
                this.Resize += new EventHandler(FormCameraVedio_Resize);

                //页面关闭
                this.FormClosed += new FormClosedEventHandler(FormCameraVedio_FormClosed);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Error");
                this.Dispose();
            }
        }

        //页面退出
        private void FormCameraVedio_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                process.Kill();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Close Error:" + ex.Message.ToString());
            }
        }

        //页面改变大小
        private void FormCameraVedio_Resize(object sender, EventArgs e)
        {
            if (this.appWin != IntPtr.Zero)
            {
                MoveWindow(appWin, 0, 0, this.Width, this.Height, true);
            }
            //base.OnResize(e);
        }

        #region API调用

        [DllImport("user32.dll", EntryPoint = "GetWindowThreadProcessId", 
            SetLastError = true,CharSet = CharSet.Unicode, 
            ExactSpelling = true,
            CallingConvention = CallingConvention.StdCall)]
        private static extern long GetWindowThreadProcessId(long hWnd, long lpdwProcessId);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern long SetParent(IntPtr hWndChild, IntPtr hWndNewParent);

        [DllImport("user32.dll", EntryPoint = "GetWindowLongA", SetLastError = true)]
        private static extern long GetWindowLong(IntPtr hwnd, int nIndex);

        [DllImport("user32.dll", EntryPoint = "SetWindowLongA", SetLastError = true)]
        private static extern long SetWindowLong(IntPtr hwnd, int nIndex, long dwNewLong);

        //private static extern int SetWindowLong(IntPtr hWnd, int nIndex, IntPtr dwNewLong);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern long SetWindowPos(IntPtr hwnd, long hWndInsertAfter, long x, long y, long cx, long cy, long wFlags);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool MoveWindow(IntPtr hwnd, int x, int y, int cx, int cy, bool repaint);

        [DllImport("user32.dll", EntryPoint = "PostMessageA", SetLastError = true)]
        private static extern bool PostMessage(IntPtr hwnd, uint Msg, long wParam, long lParam);

        private const int SWP_NOOWNERZORDER = 0x200;
        private const int SWP_NOREDRAW = 0x8;
        private const int SWP_NOZORDER = 0x4;
        private const int SWP_SHOWWINDOW = 0x0040;
        private const int WS_EX_MDICHILD = 0x40;
        private const int SWP_FRAMECHANGED = 0x20;
        private const int SWP_NOACTIVATE = 0x10;
        private const int SWP_ASYNCWINDOWPOS = 0x4000;
        private const int SWP_NOMOVE = 0x2;
        private const int SWP_NOSIZE = 0x1;
        private const int GWL_STYLE = (-16);
        private const int WS_VISIBLE = 0x10000000;
        private const int WM_CLOSE = 0x10;
        private const int WS_CHILD = 0x40000000;
        #endregion API调用

        public string ExeName
        {
            get
            {
                return exeName;
            }
            set
            {
                exeName = value;
            }
        }
    }
}
