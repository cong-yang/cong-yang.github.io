﻿namespace KidSparkPainting
{
    partial class MoreTexturePen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MoreTexturePen));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButtonZipZag = new System.Windows.Forms.RadioButton();
            this.radioButtonWideUpwardDiagonal = new System.Windows.Forms.RadioButton();
            this.radioButtonWideDownwardDiagonal = new System.Windows.Forms.RadioButton();
            this.radioButtonWeave = new System.Windows.Forms.RadioButton();
            this.radioButtonWave = new System.Windows.Forms.RadioButton();
            this.radioButtonVertical = new System.Windows.Forms.RadioButton();
            this.radioButtonTrellis = new System.Windows.Forms.RadioButton();
            this.radioButtonSphere = new System.Windows.Forms.RadioButton();
            this.radioButtonSolidDiamond = new System.Windows.Forms.RadioButton();
            this.radioButtonSmallGrid = new System.Windows.Forms.RadioButton();
            this.radioButtonSmallConfetti = new System.Windows.Forms.RadioButton();
            this.radioButtonSmallCheckerBoard = new System.Windows.Forms.RadioButton();
            this.radioButtonShingle = new System.Windows.Forms.RadioButton();
            this.radioButtonPlaid = new System.Windows.Forms.RadioButton();
            this.radioButtonPercent90 = new System.Windows.Forms.RadioButton();
            this.radioButtonPercent75 = new System.Windows.Forms.RadioButton();
            this.radioButtonPercent70 = new System.Windows.Forms.RadioButton();
            this.radioButtonPercent60 = new System.Windows.Forms.RadioButton();
            this.radioButtonPercent50 = new System.Windows.Forms.RadioButton();
            this.radioButtonPercent40 = new System.Windows.Forms.RadioButton();
            this.radioButtonPercent30 = new System.Windows.Forms.RadioButton();
            this.radioButtonPercent25 = new System.Windows.Forms.RadioButton();
            this.radioButtonPercent20 = new System.Windows.Forms.RadioButton();
            this.radioButtonPercent10 = new System.Windows.Forms.RadioButton();
            this.radioButtonPercent05 = new System.Windows.Forms.RadioButton();
            this.radioButtonOutlinedDiamond = new System.Windows.Forms.RadioButton();
            this.radioButtonNarrowHorizontal = new System.Windows.Forms.RadioButton();
            this.radioButtonLightVertical = new System.Windows.Forms.RadioButton();
            this.radioButtonLightHorizontal = new System.Windows.Forms.RadioButton();
            this.radioButtonLightDownwardDiagonal = new System.Windows.Forms.RadioButton();
            this.radioButtonLargeGrid = new System.Windows.Forms.RadioButton();
            this.radioButtonLargeConfetti = new System.Windows.Forms.RadioButton();
            this.radioButtonLargeCheckerBoard = new System.Windows.Forms.RadioButton();
            this.radioButtonHorizontalBrick = new System.Windows.Forms.RadioButton();
            this.radioButtonHorizontal = new System.Windows.Forms.RadioButton();
            this.radioButtonForwardDiagonal = new System.Windows.Forms.RadioButton();
            this.radioButtonDottedGrid = new System.Windows.Forms.RadioButton();
            this.radioButtonPercent80 = new System.Windows.Forms.RadioButton();
            this.radioButtonNarrowVertical = new System.Windows.Forms.RadioButton();
            this.radioButtonDottedDiamond = new System.Windows.Forms.RadioButton();
            this.radioButtonDivot = new System.Windows.Forms.RadioButton();
            this.radioButtonDiagonalCross = new System.Windows.Forms.RadioButton();
            this.radioButtonDiagonalBrick = new System.Windows.Forms.RadioButton();
            this.radioButtonDashedVertical = new System.Windows.Forms.RadioButton();
            this.radioButtonDashedUpwardDiagonal = new System.Windows.Forms.RadioButton();
            this.radioButtonDashedHorizontal = new System.Windows.Forms.RadioButton();
            this.radioButtonDashedDownwardDiagonal = new System.Windows.Forms.RadioButton();
            this.radioButtonDarkVertical = new System.Windows.Forms.RadioButton();
            this.radioButtonDarkUpwardDiagonal = new System.Windows.Forms.RadioButton();
            this.radioButtonDarkHorizontal = new System.Windows.Forms.RadioButton();
            this.radioButtonDarkDownwardDiagonal = new System.Windows.Forms.RadioButton();
            this.radioButtonBackwardDiagonal = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pictureBoxPreview = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.LabelName = new System.Windows.Forms.Label();
            this.ButtonCancel = new System.Windows.Forms.PictureBox();
            this.ButtonOk = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPreview)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonCancel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonOk)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.radioButtonZipZag);
            this.groupBox1.Controls.Add(this.radioButtonWideUpwardDiagonal);
            this.groupBox1.Controls.Add(this.radioButtonWideDownwardDiagonal);
            this.groupBox1.Controls.Add(this.radioButtonWeave);
            this.groupBox1.Controls.Add(this.radioButtonWave);
            this.groupBox1.Controls.Add(this.radioButtonVertical);
            this.groupBox1.Controls.Add(this.radioButtonTrellis);
            this.groupBox1.Controls.Add(this.radioButtonSphere);
            this.groupBox1.Controls.Add(this.radioButtonSolidDiamond);
            this.groupBox1.Controls.Add(this.radioButtonSmallGrid);
            this.groupBox1.Controls.Add(this.radioButtonSmallConfetti);
            this.groupBox1.Controls.Add(this.radioButtonSmallCheckerBoard);
            this.groupBox1.Controls.Add(this.radioButtonShingle);
            this.groupBox1.Controls.Add(this.radioButtonPlaid);
            this.groupBox1.Controls.Add(this.radioButtonPercent90);
            this.groupBox1.Controls.Add(this.radioButtonPercent75);
            this.groupBox1.Controls.Add(this.radioButtonPercent70);
            this.groupBox1.Controls.Add(this.radioButtonPercent60);
            this.groupBox1.Controls.Add(this.radioButtonPercent50);
            this.groupBox1.Controls.Add(this.radioButtonPercent40);
            this.groupBox1.Controls.Add(this.radioButtonPercent30);
            this.groupBox1.Controls.Add(this.radioButtonPercent25);
            this.groupBox1.Controls.Add(this.radioButtonPercent20);
            this.groupBox1.Controls.Add(this.radioButtonPercent10);
            this.groupBox1.Controls.Add(this.radioButtonPercent05);
            this.groupBox1.Controls.Add(this.radioButtonOutlinedDiamond);
            this.groupBox1.Controls.Add(this.radioButtonNarrowHorizontal);
            this.groupBox1.Controls.Add(this.radioButtonLightVertical);
            this.groupBox1.Controls.Add(this.radioButtonLightHorizontal);
            this.groupBox1.Controls.Add(this.radioButtonLightDownwardDiagonal);
            this.groupBox1.Controls.Add(this.radioButtonLargeGrid);
            this.groupBox1.Controls.Add(this.radioButtonLargeConfetti);
            this.groupBox1.Controls.Add(this.radioButtonLargeCheckerBoard);
            this.groupBox1.Controls.Add(this.radioButtonHorizontalBrick);
            this.groupBox1.Controls.Add(this.radioButtonHorizontal);
            this.groupBox1.Controls.Add(this.radioButtonForwardDiagonal);
            this.groupBox1.Controls.Add(this.radioButtonDottedGrid);
            this.groupBox1.Controls.Add(this.radioButtonPercent80);
            this.groupBox1.Controls.Add(this.radioButtonNarrowVertical);
            this.groupBox1.Controls.Add(this.radioButtonDottedDiamond);
            this.groupBox1.Controls.Add(this.radioButtonDivot);
            this.groupBox1.Controls.Add(this.radioButtonDiagonalCross);
            this.groupBox1.Controls.Add(this.radioButtonDiagonalBrick);
            this.groupBox1.Controls.Add(this.radioButtonDashedVertical);
            this.groupBox1.Controls.Add(this.radioButtonDashedUpwardDiagonal);
            this.groupBox1.Controls.Add(this.radioButtonDashedHorizontal);
            this.groupBox1.Controls.Add(this.radioButtonDashedDownwardDiagonal);
            this.groupBox1.Controls.Add(this.radioButtonDarkVertical);
            this.groupBox1.Controls.Add(this.radioButtonDarkUpwardDiagonal);
            this.groupBox1.Controls.Add(this.radioButtonDarkHorizontal);
            this.groupBox1.Controls.Add(this.radioButtonDarkDownwardDiagonal);
            this.groupBox1.Controls.Add(this.radioButtonBackwardDiagonal);
            this.groupBox1.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(783, 286);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "All Texture Pen";
            // 
            // radioButtonZipZag
            // 
            this.radioButtonZipZag.Image = global::KidSparkPainting.Properties.Resources.ZipZagSmall;
            this.radioButtonZipZag.Location = new System.Drawing.Point(205, 242);
            this.radioButtonZipZag.Name = "radioButtonZipZag";
            this.radioButtonZipZag.Size = new System.Drawing.Size(57, 28);
            this.radioButtonZipZag.TabIndex = 51;
            this.radioButtonZipZag.TabStop = true;
            this.radioButtonZipZag.UseVisualStyleBackColor = true;
            this.radioButtonZipZag.CheckedChanged += new System.EventHandler(this.radioButtonZipZag_CheckedChanged);
            // 
            // radioButtonWideUpwardDiagonal
            // 
            this.radioButtonWideUpwardDiagonal.Image = global::KidSparkPainting.Properties.Resources.WideUpwardDiagonalSmall;
            this.radioButtonWideUpwardDiagonal.Location = new System.Drawing.Point(142, 242);
            this.radioButtonWideUpwardDiagonal.Name = "radioButtonWideUpwardDiagonal";
            this.radioButtonWideUpwardDiagonal.Size = new System.Drawing.Size(57, 28);
            this.radioButtonWideUpwardDiagonal.TabIndex = 50;
            this.radioButtonWideUpwardDiagonal.TabStop = true;
            this.radioButtonWideUpwardDiagonal.UseVisualStyleBackColor = true;
            this.radioButtonWideUpwardDiagonal.CheckedChanged += new System.EventHandler(this.radioButtonWideUpwardDiagonal_CheckedChanged);
            // 
            // radioButtonWideDownwardDiagonal
            // 
            this.radioButtonWideDownwardDiagonal.Image = global::KidSparkPainting.Properties.Resources.WideDownwardDiagonalSmall;
            this.radioButtonWideDownwardDiagonal.Location = new System.Drawing.Point(79, 242);
            this.radioButtonWideDownwardDiagonal.Name = "radioButtonWideDownwardDiagonal";
            this.radioButtonWideDownwardDiagonal.Size = new System.Drawing.Size(57, 28);
            this.radioButtonWideDownwardDiagonal.TabIndex = 49;
            this.radioButtonWideDownwardDiagonal.TabStop = true;
            this.radioButtonWideDownwardDiagonal.UseVisualStyleBackColor = true;
            this.radioButtonWideDownwardDiagonal.CheckedChanged += new System.EventHandler(this.radioButtonWideDownwardDiagonal_CheckedChanged);
            // 
            // radioButtonWeave
            // 
            this.radioButtonWeave.Image = global::KidSparkPainting.Properties.Resources.WeaveSmall;
            this.radioButtonWeave.Location = new System.Drawing.Point(16, 242);
            this.radioButtonWeave.Name = "radioButtonWeave";
            this.radioButtonWeave.Size = new System.Drawing.Size(57, 28);
            this.radioButtonWeave.TabIndex = 48;
            this.radioButtonWeave.TabStop = true;
            this.radioButtonWeave.UseVisualStyleBackColor = true;
            this.radioButtonWeave.CheckedChanged += new System.EventHandler(this.radioButtonWeave_CheckedChanged);
            // 
            // radioButtonWave
            // 
            this.radioButtonWave.Image = global::KidSparkPainting.Properties.Resources.WaveSmall;
            this.radioButtonWave.Location = new System.Drawing.Point(709, 194);
            this.radioButtonWave.Name = "radioButtonWave";
            this.radioButtonWave.Size = new System.Drawing.Size(57, 28);
            this.radioButtonWave.TabIndex = 47;
            this.radioButtonWave.TabStop = true;
            this.radioButtonWave.UseVisualStyleBackColor = true;
            this.radioButtonWave.CheckedChanged += new System.EventHandler(this.radioButtonWave_CheckedChanged);
            // 
            // radioButtonVertical
            // 
            this.radioButtonVertical.Image = global::KidSparkPainting.Properties.Resources.VerticalSmall;
            this.radioButtonVertical.Location = new System.Drawing.Point(646, 194);
            this.radioButtonVertical.Name = "radioButtonVertical";
            this.radioButtonVertical.Size = new System.Drawing.Size(57, 28);
            this.radioButtonVertical.TabIndex = 46;
            this.radioButtonVertical.TabStop = true;
            this.radioButtonVertical.UseVisualStyleBackColor = true;
            this.radioButtonVertical.CheckedChanged += new System.EventHandler(this.radioButtonVertical_CheckedChanged);
            // 
            // radioButtonTrellis
            // 
            this.radioButtonTrellis.Image = global::KidSparkPainting.Properties.Resources.TrellisSmall;
            this.radioButtonTrellis.Location = new System.Drawing.Point(583, 194);
            this.radioButtonTrellis.Name = "radioButtonTrellis";
            this.radioButtonTrellis.Size = new System.Drawing.Size(57, 28);
            this.radioButtonTrellis.TabIndex = 45;
            this.radioButtonTrellis.TabStop = true;
            this.radioButtonTrellis.UseVisualStyleBackColor = true;
            this.radioButtonTrellis.CheckedChanged += new System.EventHandler(this.radioButtonTrellis_CheckedChanged);
            // 
            // radioButtonSphere
            // 
            this.radioButtonSphere.Image = global::KidSparkPainting.Properties.Resources.SphereSmall;
            this.radioButtonSphere.Location = new System.Drawing.Point(520, 194);
            this.radioButtonSphere.Name = "radioButtonSphere";
            this.radioButtonSphere.Size = new System.Drawing.Size(57, 28);
            this.radioButtonSphere.TabIndex = 44;
            this.radioButtonSphere.TabStop = true;
            this.radioButtonSphere.UseVisualStyleBackColor = true;
            this.radioButtonSphere.CheckedChanged += new System.EventHandler(this.radioButtonSphere_CheckedChanged);
            // 
            // radioButtonSolidDiamond
            // 
            this.radioButtonSolidDiamond.Image = global::KidSparkPainting.Properties.Resources.SolidDiamondSmall;
            this.radioButtonSolidDiamond.Location = new System.Drawing.Point(457, 194);
            this.radioButtonSolidDiamond.Name = "radioButtonSolidDiamond";
            this.radioButtonSolidDiamond.Size = new System.Drawing.Size(57, 28);
            this.radioButtonSolidDiamond.TabIndex = 43;
            this.radioButtonSolidDiamond.TabStop = true;
            this.radioButtonSolidDiamond.UseVisualStyleBackColor = true;
            this.radioButtonSolidDiamond.CheckedChanged += new System.EventHandler(this.radioButtonSolidDiamond_CheckedChanged);
            // 
            // radioButtonSmallGrid
            // 
            this.radioButtonSmallGrid.Image = global::KidSparkPainting.Properties.Resources.SmallGridSmall;
            this.radioButtonSmallGrid.Location = new System.Drawing.Point(394, 194);
            this.radioButtonSmallGrid.Name = "radioButtonSmallGrid";
            this.radioButtonSmallGrid.Size = new System.Drawing.Size(57, 28);
            this.radioButtonSmallGrid.TabIndex = 42;
            this.radioButtonSmallGrid.TabStop = true;
            this.radioButtonSmallGrid.UseVisualStyleBackColor = true;
            this.radioButtonSmallGrid.CheckedChanged += new System.EventHandler(this.radioButtonSmallGrid_CheckedChanged);
            // 
            // radioButtonSmallConfetti
            // 
            this.radioButtonSmallConfetti.Image = global::KidSparkPainting.Properties.Resources.SmallConfettiSmall;
            this.radioButtonSmallConfetti.Location = new System.Drawing.Point(331, 194);
            this.radioButtonSmallConfetti.Name = "radioButtonSmallConfetti";
            this.radioButtonSmallConfetti.Size = new System.Drawing.Size(57, 28);
            this.radioButtonSmallConfetti.TabIndex = 41;
            this.radioButtonSmallConfetti.TabStop = true;
            this.radioButtonSmallConfetti.UseVisualStyleBackColor = true;
            this.radioButtonSmallConfetti.CheckedChanged += new System.EventHandler(this.radioButtonSmallConfetti_CheckedChanged);
            // 
            // radioButtonSmallCheckerBoard
            // 
            this.radioButtonSmallCheckerBoard.Image = global::KidSparkPainting.Properties.Resources.SmallCheckerBoardSmall;
            this.radioButtonSmallCheckerBoard.Location = new System.Drawing.Point(268, 194);
            this.radioButtonSmallCheckerBoard.Name = "radioButtonSmallCheckerBoard";
            this.radioButtonSmallCheckerBoard.Size = new System.Drawing.Size(57, 28);
            this.radioButtonSmallCheckerBoard.TabIndex = 40;
            this.radioButtonSmallCheckerBoard.TabStop = true;
            this.radioButtonSmallCheckerBoard.UseVisualStyleBackColor = true;
            this.radioButtonSmallCheckerBoard.CheckedChanged += new System.EventHandler(this.radioButtonSmallCheckerBoard_CheckedChanged);
            // 
            // radioButtonShingle
            // 
            this.radioButtonShingle.Image = global::KidSparkPainting.Properties.Resources.ShingleSmall;
            this.radioButtonShingle.Location = new System.Drawing.Point(205, 194);
            this.radioButtonShingle.Name = "radioButtonShingle";
            this.radioButtonShingle.Size = new System.Drawing.Size(57, 28);
            this.radioButtonShingle.TabIndex = 39;
            this.radioButtonShingle.TabStop = true;
            this.radioButtonShingle.UseVisualStyleBackColor = true;
            this.radioButtonShingle.CheckedChanged += new System.EventHandler(this.radioButtonShingle_CheckedChanged);
            // 
            // radioButtonPlaid
            // 
            this.radioButtonPlaid.Image = global::KidSparkPainting.Properties.Resources.PlaidSmall;
            this.radioButtonPlaid.Location = new System.Drawing.Point(142, 194);
            this.radioButtonPlaid.Name = "radioButtonPlaid";
            this.radioButtonPlaid.Size = new System.Drawing.Size(57, 28);
            this.radioButtonPlaid.TabIndex = 38;
            this.radioButtonPlaid.TabStop = true;
            this.radioButtonPlaid.UseVisualStyleBackColor = true;
            this.radioButtonPlaid.CheckedChanged += new System.EventHandler(this.radioButtonPlaid_CheckedChanged);
            // 
            // radioButtonPercent90
            // 
            this.radioButtonPercent90.Image = global::KidSparkPainting.Properties.Resources.Percent90Small;
            this.radioButtonPercent90.Location = new System.Drawing.Point(79, 194);
            this.radioButtonPercent90.Name = "radioButtonPercent90";
            this.radioButtonPercent90.Size = new System.Drawing.Size(57, 28);
            this.radioButtonPercent90.TabIndex = 37;
            this.radioButtonPercent90.TabStop = true;
            this.radioButtonPercent90.UseVisualStyleBackColor = true;
            this.radioButtonPercent90.CheckedChanged += new System.EventHandler(this.radioButtonPercent90_CheckedChanged);
            // 
            // radioButtonPercent75
            // 
            this.radioButtonPercent75.Image = global::KidSparkPainting.Properties.Resources.Percent75Small;
            this.radioButtonPercent75.Location = new System.Drawing.Point(709, 140);
            this.radioButtonPercent75.Name = "radioButtonPercent75";
            this.radioButtonPercent75.Size = new System.Drawing.Size(57, 28);
            this.radioButtonPercent75.TabIndex = 36;
            this.radioButtonPercent75.TabStop = true;
            this.radioButtonPercent75.UseVisualStyleBackColor = true;
            this.radioButtonPercent75.CheckedChanged += new System.EventHandler(this.radioButtonPercent75_CheckedChanged);
            // 
            // radioButtonPercent70
            // 
            this.radioButtonPercent70.Image = global::KidSparkPainting.Properties.Resources.Percent70Small;
            this.radioButtonPercent70.Location = new System.Drawing.Point(646, 140);
            this.radioButtonPercent70.Name = "radioButtonPercent70";
            this.radioButtonPercent70.Size = new System.Drawing.Size(57, 28);
            this.radioButtonPercent70.TabIndex = 35;
            this.radioButtonPercent70.TabStop = true;
            this.radioButtonPercent70.UseVisualStyleBackColor = true;
            this.radioButtonPercent70.CheckedChanged += new System.EventHandler(this.radioButtonPercent70_CheckedChanged);
            // 
            // radioButtonPercent60
            // 
            this.radioButtonPercent60.Image = global::KidSparkPainting.Properties.Resources.Percent60Small;
            this.radioButtonPercent60.Location = new System.Drawing.Point(583, 140);
            this.radioButtonPercent60.Name = "radioButtonPercent60";
            this.radioButtonPercent60.Size = new System.Drawing.Size(57, 28);
            this.radioButtonPercent60.TabIndex = 34;
            this.radioButtonPercent60.TabStop = true;
            this.radioButtonPercent60.UseVisualStyleBackColor = true;
            this.radioButtonPercent60.CheckedChanged += new System.EventHandler(this.radioButtonPercent60_CheckedChanged);
            // 
            // radioButtonPercent50
            // 
            this.radioButtonPercent50.Image = global::KidSparkPainting.Properties.Resources.Percent50Small;
            this.radioButtonPercent50.Location = new System.Drawing.Point(520, 140);
            this.radioButtonPercent50.Name = "radioButtonPercent50";
            this.radioButtonPercent50.Size = new System.Drawing.Size(57, 28);
            this.radioButtonPercent50.TabIndex = 33;
            this.radioButtonPercent50.TabStop = true;
            this.radioButtonPercent50.UseVisualStyleBackColor = true;
            this.radioButtonPercent50.CheckedChanged += new System.EventHandler(this.radioButtonPercent50_CheckedChanged);
            // 
            // radioButtonPercent40
            // 
            this.radioButtonPercent40.Image = global::KidSparkPainting.Properties.Resources.Percent40Small;
            this.radioButtonPercent40.Location = new System.Drawing.Point(457, 140);
            this.radioButtonPercent40.Name = "radioButtonPercent40";
            this.radioButtonPercent40.Size = new System.Drawing.Size(57, 28);
            this.radioButtonPercent40.TabIndex = 32;
            this.radioButtonPercent40.TabStop = true;
            this.radioButtonPercent40.UseVisualStyleBackColor = true;
            this.radioButtonPercent40.CheckedChanged += new System.EventHandler(this.radioButtonPercent40_CheckedChanged);
            // 
            // radioButtonPercent30
            // 
            this.radioButtonPercent30.Image = global::KidSparkPainting.Properties.Resources.Percent30Small;
            this.radioButtonPercent30.Location = new System.Drawing.Point(394, 140);
            this.radioButtonPercent30.Name = "radioButtonPercent30";
            this.radioButtonPercent30.Size = new System.Drawing.Size(57, 28);
            this.radioButtonPercent30.TabIndex = 31;
            this.radioButtonPercent30.TabStop = true;
            this.radioButtonPercent30.UseVisualStyleBackColor = true;
            this.radioButtonPercent30.CheckedChanged += new System.EventHandler(this.radioButtonPercent30_CheckedChanged);
            // 
            // radioButtonPercent25
            // 
            this.radioButtonPercent25.Image = global::KidSparkPainting.Properties.Resources.Percent25Small;
            this.radioButtonPercent25.Location = new System.Drawing.Point(331, 140);
            this.radioButtonPercent25.Name = "radioButtonPercent25";
            this.radioButtonPercent25.Size = new System.Drawing.Size(57, 28);
            this.radioButtonPercent25.TabIndex = 30;
            this.radioButtonPercent25.TabStop = true;
            this.radioButtonPercent25.UseVisualStyleBackColor = true;
            this.radioButtonPercent25.CheckedChanged += new System.EventHandler(this.radioButtonPercent25_CheckedChanged);
            // 
            // radioButtonPercent20
            // 
            this.radioButtonPercent20.Image = global::KidSparkPainting.Properties.Resources.Percent20Small;
            this.radioButtonPercent20.Location = new System.Drawing.Point(268, 140);
            this.radioButtonPercent20.Name = "radioButtonPercent20";
            this.radioButtonPercent20.Size = new System.Drawing.Size(57, 28);
            this.radioButtonPercent20.TabIndex = 29;
            this.radioButtonPercent20.TabStop = true;
            this.radioButtonPercent20.UseVisualStyleBackColor = true;
            this.radioButtonPercent20.CheckedChanged += new System.EventHandler(this.radioButtonPercent20_CheckedChanged);
            // 
            // radioButtonPercent10
            // 
            this.radioButtonPercent10.Image = global::KidSparkPainting.Properties.Resources.Percent10Small;
            this.radioButtonPercent10.Location = new System.Drawing.Point(205, 140);
            this.radioButtonPercent10.Name = "radioButtonPercent10";
            this.radioButtonPercent10.Size = new System.Drawing.Size(57, 28);
            this.radioButtonPercent10.TabIndex = 28;
            this.radioButtonPercent10.TabStop = true;
            this.radioButtonPercent10.UseVisualStyleBackColor = true;
            this.radioButtonPercent10.CheckedChanged += new System.EventHandler(this.radioButtonPercent10_CheckedChanged);
            // 
            // radioButtonPercent05
            // 
            this.radioButtonPercent05.Image = global::KidSparkPainting.Properties.Resources.Percent05Small;
            this.radioButtonPercent05.Location = new System.Drawing.Point(142, 140);
            this.radioButtonPercent05.Name = "radioButtonPercent05";
            this.radioButtonPercent05.Size = new System.Drawing.Size(57, 28);
            this.radioButtonPercent05.TabIndex = 27;
            this.radioButtonPercent05.TabStop = true;
            this.radioButtonPercent05.UseVisualStyleBackColor = true;
            this.radioButtonPercent05.CheckedChanged += new System.EventHandler(this.radioButtonPercent05_CheckedChanged);
            // 
            // radioButtonOutlinedDiamond
            // 
            this.radioButtonOutlinedDiamond.Image = global::KidSparkPainting.Properties.Resources.OutlinedDiamondSmall;
            this.radioButtonOutlinedDiamond.Location = new System.Drawing.Point(79, 140);
            this.radioButtonOutlinedDiamond.Name = "radioButtonOutlinedDiamond";
            this.radioButtonOutlinedDiamond.Size = new System.Drawing.Size(57, 28);
            this.radioButtonOutlinedDiamond.TabIndex = 26;
            this.radioButtonOutlinedDiamond.TabStop = true;
            this.radioButtonOutlinedDiamond.UseVisualStyleBackColor = true;
            this.radioButtonOutlinedDiamond.CheckedChanged += new System.EventHandler(this.radioButtonOutlinedDiamond_CheckedChanged);
            // 
            // radioButtonNarrowHorizontal
            // 
            this.radioButtonNarrowHorizontal.Image = global::KidSparkPainting.Properties.Resources.NarrowHorizontalSmall;
            this.radioButtonNarrowHorizontal.Location = new System.Drawing.Point(709, 87);
            this.radioButtonNarrowHorizontal.Name = "radioButtonNarrowHorizontal";
            this.radioButtonNarrowHorizontal.Size = new System.Drawing.Size(57, 28);
            this.radioButtonNarrowHorizontal.TabIndex = 25;
            this.radioButtonNarrowHorizontal.TabStop = true;
            this.radioButtonNarrowHorizontal.UseVisualStyleBackColor = true;
            this.radioButtonNarrowHorizontal.CheckedChanged += new System.EventHandler(this.radioButtonNarrowHorizontal_CheckedChanged);
            // 
            // radioButtonLightVertical
            // 
            this.radioButtonLightVertical.Image = global::KidSparkPainting.Properties.Resources.LightVerticalSmall;
            this.radioButtonLightVertical.Location = new System.Drawing.Point(646, 87);
            this.radioButtonLightVertical.Name = "radioButtonLightVertical";
            this.radioButtonLightVertical.Size = new System.Drawing.Size(57, 28);
            this.radioButtonLightVertical.TabIndex = 24;
            this.radioButtonLightVertical.TabStop = true;
            this.radioButtonLightVertical.UseVisualStyleBackColor = true;
            this.radioButtonLightVertical.CheckedChanged += new System.EventHandler(this.radioButtonLightVertical_CheckedChanged);
            // 
            // radioButtonLightHorizontal
            // 
            this.radioButtonLightHorizontal.Image = global::KidSparkPainting.Properties.Resources.LightHorizontalSmall;
            this.radioButtonLightHorizontal.Location = new System.Drawing.Point(583, 87);
            this.radioButtonLightHorizontal.Name = "radioButtonLightHorizontal";
            this.radioButtonLightHorizontal.Size = new System.Drawing.Size(57, 28);
            this.radioButtonLightHorizontal.TabIndex = 23;
            this.radioButtonLightHorizontal.TabStop = true;
            this.radioButtonLightHorizontal.UseVisualStyleBackColor = true;
            this.radioButtonLightHorizontal.CheckedChanged += new System.EventHandler(this.radioButtonLightHorizontal_CheckedChanged);
            // 
            // radioButtonLightDownwardDiagonal
            // 
            this.radioButtonLightDownwardDiagonal.Image = global::KidSparkPainting.Properties.Resources.LightDownwardDiagonalSmall;
            this.radioButtonLightDownwardDiagonal.Location = new System.Drawing.Point(520, 87);
            this.radioButtonLightDownwardDiagonal.Name = "radioButtonLightDownwardDiagonal";
            this.radioButtonLightDownwardDiagonal.Size = new System.Drawing.Size(57, 28);
            this.radioButtonLightDownwardDiagonal.TabIndex = 22;
            this.radioButtonLightDownwardDiagonal.TabStop = true;
            this.radioButtonLightDownwardDiagonal.UseVisualStyleBackColor = true;
            this.radioButtonLightDownwardDiagonal.CheckedChanged += new System.EventHandler(this.radioButtonLightDownwardDiagonal_CheckedChanged);
            // 
            // radioButtonLargeGrid
            // 
            this.radioButtonLargeGrid.Image = global::KidSparkPainting.Properties.Resources.LargeGridSmall;
            this.radioButtonLargeGrid.Location = new System.Drawing.Point(457, 87);
            this.radioButtonLargeGrid.Name = "radioButtonLargeGrid";
            this.radioButtonLargeGrid.Size = new System.Drawing.Size(57, 28);
            this.radioButtonLargeGrid.TabIndex = 21;
            this.radioButtonLargeGrid.TabStop = true;
            this.radioButtonLargeGrid.UseVisualStyleBackColor = true;
            this.radioButtonLargeGrid.CheckedChanged += new System.EventHandler(this.radioButtonLargeGrid_CheckedChanged);
            // 
            // radioButtonLargeConfetti
            // 
            this.radioButtonLargeConfetti.Image = global::KidSparkPainting.Properties.Resources.LargeConfettiSmall;
            this.radioButtonLargeConfetti.Location = new System.Drawing.Point(394, 87);
            this.radioButtonLargeConfetti.Name = "radioButtonLargeConfetti";
            this.radioButtonLargeConfetti.Size = new System.Drawing.Size(57, 28);
            this.radioButtonLargeConfetti.TabIndex = 20;
            this.radioButtonLargeConfetti.TabStop = true;
            this.radioButtonLargeConfetti.UseVisualStyleBackColor = true;
            this.radioButtonLargeConfetti.CheckedChanged += new System.EventHandler(this.radioButtonLargeConfetti_CheckedChanged);
            // 
            // radioButtonLargeCheckerBoard
            // 
            this.radioButtonLargeCheckerBoard.Image = global::KidSparkPainting.Properties.Resources.LargeCheckerBoardSmall;
            this.radioButtonLargeCheckerBoard.Location = new System.Drawing.Point(331, 87);
            this.radioButtonLargeCheckerBoard.Name = "radioButtonLargeCheckerBoard";
            this.radioButtonLargeCheckerBoard.Size = new System.Drawing.Size(57, 28);
            this.radioButtonLargeCheckerBoard.TabIndex = 19;
            this.radioButtonLargeCheckerBoard.TabStop = true;
            this.radioButtonLargeCheckerBoard.UseVisualStyleBackColor = true;
            this.radioButtonLargeCheckerBoard.CheckedChanged += new System.EventHandler(this.radioButtonLargeCheckerBoard_CheckedChanged);
            // 
            // radioButtonHorizontalBrick
            // 
            this.radioButtonHorizontalBrick.Image = global::KidSparkPainting.Properties.Resources.HorizontalBrickSmall;
            this.radioButtonHorizontalBrick.Location = new System.Drawing.Point(268, 87);
            this.radioButtonHorizontalBrick.Name = "radioButtonHorizontalBrick";
            this.radioButtonHorizontalBrick.Size = new System.Drawing.Size(57, 28);
            this.radioButtonHorizontalBrick.TabIndex = 18;
            this.radioButtonHorizontalBrick.TabStop = true;
            this.radioButtonHorizontalBrick.UseVisualStyleBackColor = true;
            this.radioButtonHorizontalBrick.CheckedChanged += new System.EventHandler(this.radioButtonHorizontalBrick_CheckedChanged);
            // 
            // radioButtonHorizontal
            // 
            this.radioButtonHorizontal.Image = global::KidSparkPainting.Properties.Resources.HorizontalSmall;
            this.radioButtonHorizontal.Location = new System.Drawing.Point(205, 87);
            this.radioButtonHorizontal.Name = "radioButtonHorizontal";
            this.radioButtonHorizontal.Size = new System.Drawing.Size(57, 28);
            this.radioButtonHorizontal.TabIndex = 17;
            this.radioButtonHorizontal.TabStop = true;
            this.radioButtonHorizontal.UseVisualStyleBackColor = true;
            this.radioButtonHorizontal.CheckedChanged += new System.EventHandler(this.radioButtonHorizontal_CheckedChanged);
            // 
            // radioButtonForwardDiagonal
            // 
            this.radioButtonForwardDiagonal.Image = global::KidSparkPainting.Properties.Resources.ForwardDiagonalSmall;
            this.radioButtonForwardDiagonal.Location = new System.Drawing.Point(142, 87);
            this.radioButtonForwardDiagonal.Name = "radioButtonForwardDiagonal";
            this.radioButtonForwardDiagonal.Size = new System.Drawing.Size(57, 28);
            this.radioButtonForwardDiagonal.TabIndex = 16;
            this.radioButtonForwardDiagonal.TabStop = true;
            this.radioButtonForwardDiagonal.UseVisualStyleBackColor = true;
            this.radioButtonForwardDiagonal.CheckedChanged += new System.EventHandler(this.radioButtonForwardDiagonal_CheckedChanged);
            // 
            // radioButtonDottedGrid
            // 
            this.radioButtonDottedGrid.Image = global::KidSparkPainting.Properties.Resources.DottedGridSmall;
            this.radioButtonDottedGrid.Location = new System.Drawing.Point(79, 87);
            this.radioButtonDottedGrid.Name = "radioButtonDottedGrid";
            this.radioButtonDottedGrid.Size = new System.Drawing.Size(57, 28);
            this.radioButtonDottedGrid.TabIndex = 15;
            this.radioButtonDottedGrid.TabStop = true;
            this.radioButtonDottedGrid.UseVisualStyleBackColor = true;
            this.radioButtonDottedGrid.CheckedChanged += new System.EventHandler(this.radioButtonDottedGrid_CheckedChanged);
            // 
            // radioButtonPercent80
            // 
            this.radioButtonPercent80.Image = global::KidSparkPainting.Properties.Resources.Percent80Small;
            this.radioButtonPercent80.Location = new System.Drawing.Point(16, 194);
            this.radioButtonPercent80.Name = "radioButtonPercent80";
            this.radioButtonPercent80.Size = new System.Drawing.Size(57, 28);
            this.radioButtonPercent80.TabIndex = 14;
            this.radioButtonPercent80.TabStop = true;
            this.radioButtonPercent80.UseVisualStyleBackColor = true;
            this.radioButtonPercent80.CheckedChanged += new System.EventHandler(this.radioButtonPercent80_CheckedChanged);
            // 
            // radioButtonNarrowVertical
            // 
            this.radioButtonNarrowVertical.Image = global::KidSparkPainting.Properties.Resources.NarrowVerticalSmall;
            this.radioButtonNarrowVertical.Location = new System.Drawing.Point(16, 140);
            this.radioButtonNarrowVertical.Name = "radioButtonNarrowVertical";
            this.radioButtonNarrowVertical.Size = new System.Drawing.Size(57, 28);
            this.radioButtonNarrowVertical.TabIndex = 13;
            this.radioButtonNarrowVertical.TabStop = true;
            this.radioButtonNarrowVertical.UseVisualStyleBackColor = true;
            this.radioButtonNarrowVertical.CheckedChanged += new System.EventHandler(this.radioButtonNarrowVertical_CheckedChanged);
            // 
            // radioButtonDottedDiamond
            // 
            this.radioButtonDottedDiamond.Image = global::KidSparkPainting.Properties.Resources.DottedDiamondSmall;
            this.radioButtonDottedDiamond.Location = new System.Drawing.Point(16, 87);
            this.radioButtonDottedDiamond.Name = "radioButtonDottedDiamond";
            this.radioButtonDottedDiamond.Size = new System.Drawing.Size(57, 28);
            this.radioButtonDottedDiamond.TabIndex = 12;
            this.radioButtonDottedDiamond.TabStop = true;
            this.radioButtonDottedDiamond.UseVisualStyleBackColor = true;
            this.radioButtonDottedDiamond.CheckedChanged += new System.EventHandler(this.radioButtonDottedDiamond_CheckedChanged);
            // 
            // radioButtonDivot
            // 
            this.radioButtonDivot.Image = global::KidSparkPainting.Properties.Resources.DivotSmall;
            this.radioButtonDivot.Location = new System.Drawing.Point(709, 33);
            this.radioButtonDivot.Name = "radioButtonDivot";
            this.radioButtonDivot.Size = new System.Drawing.Size(57, 28);
            this.radioButtonDivot.TabIndex = 11;
            this.radioButtonDivot.TabStop = true;
            this.radioButtonDivot.UseVisualStyleBackColor = true;
            this.radioButtonDivot.CheckedChanged += new System.EventHandler(this.radioButtonDivot_CheckedChanged);
            // 
            // radioButtonDiagonalCross
            // 
            this.radioButtonDiagonalCross.Image = global::KidSparkPainting.Properties.Resources.DiagonalCrossSmall;
            this.radioButtonDiagonalCross.Location = new System.Drawing.Point(646, 33);
            this.radioButtonDiagonalCross.Name = "radioButtonDiagonalCross";
            this.radioButtonDiagonalCross.Size = new System.Drawing.Size(57, 28);
            this.radioButtonDiagonalCross.TabIndex = 10;
            this.radioButtonDiagonalCross.TabStop = true;
            this.radioButtonDiagonalCross.UseVisualStyleBackColor = true;
            this.radioButtonDiagonalCross.CheckedChanged += new System.EventHandler(this.radioButtonDiagonalCross_CheckedChanged);
            // 
            // radioButtonDiagonalBrick
            // 
            this.radioButtonDiagonalBrick.Image = global::KidSparkPainting.Properties.Resources.DiagonalBrickSmall;
            this.radioButtonDiagonalBrick.Location = new System.Drawing.Point(583, 33);
            this.radioButtonDiagonalBrick.Name = "radioButtonDiagonalBrick";
            this.radioButtonDiagonalBrick.Size = new System.Drawing.Size(57, 28);
            this.radioButtonDiagonalBrick.TabIndex = 9;
            this.radioButtonDiagonalBrick.TabStop = true;
            this.radioButtonDiagonalBrick.UseVisualStyleBackColor = true;
            this.radioButtonDiagonalBrick.CheckedChanged += new System.EventHandler(this.radioButtonDiagonalBrick_CheckedChanged);
            // 
            // radioButtonDashedVertical
            // 
            this.radioButtonDashedVertical.Image = global::KidSparkPainting.Properties.Resources.DashedVerticalSmall;
            this.radioButtonDashedVertical.Location = new System.Drawing.Point(520, 33);
            this.radioButtonDashedVertical.Name = "radioButtonDashedVertical";
            this.radioButtonDashedVertical.Size = new System.Drawing.Size(57, 28);
            this.radioButtonDashedVertical.TabIndex = 8;
            this.radioButtonDashedVertical.TabStop = true;
            this.radioButtonDashedVertical.UseVisualStyleBackColor = true;
            this.radioButtonDashedVertical.CheckedChanged += new System.EventHandler(this.radioButtonDashedVertical_CheckedChanged);
            // 
            // radioButtonDashedUpwardDiagonal
            // 
            this.radioButtonDashedUpwardDiagonal.Image = global::KidSparkPainting.Properties.Resources.DashedUpwardDiagonalSmall;
            this.radioButtonDashedUpwardDiagonal.Location = new System.Drawing.Point(457, 33);
            this.radioButtonDashedUpwardDiagonal.Name = "radioButtonDashedUpwardDiagonal";
            this.radioButtonDashedUpwardDiagonal.Size = new System.Drawing.Size(57, 28);
            this.radioButtonDashedUpwardDiagonal.TabIndex = 7;
            this.radioButtonDashedUpwardDiagonal.TabStop = true;
            this.radioButtonDashedUpwardDiagonal.UseVisualStyleBackColor = true;
            this.radioButtonDashedUpwardDiagonal.CheckedChanged += new System.EventHandler(this.radioButtonDashedUpwardDiagonal_CheckedChanged);
            // 
            // radioButtonDashedHorizontal
            // 
            this.radioButtonDashedHorizontal.Image = global::KidSparkPainting.Properties.Resources.DashedHorizontalSmall;
            this.radioButtonDashedHorizontal.Location = new System.Drawing.Point(394, 33);
            this.radioButtonDashedHorizontal.Name = "radioButtonDashedHorizontal";
            this.radioButtonDashedHorizontal.Size = new System.Drawing.Size(57, 28);
            this.radioButtonDashedHorizontal.TabIndex = 6;
            this.radioButtonDashedHorizontal.TabStop = true;
            this.radioButtonDashedHorizontal.UseVisualStyleBackColor = true;
            this.radioButtonDashedHorizontal.CheckedChanged += new System.EventHandler(this.radioButtonDashedHorizontal_CheckedChanged);
            // 
            // radioButtonDashedDownwardDiagonal
            // 
            this.radioButtonDashedDownwardDiagonal.Image = global::KidSparkPainting.Properties.Resources.DashedDownwardDiagonalSmall;
            this.radioButtonDashedDownwardDiagonal.Location = new System.Drawing.Point(331, 33);
            this.radioButtonDashedDownwardDiagonal.Name = "radioButtonDashedDownwardDiagonal";
            this.radioButtonDashedDownwardDiagonal.Size = new System.Drawing.Size(57, 28);
            this.radioButtonDashedDownwardDiagonal.TabIndex = 5;
            this.radioButtonDashedDownwardDiagonal.TabStop = true;
            this.radioButtonDashedDownwardDiagonal.UseVisualStyleBackColor = true;
            this.radioButtonDashedDownwardDiagonal.CheckedChanged += new System.EventHandler(this.radioButtonDashedDownwardDiagonal_CheckedChanged);
            // 
            // radioButtonDarkVertical
            // 
            this.radioButtonDarkVertical.Image = global::KidSparkPainting.Properties.Resources.DarkVerticalSmall;
            this.radioButtonDarkVertical.Location = new System.Drawing.Point(268, 33);
            this.radioButtonDarkVertical.Name = "radioButtonDarkVertical";
            this.radioButtonDarkVertical.Size = new System.Drawing.Size(57, 28);
            this.radioButtonDarkVertical.TabIndex = 4;
            this.radioButtonDarkVertical.TabStop = true;
            this.radioButtonDarkVertical.UseVisualStyleBackColor = true;
            this.radioButtonDarkVertical.CheckedChanged += new System.EventHandler(this.radioButtonDarkVertical_CheckedChanged);
            // 
            // radioButtonDarkUpwardDiagonal
            // 
            this.radioButtonDarkUpwardDiagonal.Image = global::KidSparkPainting.Properties.Resources.DarkUpwardDiagonalSmall;
            this.radioButtonDarkUpwardDiagonal.Location = new System.Drawing.Point(205, 33);
            this.radioButtonDarkUpwardDiagonal.Name = "radioButtonDarkUpwardDiagonal";
            this.radioButtonDarkUpwardDiagonal.Size = new System.Drawing.Size(57, 28);
            this.radioButtonDarkUpwardDiagonal.TabIndex = 3;
            this.radioButtonDarkUpwardDiagonal.TabStop = true;
            this.radioButtonDarkUpwardDiagonal.UseVisualStyleBackColor = true;
            this.radioButtonDarkUpwardDiagonal.CheckedChanged += new System.EventHandler(this.radioButtonDarkUpwardDiagonal_CheckedChanged);
            // 
            // radioButtonDarkHorizontal
            // 
            this.radioButtonDarkHorizontal.Image = global::KidSparkPainting.Properties.Resources.DarkHorizontalSmall;
            this.radioButtonDarkHorizontal.Location = new System.Drawing.Point(142, 33);
            this.radioButtonDarkHorizontal.Name = "radioButtonDarkHorizontal";
            this.radioButtonDarkHorizontal.Size = new System.Drawing.Size(57, 28);
            this.radioButtonDarkHorizontal.TabIndex = 2;
            this.radioButtonDarkHorizontal.TabStop = true;
            this.radioButtonDarkHorizontal.UseVisualStyleBackColor = true;
            this.radioButtonDarkHorizontal.CheckedChanged += new System.EventHandler(this.radioButtonDarkHorizontal_CheckedChanged);
            // 
            // radioButtonDarkDownwardDiagonal
            // 
            this.radioButtonDarkDownwardDiagonal.Image = global::KidSparkPainting.Properties.Resources.DarkDownwardDiagonalSmall;
            this.radioButtonDarkDownwardDiagonal.Location = new System.Drawing.Point(79, 33);
            this.radioButtonDarkDownwardDiagonal.Name = "radioButtonDarkDownwardDiagonal";
            this.radioButtonDarkDownwardDiagonal.Size = new System.Drawing.Size(57, 28);
            this.radioButtonDarkDownwardDiagonal.TabIndex = 1;
            this.radioButtonDarkDownwardDiagonal.TabStop = true;
            this.radioButtonDarkDownwardDiagonal.UseVisualStyleBackColor = true;
            this.radioButtonDarkDownwardDiagonal.CheckedChanged += new System.EventHandler(this.radioButtonDarkDownwardDiagonal_CheckedChanged);
            // 
            // radioButtonBackwardDiagonal
            // 
            this.radioButtonBackwardDiagonal.Image = global::KidSparkPainting.Properties.Resources.BackwardDiagonalSmall;
            this.radioButtonBackwardDiagonal.Location = new System.Drawing.Point(16, 33);
            this.radioButtonBackwardDiagonal.Name = "radioButtonBackwardDiagonal";
            this.radioButtonBackwardDiagonal.Size = new System.Drawing.Size(57, 28);
            this.radioButtonBackwardDiagonal.TabIndex = 0;
            this.radioButtonBackwardDiagonal.TabStop = true;
            this.radioButtonBackwardDiagonal.UseVisualStyleBackColor = true;
            this.radioButtonBackwardDiagonal.CheckedChanged += new System.EventHandler(this.radioButtonBackwardDiagonal_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.pictureBoxPreview);
            this.groupBox2.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(801, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(165, 114);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Preview";
            // 
            // pictureBoxPreview
            // 
            this.pictureBoxPreview.Image = global::KidSparkPainting.Properties.Resources.BackwardDiagonal;
            this.pictureBoxPreview.Location = new System.Drawing.Point(25, 44);
            this.pictureBoxPreview.Name = "pictureBoxPreview";
            this.pictureBoxPreview.Size = new System.Drawing.Size(119, 39);
            this.pictureBoxPreview.TabIndex = 0;
            this.pictureBoxPreview.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.LabelName);
            this.groupBox3.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold);
            this.groupBox3.Location = new System.Drawing.Point(801, 133);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(165, 114);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Name";
            // 
            // LabelName
            // 
            this.LabelName.AutoSize = true;
            this.LabelName.Font = new System.Drawing.Font("Comic Sans MS", 10.5F, System.Drawing.FontStyle.Bold);
            this.LabelName.ForeColor = System.Drawing.Color.Green;
            this.LabelName.Location = new System.Drawing.Point(15, 51);
            this.LabelName.Name = "LabelName";
            this.LabelName.Size = new System.Drawing.Size(129, 19);
            this.LabelName.TabIndex = 0;
            this.LabelName.Text = "BackwardDiagonal";
            // 
            // ButtonCancel
            // 
            this.ButtonCancel.BackColor = System.Drawing.Color.Transparent;
            this.ButtonCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonCancel.Image = global::KidSparkPainting.Properties.Resources.Cancel;
            this.ButtonCancel.Location = new System.Drawing.Point(904, 254);
            this.ButtonCancel.Name = "ButtonCancel";
            this.ButtonCancel.Size = new System.Drawing.Size(57, 45);
            this.ButtonCancel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ButtonCancel.TabIndex = 6;
            this.ButtonCancel.TabStop = false;
            this.ButtonCancel.Click += new System.EventHandler(this.ButtonCancel_Click);
            // 
            // ButtonOk
            // 
            this.ButtonOk.BackColor = System.Drawing.Color.Transparent;
            this.ButtonOk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonOk.Image = global::KidSparkPainting.Properties.Resources.OK;
            this.ButtonOk.Location = new System.Drawing.Point(820, 254);
            this.ButtonOk.Name = "ButtonOk";
            this.ButtonOk.Size = new System.Drawing.Size(57, 45);
            this.ButtonOk.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ButtonOk.TabIndex = 5;
            this.ButtonOk.TabStop = false;
            this.ButtonOk.Click += new System.EventHandler(this.ButtonOk_Click);
            // 
            // MoreTexturePen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.BackgroundImage = global::KidSparkPainting.Properties.Resources.Background1;
            this.ClientSize = new System.Drawing.Size(973, 310);
            this.Controls.Add(this.ButtonCancel);
            this.Controls.Add(this.ButtonOk);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MoreTexturePen";
            this.Text = "MoreTexturePen";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPreview)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonCancel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonOk)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox pictureBoxPreview;
        private System.Windows.Forms.RadioButton radioButtonBackwardDiagonal;
        private System.Windows.Forms.RadioButton radioButtonDarkDownwardDiagonal;
        private System.Windows.Forms.RadioButton radioButtonDivot;
        private System.Windows.Forms.RadioButton radioButtonDiagonalCross;
        private System.Windows.Forms.RadioButton radioButtonDiagonalBrick;
        private System.Windows.Forms.RadioButton radioButtonDashedVertical;
        private System.Windows.Forms.RadioButton radioButtonDashedUpwardDiagonal;
        private System.Windows.Forms.RadioButton radioButtonDashedHorizontal;
        private System.Windows.Forms.RadioButton radioButtonDashedDownwardDiagonal;
        private System.Windows.Forms.RadioButton radioButtonDarkVertical;
        private System.Windows.Forms.RadioButton radioButtonDarkUpwardDiagonal;
        private System.Windows.Forms.RadioButton radioButtonDarkHorizontal;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label LabelName;
        private System.Windows.Forms.RadioButton radioButtonPercent80;
        private System.Windows.Forms.RadioButton radioButtonNarrowVertical;
        private System.Windows.Forms.RadioButton radioButtonDottedDiamond;
        private System.Windows.Forms.RadioButton radioButtonSmallGrid;
        private System.Windows.Forms.RadioButton radioButtonSmallConfetti;
        private System.Windows.Forms.RadioButton radioButtonSmallCheckerBoard;
        private System.Windows.Forms.RadioButton radioButtonShingle;
        private System.Windows.Forms.RadioButton radioButtonPlaid;
        private System.Windows.Forms.RadioButton radioButtonPercent90;
        private System.Windows.Forms.RadioButton radioButtonPercent75;
        private System.Windows.Forms.RadioButton radioButtonPercent70;
        private System.Windows.Forms.RadioButton radioButtonPercent60;
        private System.Windows.Forms.RadioButton radioButtonPercent50;
        private System.Windows.Forms.RadioButton radioButtonPercent40;
        private System.Windows.Forms.RadioButton radioButtonPercent30;
        private System.Windows.Forms.RadioButton radioButtonPercent25;
        private System.Windows.Forms.RadioButton radioButtonPercent20;
        private System.Windows.Forms.RadioButton radioButtonPercent10;
        private System.Windows.Forms.RadioButton radioButtonPercent05;
        private System.Windows.Forms.RadioButton radioButtonOutlinedDiamond;
        private System.Windows.Forms.RadioButton radioButtonNarrowHorizontal;
        private System.Windows.Forms.RadioButton radioButtonLightVertical;
        private System.Windows.Forms.RadioButton radioButtonLightHorizontal;
        private System.Windows.Forms.RadioButton radioButtonLightDownwardDiagonal;
        private System.Windows.Forms.RadioButton radioButtonLargeGrid;
        private System.Windows.Forms.RadioButton radioButtonLargeConfetti;
        private System.Windows.Forms.RadioButton radioButtonLargeCheckerBoard;
        private System.Windows.Forms.RadioButton radioButtonHorizontalBrick;
        private System.Windows.Forms.RadioButton radioButtonHorizontal;
        private System.Windows.Forms.RadioButton radioButtonForwardDiagonal;
        private System.Windows.Forms.RadioButton radioButtonDottedGrid;
        private System.Windows.Forms.RadioButton radioButtonWave;
        private System.Windows.Forms.RadioButton radioButtonVertical;
        private System.Windows.Forms.RadioButton radioButtonTrellis;
        private System.Windows.Forms.RadioButton radioButtonSphere;
        private System.Windows.Forms.RadioButton radioButtonSolidDiamond;
        private System.Windows.Forms.RadioButton radioButtonZipZag;
        private System.Windows.Forms.RadioButton radioButtonWideUpwardDiagonal;
        private System.Windows.Forms.RadioButton radioButtonWideDownwardDiagonal;
        private System.Windows.Forms.RadioButton radioButtonWeave;
        private System.Windows.Forms.PictureBox ButtonOk;
        private System.Windows.Forms.PictureBox ButtonCancel;
    }
}