﻿namespace KidSparkPainting
{
    partial class MediaPlayer
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MediaPlayer));
            this.panelMain = new System.Windows.Forms.Panel();
            this.panelOperate = new System.Windows.Forms.Panel();
            this.exit = new System.Windows.Forms.PictureBox();
            this.HidePanel = new System.Windows.Forms.PictureBox();
            this.downvoice = new System.Windows.Forms.PictureBox();
            this.risingvoice = new System.Windows.Forms.PictureBox();
            this.mute = new System.Windows.Forms.PictureBox();
            this.stop = new System.Windows.Forms.PictureBox();
            this.play = new System.Windows.Forms.PictureBox();
            this.axWmp = new AxWMPLib.AxWindowsMediaPlayer();
            this.timerMediaPlayer = new System.Windows.Forms.Timer(this.components);
            this.panelMain.SuspendLayout();
            this.panelOperate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.exit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HidePanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.downvoice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.risingvoice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mute)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.play)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axWmp)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMain
            // 
            this.panelMain.BackColor = System.Drawing.Color.Transparent;
            this.panelMain.Controls.Add(this.panelOperate);
            this.panelMain.Controls.Add(this.axWmp);
            this.panelMain.Location = new System.Drawing.Point(10, 10);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(402, 318);
            this.panelMain.TabIndex = 0;
            // 
            // panelOperate
            // 
            this.panelOperate.BackColor = System.Drawing.Color.Transparent;
            this.panelOperate.Controls.Add(this.exit);
            this.panelOperate.Controls.Add(this.HidePanel);
            this.panelOperate.Controls.Add(this.downvoice);
            this.panelOperate.Controls.Add(this.risingvoice);
            this.panelOperate.Controls.Add(this.mute);
            this.panelOperate.Controls.Add(this.stop);
            this.panelOperate.Controls.Add(this.play);
            this.panelOperate.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelOperate.Location = new System.Drawing.Point(0, 287);
            this.panelOperate.Name = "panelOperate";
            this.panelOperate.Size = new System.Drawing.Size(402, 31);
            this.panelOperate.TabIndex = 7;
            // 
            // exit
            // 
            this.exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.exit.Dock = System.Windows.Forms.DockStyle.Right;
            this.exit.Image = global::KidSparkPainting.Properties.Resources.Exit1;
            this.exit.Location = new System.Drawing.Point(346, 0);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(29, 31);
            this.exit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.exit.TabIndex = 7;
            this.exit.TabStop = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // HidePanel
            // 
            this.HidePanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.HidePanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.HidePanel.Image = global::KidSparkPainting.Properties.Resources.HIDETOOLS;
            this.HidePanel.Location = new System.Drawing.Point(375, 0);
            this.HidePanel.Name = "HidePanel";
            this.HidePanel.Size = new System.Drawing.Size(27, 31);
            this.HidePanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.HidePanel.TabIndex = 6;
            this.HidePanel.TabStop = false;
            this.HidePanel.Click += new System.EventHandler(this.HidePanel_Click);
            // 
            // downvoice
            // 
            this.downvoice.Cursor = System.Windows.Forms.Cursors.Hand;
            this.downvoice.Dock = System.Windows.Forms.DockStyle.Left;
            this.downvoice.Image = global::KidSparkPainting.Properties.Resources.VOICEDOWN;
            this.downvoice.Location = new System.Drawing.Point(108, 0);
            this.downvoice.Name = "downvoice";
            this.downvoice.Size = new System.Drawing.Size(22, 31);
            this.downvoice.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.downvoice.TabIndex = 4;
            this.downvoice.TabStop = false;
            this.downvoice.Click += new System.EventHandler(this.downvoice_Click);
            // 
            // risingvoice
            // 
            this.risingvoice.Cursor = System.Windows.Forms.Cursors.Hand;
            this.risingvoice.Dock = System.Windows.Forms.DockStyle.Left;
            this.risingvoice.Image = global::KidSparkPainting.Properties.Resources.VOICEUP;
            this.risingvoice.Location = new System.Drawing.Point(86, 0);
            this.risingvoice.Name = "risingvoice";
            this.risingvoice.Size = new System.Drawing.Size(22, 31);
            this.risingvoice.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.risingvoice.TabIndex = 3;
            this.risingvoice.TabStop = false;
            this.risingvoice.Click += new System.EventHandler(this.risingvoice_Click);
            // 
            // mute
            // 
            this.mute.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mute.Dock = System.Windows.Forms.DockStyle.Left;
            this.mute.Image = global::KidSparkPainting.Properties.Resources.VOICE;
            this.mute.Location = new System.Drawing.Point(58, 0);
            this.mute.Name = "mute";
            this.mute.Size = new System.Drawing.Size(28, 31);
            this.mute.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.mute.TabIndex = 2;
            this.mute.TabStop = false;
            this.mute.Click += new System.EventHandler(this.mute_Click);
            // 
            // stop
            // 
            this.stop.Cursor = System.Windows.Forms.Cursors.Hand;
            this.stop.Dock = System.Windows.Forms.DockStyle.Left;
            this.stop.Image = global::KidSparkPainting.Properties.Resources.STOP;
            this.stop.Location = new System.Drawing.Point(29, 0);
            this.stop.Name = "stop";
            this.stop.Size = new System.Drawing.Size(29, 31);
            this.stop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.stop.TabIndex = 1;
            this.stop.TabStop = false;
            this.stop.Click += new System.EventHandler(this.stop_Click);
            // 
            // play
            // 
            this.play.Cursor = System.Windows.Forms.Cursors.Hand;
            this.play.Dock = System.Windows.Forms.DockStyle.Left;
            this.play.Image = global::KidSparkPainting.Properties.Resources.PLAY;
            this.play.Location = new System.Drawing.Point(0, 0);
            this.play.Name = "play";
            this.play.Size = new System.Drawing.Size(29, 31);
            this.play.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.play.TabIndex = 0;
            this.play.TabStop = false;
            this.play.Click += new System.EventHandler(this.play_Click);
            // 
            // axWmp
            // 
            this.axWmp.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.axWmp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axWmp.Enabled = true;
            this.axWmp.Location = new System.Drawing.Point(0, 0);
            this.axWmp.Name = "axWmp";
            this.axWmp.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWmp.OcxState")));
            this.axWmp.Size = new System.Drawing.Size(402, 318);
            this.axWmp.TabIndex = 6;
            this.axWmp.UseWaitCursor = true;
            this.axWmp.MouseDownEvent += new AxWMPLib._WMPOCXEvents_MouseDownEventHandler(this.axWmp_MouseDownEvent);
            // 
            // MediaPlayer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(127)))), ((int)(((byte)(228)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.panelMain);
            this.Name = "MediaPlayer";
            this.Size = new System.Drawing.Size(422, 338);
            this.panelMain.ResumeLayout(false);
            this.panelOperate.ResumeLayout(false);
            this.panelOperate.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.exit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HidePanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.downvoice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.risingvoice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mute)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.play)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axWmp)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Panel panelOperate;
        private System.Windows.Forms.PictureBox exit;
        private System.Windows.Forms.PictureBox HidePanel;
        private System.Windows.Forms.PictureBox downvoice;
        private System.Windows.Forms.PictureBox risingvoice;
        private System.Windows.Forms.PictureBox mute;
        private System.Windows.Forms.PictureBox stop;
        private System.Windows.Forms.PictureBox play;
        private AxWMPLib.AxWindowsMediaPlayer axWmp;
        private System.Windows.Forms.Timer timerMediaPlayer;

    }
}
