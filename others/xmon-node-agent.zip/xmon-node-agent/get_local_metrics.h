#ifndef GET_LOCAL_METRICS_H_
#define GET_LOCAL_METRICS_H_

#include <iostream>
#include <map>
#include <string>
#include <string.h>
#include <stdint.h>
#include <set>
#include <vector>


using std::string;
using std::map;

class GetLocalMetrics {
    public:
    GetLocalMetrics();
    //net device IO information
    int32_t GetNetDevIn();   //get net device in(byte)
    int32_t GetNetDevOut();  //get net device out(byte)
    int32_t NetDeviceParse(); //parse the net device
    string GetIpAddress(const char* eif);   //get ip address
    int32_t GetNetworkDevicesNum(); //get network devices number


    //process load
    int32_t GetRunningProcess();    //get runing process
    int32_t GetTotalProcess();  //get total process
    int32_t ProcessParse();    //parse the process
    int32_t isNum(std::string str);    //to gudge wheather a string is int(not use yet)
    std::string GetProcessName(std::string PID); //get the name of process(not use yet)
    std::string GetProcessState(std::string PID);//get the state of process(now use yet)


    //cpu load
    double GetOneMCpuLoad();   //get cpu load(1 minutes)
    double GetFiveMCpuLoad();   //get cpu load(5 minutes)
    double GetFifteenMCpuLoad();    //get cpu load (15 minutes)
    int32_t StartParseCpuLoad();    //start to parse cpuload
    int32_t GetCpus();     //get cpu number
    double GetCpuUseage();  //get cpu useage
    double GetCpuFreq();    //get cpu frequency
    const char* GetCpuGlibcVersion();   // get installed glibc's version
    int32_t GetMips();  //get mips number


    

    //memory and swap
    int32_t GetMemoryTotal();  //get total memory
    int32_t GetMemoryUsed();    //get used memory
    int32_t GetMemoryFree();  //get free memory(MB)
    int32_t GetMemoryBuffers(); //
    int32_t GetMemoryCashed();
    int32_t GetMemoryMaped();
    int32_t GetMemoryShared();
    int32_t GetMemoryInCore();
    int32_t GetSwapTotal();
    int32_t GetSwapFree();
    int32_t GetSwapCashed();
    int32_t MemoryParse(); //parse /proc/meminfo to get all metrics


    //system
    char* sysapi_translate_arch(const char *machine);
    char* GetArch();    //get OS's architecture, like x86,x64 .etc
    char* GetSystem();  //get OS's information, like ubuntu, linux, redhat .etc
    const char* Get_Host_Name();    //get host name
    uint64_t GetUpTime(); //get OS up time(seconds)

    //disk
    int32_t sysapi_disk_space(const char * filename);
             
    // Structure for network interfaces statistics
    struct stats_net_dev {
        uint64_t rx_packets;
        uint64_t tx_packets;
        uint64_t rx_bytes;
        uint64_t tx_bytes;
        uint64_t rx_compressed;
        uint64_t tx_compressed;
        uint64_t multicast;
        char     interface[16];

        stats_net_dev() {
            rx_packets = 0;
            tx_packets = 0;
            rx_bytes = 0;
            tx_bytes = 0;
            rx_compressed = 0;
            tx_compressed = 0;
            multicast = 0;
            memset(interface, 0, sizeof(interface));
        }
    };

    //Read network interfaces statistics from /proc/net/dev.
    void read_net_dev(stats_net_dev *st_net_dev,
                      int32_t nbr);

    //get eth0，eth1 flux and packages number
    int32_t get_net_stat(int32_t *eth0_rxpck, int32_t *eth0_txpck,
                 int32_t *eth0_rxbyt, int32_t *eth0_txbyt,
                 int32_t *eth1_rxpck, int32_t *eth1_txpck,
                 int32_t *eth1_rxbyt, int32_t *eth1_txbyt);

    // pid stat
    #define MAX_CMDLINE_LEN 128
    #define MAX_COMM_LEN 128
    struct pid_stats
    {
        uint64_t      data_size;
        uint64_t      stack_size;
        uint64_t      heap_size;
        uint64_t      vsz;
        uint64_t      utime;
        uint64_t      stime;
        char          comm[MAX_COMM_LEN];
        char          cmdline[MAX_CMDLINE_LEN];
        char          state[2];
    };

    private:
    int32_t DevInNow;
    int32_t DevOutNow;
    int32_t DevInPre;
    int32_t DevOutPre;
    
    int32_t RunningProcessNumber;
    int32_t TotalProcessNumber;

    double OneMCpuLoad;
    double FiveMCpuLoad;
    double FifteenMCpuLoad;

    int32_t MemoryTotal;
    int32_t MemoryFree;
    int32_t MemoryBuffers;
    int32_t MemoryCashed;
    int32_t MemoryMaped;
    int32_t MemoryShared;
    int32_t MemoryInCore;
    int32_t SwapTotal;
    int32_t SwapFree;
    int32_t SwapCashed;
};

#endif //GET_LOCAL_METRICS_H_
