/**
 *  Copyright (c) 2011 SIAT, China 
 *  Function: Send metrics to rabbitmq service
 *  Date: 2011.09.10
 *  Auther: Yang Cong
 *  Emain: yangcong955@126.com
**/

#include "get_local_metrics.h"
#include <net/if.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <gnu/libc-version.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <netinet/in.h>
#include <string.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <sys/param.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/statfs.h>
#include <sys/sysinfo.h>
#include <sys/types.h>
#include <sys/utsname.h>
#include <time.h>
#include <unistd.h>
#include <algorithm>
#include <map>
#include <set>
#include <string>
#include <vector>
#include <inttypes.h>
#include <fstream>
#include "system_init.h"

#define BUF_SIZE 4096
#define NET_DEV     "/proc/net/dev"
#define _PATH_PROCNET_TCP   "/proc/net/tcp"
#define _PATH_PROCNET_UDP  "/proc/net/udp"
#define PRIu64 "l" "u"
#define SCNu64 "l" "u"
static char host_name[HOST_NAME_MAX];

GetLocalMetrics::
GetLocalMetrics() {
    DevInPre = 0;
    DevOutPre = 0;
}

/*Part 1**start to get Net Device Information*/

//parse /proc/net/dev to get net device IO
int32_t GetLocalMetrics::
NetDeviceParse() {
    if (DevInPre == 0 || DevOutPre == 0) {
        int32_t myin = 0;
        int32_t myout = 0;
        FILE* fp = fopen("/proc/net/dev", "r");
        char buftemp[256] = {0};

        if (!fp) {
            return 0;
        }
    
        while (fgets(buftemp, sizeof(buftemp)-1, fp)) {
            if (strncmp(buftemp, "  eth0", 6) == 0) {
                sscanf(strchr(buftemp, ':') + 1, 
                "%u%*u%*u%*u%*u%*u%*u%*u%u%[^ ]", &myin, &myout);
            }
        }
        fclose(fp);
        DevInNow = 0;
        DevOutNow = 0;
        DevInPre = myin;
        DevOutPre = myout;
        //DevInNow = 0;
        //DevOutNow = 0;
        //std::cout << DevInNow<<"  "<<DevOutNow << std::endl;
    } else {
        int bytein = 0;
        int byteout = 0;
        FILE* fp = fopen("/proc/net/dev", "r");
        char buf[256] = {0};

        if (!fp) {
            return 0;
        }
    
        while (fgets(buf, sizeof(buf)-1, fp)) {
            if (strncmp(buf, "  eth0", 6) == 0) {
                sscanf(strchr(buf, ':') + 1, 
                "%u%*u%*u%*u%*u%*u%*u%*u%u%[^ ]", &bytein, &byteout);
            }
        }
        fclose(fp);
        //std::cout << bytein << "  " << byteout <<std::endl;
        //std::cout << DevInPre << "  " << DevOutPre << std::endl;
        int32_t sendfrequency = SystemInitialize::GetXMLNodeSendFrequency();
        DevInNow = (bytein - DevInPre)/sendfrequency;
        DevOutNow = (byteout - DevOutPre)/sendfrequency;
        //std::cout << DevInNow << "  " << DevOutNow << std::endl;
        DevInPre = bytein;
        DevOutPre = byteout;
    }

    //std::cout << DevInNow << std::endl;
    //std::cout << DevOutNow << std::endl;
    return 0;
}

int32_t GetLocalMetrics::
GetNetDevIn() {
    return DevInNow;
}

int32_t GetLocalMetrics::
GetNetDevOut() {
    return DevOutNow;
}

/*
 * @brief:select local ip address
 * @return:success:return ip address, else return 0
 */
string GetLocalMetrics::
GetIpAddress(const char* eif) {
    int32_t fd = socket(AF_INET, SOCK_DGRAM, 0);
    string ip = "";
    if (fd >= 0) {
        ifreq ifr;
        ifr.ifr_addr.sa_family = AF_INET;
        strncpy(ifr.ifr_name, eif, sizeof(ifr.ifr_name));

        if (ioctl(fd, SIOCGIFADDR, &ifr) == 0) {
            ip = inet_ntoa(reinterpret_cast<sockaddr_in*>
                           (&ifr.ifr_addr)->sin_addr);
        }
    }
    close(fd);
    return ip;
}


/*
 * @brief: Find number of interfaces (network devices) that are in /proc/net/dev file.
 * @returns: Number of network interfaces.
 */
int32_t GetLocalMetrics::
GetNetworkDevicesNum() {
    FILE *fp;
    char line[128];
    int iface = 0;

    if ((fp = fopen(NET_DEV, "r")) == NULL) {
        return 0;   //No network device file
    }

    while (fgets(line, 128, fp) != NULL) {
        if (strchr(line, ':')) {
            iface++;
        }
    }
    fclose(fp);
    return iface;
}
/*Part 1**get Net Work Device end******/

/**Part 2**get Process Infromation Start***/
//To judge whether a string is number
//used for ProcessParse() (not use yet)
int32_t GetLocalMetrics::
isNum(std::string str) {
    int32_t strlen;
    int32_t result = 0;
    bool isnumber = false;
    std::string num = "1234567890";
    strlen=str.length();
    for (int i=0; i<strlen; i++) {
        for (int t =0; t<num.length();t++) {
            if(str[i]==num[t]) {
                isnumber = true;
                break;
            }
        }
        if (isnumber) {
            result += 0;
        } else {
            result += 1;
        }
    }
    return result;  //if result is 0, it is a number, else, it's not.
}

//get PID'S Name (not use yet)
std::string GetLocalMetrics::
GetProcessName(std::string PID) {
    std::string fullpath = "/proc/" + PID + "/status";
    char* path = new char[fullpath.size()+1];
    strcpy(path,fullpath.c_str());
    std::ifstream fin(path); 
    std::string output;
    std::string processName;
    while( fin >> output && output=="Name:") {
        if(output == "Name:") {
            fin >> output;
            processName = output;
            break;
        }
    }
    return processName;
}

//get PID's status (not use yet)
std::string GetLocalMetrics::
GetProcessState(std::string PID) {
    std::string fullpath = "/proc/" + PID + "/status";
    char* path = new char[fullpath.size()+1];
    strcpy(path,fullpath.c_str());
    std::ifstream fin(path);
    std::string output;
    std::string processStatus;
    while( fin >> output) {
        if (output == "State:") {
            fin >> output;
            processStatus = output;
            break;
        }
    }
    return processStatus;
}

//parse /proc/loadavg to get process information
int32_t GetLocalMetrics::
ProcessParse() {
    int32_t totalprocess, runningprocess;
    FILE* fp = fopen("/proc/loadavg", "r");
    char buf[256] = {0};

    if (!fp) {
        return -1.0;
    }

    fgets(buf, sizeof(buf)-1, fp);
    sscanf(strchr(buf, '/') + 1, "%d", &totalprocess);
    sscanf(buf,"%*lf%*lf%*lf%d%[/]",&runningprocess);
    fclose(fp);
    TotalProcessNumber = totalprocess;
    RunningProcessNumber = runningprocess;
    return 0;
}

//rerurn running process number
int32_t GetLocalMetrics::
GetRunningProcess() { 
    //ProcessParse();
    return RunningProcessNumber;
}

//return total process number
int32_t GetLocalMetrics::
GetTotalProcess() {
    //ProcessParse();
    return TotalProcessNumber;
}
/**Part 2***get Process Information End******/


/**Part 3**Get CPU Information Start****/
/*
 * @brief:get cpu numbers
 * @return:logical cpu numbers
 */
int32_t GetLocalMetrics::GetCpus() {
    int32_t cpu_num = 0;
    FILE *fp = fopen("/proc/cpuinfo", "r");
    if (!fp) {
        return 1;
    }
    char buf[256] = {0};
    //  Look at each line, count line begin with
    while (fgets(buf, sizeof(buf)-1, fp)) {
        if (strncmp(buf, "processor", 9) == 0) {
            cpu_num++;
        }
    }
    /* Done reading; close the file */
    fclose(fp);
    return cpu_num ? cpu_num : 1;
}


/*
 * @brief:get cpu average load (1,5,15)
 * return:success:return cpu load, else return -1.0
*/
int32_t GetLocalMetrics::
StartParseCpuLoad() {
    double short_avg, medium_avg, long_avg;
    FILE* fp = fopen("/proc/loadavg", "r");

    // gather info from /proc/meminfo to get free swap
    if (!fp) {
        return -1.0;
    }

    fscanf(fp, "%lf %lf %lf", &short_avg, &medium_avg, &long_avg);
    fclose(fp);
    OneMCpuLoad = short_avg;
    FiveMCpuLoad = medium_avg;
    FifteenMCpuLoad = long_avg;
    return 0;
}

double GetLocalMetrics::
GetOneMCpuLoad() {
    //StartParseCpuLoad();
    return OneMCpuLoad;
}

double GetLocalMetrics::
GetFiveMCpuLoad() {
    //StartParseCpuLoad();
    return FiveMCpuLoad;
}

double GetLocalMetrics::
GetFifteenMCpuLoad() {
    //StartParseCpuLoad();
    return FifteenMCpuLoad;
}

/*
 * @brief:check cpu frequency
 * @return:cpu frequency, failt: return -1.0
 */
double GetLocalMetrics::
GetCpuFreq() {
    double cpu_req = -1.0;
    int32_t n = 0;

    // gather info from /proc/meminfo to get free swap
    FILE *fp = fopen("/proc/cpuinfo", "r");
    char buf[256] = {0};
    if (!fp) {
        return -1;
    }

    // Look at each line, count line begin with
    while (fgets(buf, sizeof(buf)-1, fp)) {
        double i_freq;
        if (!strncmp(buf, "cpu MHz\t", 8)) {
            sscanf(strchr(buf, ':') + 1, "%lf", &i_freq);

            cpu_req += i_freq;
            n++;
        }
    }

    // Done reading; close the file
    fclose(fp);
    if (n > 0) {
        cpu_req = cpu_req / n;
    }
    return cpu_req;
}


/*
 * @brief:get machine glibc
 * @return:glibc version
 */
const char* GetLocalMetrics::
GetCpuGlibcVersion() {
    return gnu_get_libc_version();
}


/*
 * @brief:获取机器的mips数值
 * @return: the numbers of mips
 */
int32_t GetLocalMetrics::
GetMips() {
    double mips = -1;
    int32_t n = 0;
    // gather info from /proc/cpuinfo to count cpu nums
    FILE *fp = fopen("/proc/cpuinfo", "r");
    char buf[256] = {0};
    if (!fp) {
        return -1;
    }

    /* Look at each line, count line begin with  */
    while (fgets(buf, sizeof(buf)-1, fp)) {
        double i_mips;
        if (strncmp(buf, "bogomips", 8) == 0) {
            sscanf(strchr(buf, ':') + 1, "%lf", &i_mips);
            mips += i_mips;
            n++;
            break;
        }
    }

    /* Done reading; close the file */
    fclose(fp);

    if (n > 0) {
        mips = mips / n;
    }
    return static_cast<int>(mips);
}

/*
 * @brief:get cpu useage
 * return:cpu useage
 */
double GetLocalMetrics::
GetCpuUseage() {
    FILE *fp;
    char line[8192];
    static uint64_t prev_used = 0;
    static uint64_t prev_total = 0;
    static bool first = true;

    if ((fp = fopen("/proc/stat", "r")) == NULL) {
        return -1.0;
    }

    uint64_t cpu_user = 0;
    uint64_t cpu_nice = 0;
    uint64_t cpu_sys = 0;
    uint64_t cpu_idle = 0;
    uint64_t cpu_iowait = 0;
    uint64_t cpu_hardirq = 0;
    uint64_t cpu_softirq = 0;
    uint64_t used = 0;
    uint64_t total = 0;
    while (fgets(line, 8192, fp) != NULL) {
        if (!strncmp(line, "cpu ", 4)) {
            sscanf(line + 5, "%" SCNu64 "%" SCNu64 "%" SCNu64 "%" SCNu64
                   "%" SCNu64 "%" SCNu64 "%" SCNu64,
                   &cpu_user, &cpu_nice, &cpu_sys, &cpu_idle,
                   &cpu_iowait, &cpu_hardirq, &cpu_softirq);
            used = cpu_user + cpu_nice + cpu_sys +
                   cpu_iowait + cpu_hardirq + cpu_softirq;
            total = used + cpu_idle;
            break;
        }
    }

    if (first) {
        first = false;
        prev_used = used;
        prev_total = total;
        fclose(fp);
        return 0.0;
    }
    // 回避除以0的问题
    if (total == prev_total) {
        total = prev_total + 1;
    }
    double cpu_usage = static_cast<double>(used - prev_used) /
                       static_cast<double>(total - prev_total);
    prev_used = used;
    prev_total = total;
    fclose(fp);
    return cpu_usage;
}

/**Part 3**Get CPU Information End******/


/**Part 4**Get Memory and Swap Information Start*/

//parse /proc/meminfo to get all metrics
int32_t GetLocalMetrics::
MemoryParse() {
    int32_t memorytotal, memoryfree, memorybuffers, 
            memorycashed, memorymaped, memoryshared, 
            memoryincore, swaptotal, swapfree, swapcashed;
    FILE* fp = fopen("/proc/meminfo", "r");
    char buf[1024] = {0};
    
    if (!fp) {
        return -1.0;
    }
    
    while (fgets(buf, sizeof(buf)-1, fp)) {
        if (strncmp(buf, "MemTotal", 8) == 0) {
            sscanf(strchr(buf, ':') + 1, "%u%[^ ]", &memorytotal);
        }
        if (strncmp(buf, "MemFree", 7) == 0) {
            sscanf(strchr(buf, ':') + 1, "%u%[^ ]", &memoryfree);
        }
        if (strncmp(buf, "Buffers", 7) == 0) {
            sscanf(strchr(buf, ':') + 1, "%u%[^ ]", &memorybuffers);
        }
        if (strncmp(buf, "Cached", 6) == 0) {
            sscanf(strchr(buf, ':') + 1, "%u%[^ ]", &memorycashed);
        }
        if (strncmp(buf, "Mapped", 6) == 0) {
            sscanf(strchr(buf, ':') + 1, "%u%[^ ]", &memorymaped);
        }
        if (strncmp(buf, "Shmem", 5) == 0) {
            sscanf(strchr(buf, ':') + 1, "%u%[^ ]", &memoryshared);
        }
        if (strncmp(buf, "KernelStack", 11) == 0) {
            sscanf(strchr(buf, ':') + 1, "%u%[^ ]", &memoryincore);
        }
        if (strncmp(buf, "SwapTotal", 9) == 0) {
            sscanf(strchr(buf, ':') + 1, "%u%[^ ]", &swaptotal);
        }
        if (strncmp(buf, "SwapFree", 8) == 0) {
            sscanf(strchr(buf, ':') + 1, "%u%[^ ]", &swapfree);
        }
        if (strncmp(buf, "SwapCached", 10) == 0) {
            sscanf(strchr(buf, ':') + 1, "%u%[^ ]", &swapcashed);
        }
    }
    fclose(fp);
    //std::cout << memorytotal << std::endl;
    MemoryTotal = memorytotal;
    MemoryFree = memoryfree;
    MemoryBuffers = memorybuffers;
    MemoryCashed = memorycashed;
    MemoryMaped = memorymaped;
    MemoryShared = memoryshared;
    MemoryInCore = memoryincore;
    SwapTotal = swaptotal;
    SwapFree = swapfree;
    SwapCashed = swapcashed;
    return 0;
}

//get memory total
int32_t GetLocalMetrics::
GetMemoryTotal() {
    return MemoryTotal;
}

//get memory used
int32_t GetLocalMetrics::
GetMemoryUsed() {
    return MemoryTotal - MemoryFree;
}

//get memory free
int32_t GetLocalMetrics::
GetMemoryFree() {
    return MemoryFree;
}

//get memory buffers
int32_t GetLocalMetrics::
GetMemoryBuffers() {
    return MemoryBuffers;
}

//get memory cashed
int32_t GetLocalMetrics::
GetMemoryCashed() {
    return MemoryCashed;
}

//get memory maped
int32_t GetLocalMetrics::
GetMemoryMaped() {
    return MemoryMaped;
}

//get memory shared
int32_t GetLocalMetrics::
GetMemoryShared() {
    return MemoryShared;
}

//get memory in core
int32_t GetLocalMetrics::
GetMemoryInCore() {
    return MemoryInCore;
}

//get swap total
int32_t GetLocalMetrics::
GetSwapTotal() {
    return SwapTotal;
}

//get swap free
int32_t GetLocalMetrics::
GetSwapFree() {
    return SwapFree;
}

//get swap cashed
int32_t GetLocalMetrics::
GetSwapCashed() {
    return SwapCashed;
}

/**Part 4**Get Memory and Swap Information End*****/


/**Part 5**Get System Information Start**/
//function not know
char* GetLocalMetrics::
sysapi_translate_arch(const char *machine) {
    char tmp[64];
    char *tmparch;
    if (!strcmp(machine, "alpha")) {
        snprintf(tmp, sizeof(tmp), "ALPHA");
    } else if (!strcmp(machine, "i86pc")) {
        snprintf(tmp, sizeof(tmp), "INTEL");
    } else if (!strcmp(machine, "i686")) {
        snprintf(tmp, sizeof(tmp), "INTEL");
    } else if (!strcmp(machine, "i586")) {
        snprintf(tmp, sizeof(tmp), "INTEL");
    } else if (!strcmp(machine, "i486")) {
        snprintf(tmp, sizeof(tmp), "INTEL");
    } else if (!strcmp(machine, "i386")) {
        snprintf(tmp, sizeof(tmp), "INTEL");
    } else if (!strcmp(machine, "ia64")) {
        snprintf(tmp, sizeof(tmp), "IA64");
    } else if (!strcmp(machine, "x86_64")) {
        snprintf(tmp, sizeof(tmp), "X86_64");
    } else if (!strcmp(machine, "amd64")) {
        snprintf(tmp, sizeof(tmp), "X86_64");
    } else if (!strcmp(machine, "sun4u")) {
        snprintf(tmp, sizeof(tmp), "SUN4u");
    } else if (!strcmp(machine, "sun4m")) {
        snprintf(tmp, sizeof(tmp), "SUN4x");
    } else if (!strcmp(machine, "sun4c")) {
        snprintf(tmp, sizeof(tmp), "SUN4x");
    } else if (!strcmp(machine, "sparc")) {  // LDAP entry
        snprintf(tmp, sizeof(tmp), "SUN4x");
    } else if (!strcmp(machine, "Power Macintosh")) {  // LDAP entry
        snprintf(tmp, sizeof(tmp), "PPC");
    } else if (!strcmp(machine, "ppc")) {
        snprintf(tmp, sizeof(tmp), "PPC");
    } else if (!strcmp(machine, "ppc32")) {
        snprintf(tmp, sizeof(tmp), "PPC");
    } else if (!strcmp(machine, "ppc64")) {
        snprintf(tmp, sizeof(tmp), "PPC64");
    } else {
        // Unknown, just use what uname gave:
        snprintf(tmp, sizeof(tmp), "%s", machine);
    }
    tmparch = strdup(tmp);
    return tmparch;
}

/*
 * @brief: get system architecture (uname -m)
 * return: success,return architecture else , null
 * free the point
*/
char* GetLocalMetrics::
GetArch() {
    utsname buf;
    if (-1 == uname(&buf))
        return NULL;
    char *arch_name = new char[256];
    strncpy(arch_name, buf.machine, strlen(buf.machine)+1);

    char* name = sysapi_translate_arch(arch_name);
    delete[] arch_name;
    return name;
}

/*
 * @brief: return OS type (uname -o)
*/
char* GetLocalMetrics::
GetSystem() {
    utsname buf;
    if (-1 == uname(&buf)) {
        return NULL;
    }
    const size_t name_len = 256;
    char *os_name = new char[name_len];
    snprintf(os_name, name_len, "%s %s", 
            buf.sysname, buf.release);
    return os_name;
}


/*
 * @brief:check host name (uname -n)
 * return:success:hostname, failt:null
 */
const char* GetLocalMetrics::
Get_Host_Name() {
    gethostname(host_name, HOST_NAME_MAX);
    struct utsname buf;
    if (-1 == uname(&buf))
        return NULL;
    strncpy(host_name, buf.nodename, 
            sizeof(host_name));
    return host_name;
}


/*
 * @brief: return system time(S)
 * @return:system time
 */
uint64_t GetLocalMetrics::
GetUpTime() {
    uint64_t kHZ = sysconf(_SC_CLK_TCK);
    FILE *fp;
    char line[128];
    uint64_t up_sec, up_cent;

    if ((fp = fopen("/proc/uptime", "r")) == NULL)
        return -1;

    if (fgets(line, 128, fp) == NULL) {
        fclose(fp);
        return -1;
    }

    sscanf(line, "%" SCNu64 ".%" SCNu64, &up_sec, &up_cent);

    fclose(fp);

    return up_sec * kHZ + up_cent * kHZ / 100;
}

/**Part 5**Get System Information End**/


/**Part 6**Get Dist Information Start*/
/*
 * @brief:get disk parthen(MB)
 * return:success disk size; failt:-1;
 */
int32_t GetLocalMetrics::
sysapi_disk_space(const char * filename) {
    struct statfs statfsbuf;
    float free_kbytes;
    float kbytes_per_block;

    if (statfs(filename, &statfsbuf) < 0) {
        return -1;
    }

    /* Convert to kbyte blocks: available blks * blksize / 1k bytes. */
    kbytes_per_block = static_cast<uint64_t>
        (statfsbuf.f_bsize) / (1024.0*1024.0);
    free_kbytes = static_cast<float>(statfsbuf.f_bavail) *
                  static_cast<float>(kbytes_per_block);
    return static_cast<int32_t>(free_kbytes);
}

/**Part 6**Get Dist Information End**/
