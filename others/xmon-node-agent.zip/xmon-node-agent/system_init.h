#ifndef SYSTEM_INIT_H_ 
#define SYSTEM_INIT_H_

#include <string>

class SystemInitialize
{
    public:
        static std::string GetXMLRabbitMQIp();
        static int32_t GetXMLRabbitMQPort();
        static int32_t GetXMLNodeSendFrequency();
};

#endif //SYSTEM_INIT_H_
