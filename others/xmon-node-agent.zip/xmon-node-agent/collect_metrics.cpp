#include "collect_metrics.h"
#include <string>
#include <sstream>
#include <ctime>
#include "system_init.h"

//main function to send all metrics
int32_t amqp_sendstring(
            const std::string& para_hostname, 
			int32_t para_port, 
			const std::string& para_exchange, 
			const std::string& para_routingkey, 
			const std::string& para_messagebody) ;

//to replact all whitespace into '_'
std::string replaceWhitespaceInString(
        std::string para_s) {
    std::stringstream ss_buffer;
    std::string mystring;
    const char * ca_temp = para_s.c_str();
    for (int i=0; i < para_s.size(); i++) {
        if (ca_temp[i] == ' ' ) {
            ss_buffer<<'_';
        } else {
            ss_buffer<<ca_temp[i];
        }
    }
    mystring = ss_buffer.str();
    ss_buffer.str("");
    return mystring;
}


string CollectMetrics::GetMachineID() {
  return m_machparameter.GetIpAddress("eth0");
}


void CollectMetrics::Run(int32_t para_t) {
    const int32_t Timestep = para_t;
    LocateReportServer();
    while (true) {
        sleep(Timestep);
        GetMetrics(); 
        PublishMetrics(); 
    }
}

void CollectMetrics::GetMetrics() {
    //init metrics
    m_machparameter.NetDeviceParse();
    m_machparameter.ProcessParse();
    m_machparameter.StartParseCpuLoad();
    m_machparameter.MemoryParse();

    //std::cout << m_machparameter.GetNetDevIn() << std::endl;
    //std::cout << m_machparameter.GetNetDevOut() << std::endl;

    //start to collect metrics
    m_ss_buffers[0] <<" NetworkDevicesNum "<< m_machparameter.GetNetworkDevicesNum();
    m_ss_buffers[1] <<" NetworkDevicesIn "<< m_machparameter.GetNetDevIn();
    m_ss_buffers[2] <<" NetworkDevicesOut "<< m_machparameter.GetNetDevOut();
    m_ss_buffers[3] <<" IpAddress "<< m_machparameter.GetIpAddress("eth0");

    m_ss_buffers[4] <<" RunningProcess "<< m_machparameter.GetRunningProcess();
    m_ss_buffers[5] <<" TotalProcess "<< m_machparameter.GetTotalProcess();

    m_ss_buffers[6] <<" Cpus "<< m_machparameter.GetCpus();
    m_ss_buffers[7] <<" OneMCpuLoad " <<m_machparameter.GetOneMCpuLoad() * 100;
    m_ss_buffers[8] <<" FiveMCpuLoad " <<m_machparameter.GetFiveMCpuLoad() * 100;
    m_ss_buffers[9] <<" FifteenMCpuLoad " <<m_machparameter.GetFifteenMCpuLoad() * 100;
    m_ss_buffers[10] <<" CpuFreq "<< m_machparameter.GetCpuFreq() ;
    m_ss_buffers[11] <<" CpuGlibcVersion "<< m_machparameter.GetCpuGlibcVersion() ;
    m_ss_buffers[12] <<" Mips "<<m_machparameter.GetMips() ;
    m_ss_buffers[13] <<" CpuUsage "<< m_machparameter.GetCpuUseage() ;

    m_ss_buffers[14] <<" TotalMemory " << m_machparameter.GetMemoryTotal();
    m_ss_buffers[15] <<" UsedMemory " << m_machparameter.GetMemoryUsed();
    m_ss_buffers[16] <<" FreeMemory " << m_machparameter.GetMemoryFree();
    m_ss_buffers[17] <<" BufferMemory " << m_machparameter.GetMemoryBuffers();
    m_ss_buffers[18] <<" CashedMemory " << m_machparameter.GetMemoryCashed();
    m_ss_buffers[19] <<" MapedMemory " << m_machparameter.GetMemoryMaped();
    m_ss_buffers[20] <<" SharedMemory " << m_machparameter.GetMemoryShared();
    m_ss_buffers[21] <<" InCoreMemory " << m_machparameter.GetMemoryInCore();
    m_ss_buffers[22] <<" TotalSwap " << m_machparameter.GetSwapTotal();
    m_ss_buffers[23] <<" FreeSwap " << m_machparameter.GetSwapFree();
    m_ss_buffers[24] <<" CashedSwap "<< m_machparameter.GetSwapCashed();
 
    m_ss_buffers[25] <<" Arch " << replaceWhitespaceInString(m_machparameter.GetArch()) ;
    m_ss_buffers[26] <<" System "<< replaceWhitespaceInString(m_machparameter.GetSystem()) ;    
    m_ss_buffers[27] <<" HostName "<< m_machparameter.Get_Host_Name() ;
    m_ss_buffers[28] <<" UpTime "<< m_machparameter.GetUpTime() ;
  
    m_metricslist.clear();
    for ( int i=0; i<m_numberOfMetrics; i++) {
        m_metricslist.push_back(m_ss_buffers[i].str());
        m_ss_buffers[i].str(""); //everytime to use stringstream, make sure to clean it
    }
}

void CollectMetrics::LocateReportServer() {
    m_hostname = SystemInitialize::GetXMLRabbitMQIp();
    m_port = SystemInitialize::GetXMLRabbitMQPort();
    //m_hostname = "ccrfox10";
    //m_port = 5672;
}

std::string CollectMetrics::
MessageAssembler() {
    std::stringstream ss_buffer;
    std::string metricstring;
    ss_buffer<<" numberOfMetrics ";
    ss_buffer<<m_numberOfMetrics;
    ss_buffer<<" time ";

    time_t now = time(NULL);
    std::string s_temp (ctime(&now));
    const char* ca_temp = s_temp.c_str();
    for (int i=0; i < s_temp.size()-1; i++) {
        if (ca_temp[i] == ' ') {
            ss_buffer<<'_';
        } else {
            ss_buffer<<ca_temp[i];
        }
    }
    ss_buffer<<" mark "<<GetMachineID()<<" ";

    for (int i=0 ; i<m_numberOfMetrics; ++i) {
        ss_buffer<<m_metricslist[i]<<" ";
    }
    metricstring = ss_buffer.str();
    ss_buffer.str("");  //clean the stringstream
    return metricstring;
}

//push metrics to rabbitmq service
void CollectMetrics::PublishMetrics() {
    string messageString = MessageAssembler();
    //try {
        amqp_sendstring(m_hostname, m_port, 
                "Metrics", "Metrics", messageString);
   // } catch (...) {
     //   std::cout << "NodeAgent can't connect to rabbitmq service" << std::endl;
       // return;
   // }
    std::cout<<messageString<<std::endl;
}

