#include "collect_metrics.h"
#include "system_init.h"
int main(int argc, char** argv) {
    CollectMetrics agent;
    agent.Run(SystemInitialize::GetXMLNodeSendFrequency());
    return 0;
}
