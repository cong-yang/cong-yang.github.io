#ifndef __HEADER_COLLECTORAGENT
#define __HEADER_COLLECTORAGENT

#include "get_local_metrics.h"
#include <string>
#include <vector>
#include <sstream>

class CollectMetrics {
 public:
  void Run(int32_t);

 private:
  std::string m_hostname;
  int32_t m_port;

  const static int32_t m_numberOfMetrics = 29;
  std::stringstream m_ss_buffers[m_numberOfMetrics];

  std::vector<std::string> m_metricslist;
  GetLocalMetrics m_machparameter;
 
  void LocateReportServer();
  std::string GetMachineID();
  void GetMetrics();
  std::string MessageAssembler();
  void PublishMetrics();
};


#endif
