#include "system_init.h"
#include <cstdlib>
#include <iostream>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/xml_parser.hpp>
#include <boost/typeof/typeof.hpp>

using namespace boost::property_tree;

//get rabbitmq service ip address
//from XMonitor.xml
std::string SystemInitialize::
GetXMLRabbitMQIp()
{
    std::string rabbitmqip;
    ptree pt;
    read_xml("XMonitor.xml", pt);
    rabbitmqip = pt.get<std::string>("XMonitor.rabbitMQService.RabbitMQServiceIP");
    return rabbitmqip;
}

//get rabbitmq service port
//from XMonitor.xml
int32_t SystemInitialize::
GetXMLRabbitMQPort()
{
    int32_t rabbitmqport;
    ptree pt;
    read_xml("XMonitor.xml", pt);
    rabbitmqport =  pt.get<int32_t>("XMonitor.rabbitMQService.RabbitMQServicePort");
    return rabbitmqport;
}

//get node send metrics frequency
//from xmonitor.xml
int32_t SystemInitialize::
GetXMLNodeSendFrequency()
{
    int32_t sendfrequency;
    ptree pt;
    read_xml("XMonitor.xml", pt);
    sendfrequency = pt.get<int32_t>("XMonitor.NodeAgent.SendMetricsFrequency"); 
    return sendfrequency;
}
