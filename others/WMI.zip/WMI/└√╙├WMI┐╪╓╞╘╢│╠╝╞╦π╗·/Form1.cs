﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Management;
//WMI操作类位于的命名空间

namespace 利用WMI控制远程计算机
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //确定WMI操作的范围
            ConnectionOptions options = new ConnectionOptions();
            //设定用于WMI连接操作的用户名
            options.Username = textBox2.Text;
            //设定用户的口令
            options.Password = textBox3.Text;
            try
            {
                ManagementScope Conn = new ManagementScope("\\\\" + textBox1.Text + "\\root\\cimv2", options);
                Conn.Connect();
                //确定WMI操作的内容
                ObjectQuery oq = new ObjectQuery("SELECT * FROM Win32_OperatingSystem");
                ManagementObjectSearcher query1 = new ManagementObjectSearcher(Conn, oq);
                //获取WMI操作内容
                ManagementObjectCollection queryCollection1 = query1.Get();
                //根据使用者选择，执行相应的远程操作
                foreach (ManagementObject mo in queryCollection1)
                {
                    string[] ss = { "" };
                    //执行重启操作
                    if (comboBox1.Text == "重新启动")
                    {
                        mo.InvokeMethod("Reboot", ss);
                    }
                    else
                        //执行远程关机
                        if (comboBox1.Text == "远程关机")
                        {
                            mo.InvokeMethod("Shutdown", ss);
                        }
                        else
                            MessageBox.Show("选择不正确的操作！", "错误！");
                }
            }
            //报错
            catch (Exception ee)
            {
                MessageBox.Show("连接" + textBox1.Text + "出错，出错信息为：" + ee.Message);
            }
        }
    }
}
