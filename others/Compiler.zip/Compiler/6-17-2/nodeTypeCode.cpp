// nodeTypeCode.cpp: implementation of the nodeTypeCode class.
//
//////////////////////////////////////////////////////////////////////

#include "nodeTypeCode.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

nodeTypeCode::nodeTypeCode()
{

}

int const nodeTypeCode::DEC_LIST = 1;
int const nodeTypeCode::DEC_VAR = 2;
int const nodeTypeCode::DEC_ARRAY = 3;
int const nodeTypeCode::DEC_PROC = 4;
int const nodeTypeCode::DEC_PARAM = 5;
int const nodeTypeCode::DEC_LOCAL = 6;
int const nodeTypeCode::STMT_COM = 7;
int const nodeTypeCode::STMT_EXP = 8;
int const nodeTypeCode::STMT_IF = 9;
int const nodeTypeCode::STMT_RETURN = 10;
int const nodeTypeCode::STMT_WHILE = 11;
int const nodeTypeCode::STMT_LIST = 12;
int const nodeTypeCode::STMT = 13;
int const nodeTypeCode::EXP_VAR = 14;
int const nodeTypeCode::EXP_NUM = 15;
int const nodeTypeCode::EXP_ARRAY = 16;
int const nodeTypeCode::EXP_ASSIGN = 17;
int const nodeTypeCode::EXP_CALL = 18;
int const nodeTypeCode::EXP_OP = 19;

int const nodeTypeCode::END = 22;

nodeTypeCode::~nodeTypeCode()
{

}
