// basicTypeInt1.h: interface for the basicTypeInt class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BASICTYPEINT1_H__F7D2D879_7C73_4E77_916D_05DB4F6C9FBB__INCLUDED_)
#define AFX_BASICTYPEINT1_H__F7D2D879_7C73_4E77_916D_05DB4F6C9FBB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class basicTypeInt  
{
public:
	static 
	basicTypeInt();
	virtual ~basicTypeInt();

};

#endif // !defined(AFX_BASICTYPEINT1_H__F7D2D879_7C73_4E77_916D_05DB4F6C9FBB__INCLUDED_)
