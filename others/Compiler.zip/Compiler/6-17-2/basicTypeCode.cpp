// basicTypeCode.cpp: implementation of the basicTypeCode class.
//
//////////////////////////////////////////////////////////////////////

#include "basicTypeCode.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

basicTypeCode::basicTypeCode()
{

}

int basicTypeCode::BOOLEAN	= 1;
int basicTypeCode::DOUBLE	= 2;
int basicTypeCode::FLOAT	= 3;
int basicTypeCode::INT		= 4;
int basicTypeCode::VOID		= 5;

int basicTypeCode::BOOLEAN_SIZE	= 1;
int basicTypeCode::DOUBLE_SIZE	= 16;
int basicTypeCode::FLOAT_SIZE	= 8;
int basicTypeCode::INT_SIZE		= 1;	//��TM������У�int��ռ1���ֽڣ�
int basicTypeCode::VOID_SIZE	= 0;


basicTypeCode::~basicTypeCode()
{

}
