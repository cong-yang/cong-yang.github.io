// basicType1.cpp: implementation of the basicType class.
//
//////////////////////////////////////////////////////////////////////

#include "basicType.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

basicType::basicType(int kind,int size)
{
	this->kind = kind;
	this->size = size;
}
/**/
basicType::basicType(int kind,int size,string name)
{
	this->kind = kind;
	this->size = size;
	this->name = name;
}

/*
���͵��ڲ���ʾ��Ϊ��ָ�룻
*/
basicType * const basicType::intPtr = new basicType(basicTypeCode::INT,basicTypeCode::INT_SIZE,"int");
basicType * const basicType::voidPtr = new basicType(basicTypeCode::VOID,basicTypeCode::VOID_SIZE,"void");
 
/*
���������const��ʾ�÷����������ı��������;
*/
int basicType::get_kind() const
{
	return kind;
}
int basicType::get_size() const
{
	return size;
}
string basicType::get_name() const
{
	return name;
}
void basicType::display()
{
	cout<<this->name<<' ';
//	cout<<"����ֵ����:"<<this->name<<":\t"<<this->kind<<":"<<this->size<<endl;
}
basicType::~basicType()
{

}
