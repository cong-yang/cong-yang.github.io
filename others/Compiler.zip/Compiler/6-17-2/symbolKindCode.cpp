// symbolKindCode.cpp: implementation of the symbolKindCode class.
//
//////////////////////////////////////////////////////////////////////

#include "symbolKindCode.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

symbolKindCode::symbolKindCode()
{

}

int symbolKindCode::ARRAY = 1;
int symbolKindCode::NUM = 2;
int symbolKindCode::PROC = 3;
int symbolKindCode::VAR = 4;
int symbolKindCode::END = 5;
//int symbolKindCode::PARM = 5;


symbolKindCode::~symbolKindCode()
{

}
