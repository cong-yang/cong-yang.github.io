// symbolTable.h: interface for the symbolTable class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SYMBOLTABLE_H__675B0BDD_B59A_4B36_9E85_EF3AFC955D69__INCLUDED_)
#define AFX_SYMBOLTABLE_H__675B0BDD_B59A_4B36_9E85_EF3AFC955D69__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "symbolRecord.h"
#include "treeNode.h"
#include <vector>

class symbolTable  
{
private:
	vector<symbolRecord*> v_st;
	
public:
	symbolTable();
	int static ERROR_NOT_FOUND;
	bool insert(symbolRecord *sr);
	bool search_num(string name);			//���ҳ���
	bool search_redefine(symbolRecord *sr,int start_pos);//�����ظ�����
	//symbolRecord *search(symbolRecord *sr);			//����Ӧ�÷��ʵķ��ţ�
	vector<symbolRecord*> *get_v_st();
	void display();
	int find_symbol(treeNode *tn);
	symbolRecord *find_symbol_sr(treeNode *tn);
	virtual ~symbolTable();

};

#endif // !defined(AFX_SYMBOLTABLE_H__675B0BDD_B59A_4B36_9E85_EF3AFC955D69__INCLUDED_)
