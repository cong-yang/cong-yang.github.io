// symbolTableParam.cpp: implementation of the symbolTableParam class.
//
//////////////////////////////////////////////////////////////////////

#include "symbolTableParam.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

symbolTableParam::symbolTableParam()
{

}

vector<symbolRecordParam*> *symbolTableParam::get_v_st()
{
	return &v_st;			//���ط��ű����ݽṹv_st�ĵ�ַ
}

void symbolTableParam::insert_param(symbolRecordParam *srp)
{

	this->v_st.push_back(srp);
}

int symbolTableParam::find_param(string proc_name)
{
	vector<symbolRecordParam*>::iterator i,iend;
	int j=0;
	string ts;
	i = v_st.begin();
	iend = v_st.end();
	for(;i != iend;i++)
	{
		ts=(*i)->get_proc_name();
		if(ts.compare(proc_name) == 0)
		{
			return j;
		}
		j++;
	}
	return -1;
}
symbolTableParam::~symbolTableParam()
{

}