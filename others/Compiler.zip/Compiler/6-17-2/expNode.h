// expNode.h: interface for the expNode class.
// 
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EXPNODE_H__AF3BD71D_1087_4D19_AA0C_D3069AF9F9F8__INCLUDED_)
#define AFX_EXPNODE_H__AF3BD71D_1087_4D19_AA0C_D3069AF9F9F8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nodeBase.h"
#include "basicType.h"

class expNode:public nodeBase
{
protected:
	 basicType * const return_type;		//ָ��basicType�ĳ�ָ�룬ָ�뱾�����ɸı䣻
public:
	expNode(int line_no,int node_type,string name,basicType *return_type);
	basicType * get_return_type();
	void display();
	virtual ~expNode();

};

#endif // !defined(AFX_EXPNODE_H__AF3BD71D_1087_4D19_AA0C_D3069AF9F9F8__INCLUDED_)
