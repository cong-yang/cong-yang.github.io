// BNF.cpp: implementation of the BNF class.
//
//////////////////////////////////////////////////////////////////////

#include "BNF.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

/*
BNF::BNF(vector<produce*> *v_produce)
{
	this->v_produce = v_produce;
}

BNF::BNF(const BNF &bnf)
{
	this->v_produce = bnf.v_produce;
}
*/

int BNF::push_back(produce *p)
{
	this->v_produce->push_back(p);
	return this->v_produce->size();
}

signString *BNF::create_ss(string sign_name,int sign_code)
{
	vector<signString*>::iterator i,iend;
	iend = this->v_ss->end();
	for(i = v_ss->begin();i != iend;i++)
	{
		if((*i)->get_value() == sign_code)
		{
			return (*i);
		}
	}
	signString *ss = new signString(sign_name,sign_code);
	this->v_ss->push_back(ss);
	return ss;

}

vector<produce*> *BNF::get_produce()
{
	return this->v_produce;
}

vector<signString*> *BNF::get_ss()
{	
	return this->v_ss;
}

BNF::BNF()
{
	this->v_produce = new vector<produce*>;
	this->v_ss		= new produce::t_ss_vector();

	produce *p = NULL;
	//1.	program �� declaration-list
	p = new produce(this->create_ss("program",signWord::PROGRAM));
	p->push_back(create_ss("declaration_list",signWord::DECLARATION_LIST));
	v_produce->push_back(p);

	//2.	declaration-list �� declaration declaration-more
	p = new produce(create_ss("declaration-list",signWord::DECLARATION_LIST));
	p->push_back(create_ss("declaration",signWord::DECLARATION));
	p->push_back(create_ss("declaration-more",signWord::DECLARATION_MORE));
	this->v_produce->push_back(p);


	//3.	declaration-more �� declaration declaration-more
	p = new produce(create_ss("declaration-more",signWord::DECLARATION_MORE));
	p->push_back(create_ss("declaration",signWord::DECLARATION));
	p->push_back(create_ss("declaration-more",signWord::DECLARATION_MORE));
	this->v_produce->push_back(p);

	//4.	declaration-more ����
	p = new produce(create_ss("declaration-more",signWord::DECLARATION_MORE));
	p->push_back(create_ss("��",keyWord::EMPTY));
	this->v_produce->push_back(p);

	//5.	declaration �� type-specifier ID declaration-type
	p = new produce(create_ss("declaration",signWord::DECLARATION));
	p->push_back(create_ss("type-specifier",signWord::TYPE_SPECIFIER));
	p->push_back(create_ss("ID",keyWord::ID));
	p->push_back(create_ss("declaration-type",signWord::DECLARATION_TYPE));
	this->v_produce->push_back(p);

	//6.	declaration-type �� ; 
	p = new produce(create_ss("declaration-type",signWord::DECLARATION_TYPE));
	p->push_back(create_ss(";",keyWord::SEMI));
	this->v_produce->push_back(p);

	//7.	declaration-type �� [ NUM ] ; 
	p = new produce(create_ss("declaration-type",signWord::DECLARATION_TYPE));
	p->push_back(create_ss("[",keyWord::LEFT_MID));
	p->push_back(create_ss("NUM",keyWord::NUM));
	p->push_back(create_ss("]",keyWord::RIGHT_MID));
	p->push_back(create_ss(";",keyWord::SEMI));
	this->v_produce->push_back(p);

	//8.	declaration-type �� ( params ) compound-stmt
	p = new produce(create_ss("declaration-type",signWord::DECLARATION_TYPE));
	p->push_back(create_ss("(",keyWord::LEFT_SMALL));
	p->push_back(create_ss("params",signWord::PARAMS));
	p->push_back(create_ss(")",keyWord::RIGHT_SMALL));
	p->push_back(create_ss("compound-stmt",signWord::COMPOUND_STMT));
	this->v_produce->push_back(p);

	//9.	type-specifier-var �� int
	p = new produce(create_ss("type-specifier-var",signWord::TYPE_SPECIFIER_VAR));
	p->push_back(create_ss("int",keyWord::INT));
	this->v_produce->push_back(p);

	//10.	type-specifier �� type-specifier-var
	p = new produce(create_ss("type-specifier",signWord::TYPE_SPECIFIER));
	p -> push_back(create_ss("type-specifier-var",signWord::TYPE_SPECIFIER_VAR));
	this->v_produce->push_back(p);
	
	//11.	type-specifier �� void
	p = new produce(create_ss("type-specifier",signWord::TYPE_SPECIFIER));
	p->push_back(create_ss("void",keyWord::VOID));
	this->v_produce->push_back(p);

	//12.	params �� type-specifier-var ID param-more param-list-more
	p = new produce(create_ss("params",signWord::PARAMS));
	p->push_back(create_ss("type_specifier_var",signWord::TYPE_SPECIFIER_VAR));
	p->push_back(create_ss("ID",keyWord::ID));
	p->push_back(create_ss("param_more",signWord::PARAM_MORE));
	p->push_back(create_ss("param_list_more",signWord::PARAM_LIST_MORE));
	this->v_produce->push_back(p);

	//13.	params �� void params-more
	p = new produce(create_ss("params",signWord::PARAMS));
	p->push_back(create_ss("void",keyWord::VOID));
	p->push_back(create_ss("params_more",signWord::PARAMS_MORE));
	this->v_produce->push_back(p);

	//14.	params-more �� ID param-more param-list-more
	p = new produce(create_ss("params_more",signWord::PARAMS_MORE));
	p->push_back(create_ss("ID",keyWord::ID));
	p->push_back(create_ss("param_more",signWord::PARAM_MORE));
	p->push_back(create_ss("param_list_more",signWord::PARAM_LIST_MORE));
	this->v_produce->push_back(p);

	//15.	params-more �� ��
	p = new produce(create_ss("params_more",signWord::PARAMS_MORE));
	p->push_back(create_ss("��",keyWord::EMPTY));
	this->v_produce->push_back(p);
	
	//16.	param-list-more �� , param param-list-more
	p = new produce(create_ss("param_list_more",signWord::PARAM_LIST_MORE));
	p->push_back(create_ss(",",keyWord::COMMA));
	p->push_back(create_ss("param",signWord::PARAM));
	p->push_back(create_ss("param_list_more",signWord::PARAM_LIST_MORE));
	this->v_produce->push_back(p);

	//17.	param-list-more �� ��
	p = new produce(create_ss("param_list_more",signWord::PARAM_LIST_MORE));
	p->push_back(create_ss("��",keyWord::EMPTY));
	this->v_produce->push_back(p);

	//18.	param �� type-specifier ID param-more
	p = new produce(create_ss("param",signWord::PARAM));
	p->push_back(create_ss("type_specifier",signWord::TYPE_SPECIFIER));
	p->push_back(create_ss("ID",keyWord::ID));
	p->push_back(create_ss("param_more",signWord::PARAM_MORE));
	this->v_produce->push_back(p);

	//19.	param-more �� [ ]
	p = new produce(create_ss("param_more",signWord::PARAM_MORE));
	p->push_back(create_ss("[",keyWord::LEFT_MID));
	p->push_back(create_ss("]",keyWord::RIGHT_MID));
	this->v_produce->push_back(p);

	//20.	param-more �� ��
	p = new produce(create_ss("param_more",signWord::PARAM_MORE));
	p->push_back(create_ss("��",keyWord::EMPTY));
	this->v_produce->push_back(p);
	
	//21.	compound-stmt �� { local-declarations statement-list }
	p = new produce(create_ss("compound_stmt",signWord::COMPOUND_STMT));
	p->push_back(create_ss("{",keyWord::LEFT_BIG));
	p->push_back(create_ss("local_declarations",signWord::LOCAL_DECLARATIONS));
	p->push_back(create_ss("statement_list",signWord::STATEMENT_LIST));
	p->push_back(create_ss("}",keyWord::RIGHT_BIG));
	this->v_produce->push_back(p);

	//22.	local-declarations �� var-declaration local-declarations 
	p = new produce(create_ss("local_declarations",signWord::LOCAL_DECLARATIONS));
	p->push_back(create_ss("var_declaration",signWord::VAR_DECLARATION));
	p->push_back(create_ss("local_declarations",signWord::LOCAL_DECLARATIONS));
	this->v_produce->push_back(p);

	//23.	local-declarations �� ��
	p = new produce(create_ss("local_declarations",signWord::LOCAL_DECLARATIONS));
	p->push_back(create_ss("��",keyWord::EMPTY));
	this->v_produce->push_back(p);

	//24.	var-declaration �� type-specifier ID var-declaration-more
	p = new produce(create_ss("var_declaration",signWord::VAR_DECLARATION));
	p->push_back(create_ss("type_specifier",signWord::TYPE_SPECIFIER));
	p->push_back(create_ss("ID",keyWord::ID));
	p->push_back(create_ss("var_declaration_more",signWord::VAR_DECLARATION_MORE));
	this->v_produce->push_back(p);

	//25.	var-declaration-more �� ;
	p = new produce(create_ss("var_declaration_more",signWord::VAR_DECLARATION_MORE));
	p->push_back(create_ss(";",keyWord::SEMI));
	this->v_produce->push_back(p);
	
	//26.	var-declaration-more �� [ NUM ] ;
	p = new produce(create_ss("var_declaration_more",signWord::VAR_DECLARATION_MORE));
	p->push_back(create_ss("[",keyWord::LEFT_MID));
	p->push_back(create_ss("NUM",keyWord::NUM));
	p->push_back(create_ss("]",keyWord::RIGHT_MID));
	p->push_back(create_ss(";",keyWord::SEMI));
	this->v_produce->push_back(p);

	//27.	statement-list �� statement statement-list
	p = new produce(create_ss("statement_list",signWord::STATEMENT_LIST));
	p->push_back(create_ss("statement",signWord::STATEMENT));
	p->push_back(create_ss("statement_list",signWord::STATEMENT_LIST));
	this->v_produce->push_back(p);

	//28.	statement-list �� ��
	p = new produce(create_ss("statement_list",signWord::STATEMENT_LIST));
	p->push_back(create_ss("��",keyWord::EMPTY));
	this->v_produce->push_back(p);

	//29.	statement �� expression-stmt
	p = new produce(create_ss("statement",signWord::STATEMENT));
	p->push_back(create_ss("expression_stmt",signWord::EXPRESSION_STMT));
	this->v_produce->push_back(p);

	//30.	statement �� compound-stmt
	p = new produce(create_ss("statement",signWord::STATEMENT));
	p->push_back(create_ss("compound_stmt",signWord::COMPOUND_STMT));
	this->v_produce->push_back(p);
	
	//31.	statement �� selection-stmt
	p = new produce(create_ss("statement",signWord::STATEMENT));
	p->push_back(create_ss("selection_stmt",signWord::SELECTION_STMT));
	this->v_produce->push_back(p);

	//32.	statement �� iteration-stmt
	p = new produce(create_ss("statement",signWord::STATEMENT));
	p->push_back(create_ss("iteration_stmt",signWord::ITERATION_STMT));
	this->v_produce->push_back(p);

	//33.	statement �� return-stmt
	p = new produce(create_ss("statement",signWord::STATEMENT));
	p->push_back(create_ss("return_stmt",signWord::RETURN_STMT));
	this->v_produce->push_back(p);

	//34.	expression-stmt �� expression ; 
	p = new produce(create_ss("expression_stmt",signWord::EXPRESSION_STMT));
	p->push_back(create_ss("expression",signWord::EXPRESSION));
	p->push_back(create_ss(";",keyWord::SEMI));
	this->v_produce->push_back(p);

	//35.	expression-stmt �� ;
	p = new produce(create_ss("expression_stmt",signWord::EXPRESSION_STMT));
	p->push_back(create_ss(";",keyWord::SEMI));
	this->v_produce->push_back(p);
	
	//36.	selection-stmt �� if ( expression ) statement selection-stmt-more
	p = new produce(create_ss("selection_stmt",signWord::SELECTION_STMT));
	p->push_back(create_ss("if",keyWord::IF));
	p->push_back(create_ss("(",keyWord::LEFT_SMALL));
	p->push_back(create_ss("expression",signWord::EXPRESSION));
	p->push_back(create_ss(")",keyWord::RIGHT_SMALL));
	p->push_back(create_ss("statement",signWord::STATEMENT));
	p->push_back(create_ss("selection_stmt_more",signWord::SELECTION_STMT_MORE));
	this->v_produce->push_back(p);

	//37.	selection-stmt-more �� else statement
	p = new produce(create_ss("selection_stmt_more",signWord::SELECTION_STMT_MORE));
	p->push_back(create_ss("else",keyWord::ELSE));
	p->push_back(create_ss("statement",signWord::STATEMENT));
	this->v_produce->push_back(p);

	//38.	selection-stmt-more �� ��
	p = new produce(create_ss("selection_stmt_more",signWord::SELECTION_STMT_MORE));
	p->push_back(create_ss("��",keyWord::EMPTY));
	this->v_produce->push_back(p);

	//39.	iteration-stmt �� while ( expression ) statement
	p = new produce(create_ss("iteration_stmt",signWord::ITERATION_STMT));
	p->push_back(create_ss("while",keyWord::WHILE));
	p->push_back(create_ss("(",keyWord::LEFT_SMALL));
	p->push_back(create_ss("expression",signWord::EXPRESSION));
	p->push_back(create_ss(")",keyWord::RIGHT_SMALL));
	p->push_back(create_ss("statement",signWord::STATEMENT));
	this->v_produce->push_back(p);

	//40.	return-stmt �� return expression-stmt
	p = new produce(create_ss("return_stmt",signWord::RETURN_STMT));
	p->push_back(create_ss("return",keyWord::RETURN));
	p->push_back(create_ss("expression-stmt",signWord::EXPRESSION_STMT));
	this->v_produce->push_back(p);

	/*
	//40.	return-stmt �� return return-stmt-more
	p = new produce(create_ss("return_stmt",signWord::RETURN_STMT));
	p->push_back(create_ss("return",keyWord::RETURN));
	p->push_back(create_ss("return_stmt_more",signWord::RETURN_STMT_MORE));
	this->v_produce->push_back(p);

	
	//41.	return-stmt-more �� ;
	p = new produce(create_ss("return_stmt_more",signWord::RETURN_STMT_MORE));
	p->push_back(create_ss(";",keyWord::SEMI));
	this->v_produce->push_back(p);

	//42.	return-stmt-more �� expression ;
	p = new produce(create_ss("return_stmt_more",signWord::RETURN_STMT_MORE));
	p->push_back(create_ss("expression",signWord::EXPRESSION));
	p->push_back(create_ss(";",keyWord::SEMI));
	this->v_produce->push_back(p);
	*/

	//43.	expression �� ( expression ) term-more additive-expression-more simple-expression-more
	p = new produce(create_ss("expression",signWord::EXPRESSION));
	p->push_back(create_ss("(",keyWord::LEFT_SMALL));
	p->push_back(create_ss("expression",signWord::EXPRESSION));
	p->push_back(create_ss(")",keyWord::RIGHT_SMALL));
	p->push_back(create_ss("term-more",signWord::TERM_MORE));
	p->push_back(create_ss("additive-expression-more",signWord::ADDITIVE_EXPRESSION_MORE));
	p->push_back(create_ss("simple-expression-more",signWord::SIMPLE_EXPRESSION_MORE));
	this->v_produce->push_back(p);

	//44.	expression �� NUM term-more additive-expression-more simple-expression-more
	p = new produce(create_ss("expression",signWord::EXPRESSION));
	p->push_back(create_ss("NUM",keyWord::NUM));
	p->push_back(create_ss("term-more",signWord::TERM_MORE));
	p->push_back(create_ss("additive-expression-more",signWord::ADDITIVE_EXPRESSION_MORE));
	p->push_back(create_ss("simple-expression-more",signWord::SIMPLE_EXPRESSION_MORE));
	this->v_produce->push_back(p);

	//45.	expression �� ID ID-more
	p = new produce(create_ss("expression",signWord::EXPRESSION));
	p->push_back(create_ss("ID",keyWord::ID));
	p->push_back(create_ss("ID-more",signWord::ID_MORE));
	this->v_produce->push_back(p);
	
	//46.	ID-more ��var-more ID-mm
	p = new produce(create_ss("ID-more",signWord::ID_MORE));
	p->push_back(create_ss("var-more",signWord::VAR_MORE));
	p->push_back(create_ss("ID-mm",signWord::ID_MM));
	this->v_produce->push_back(p);

	//47.	ID-more ��(args) term-more additive-expression-more simple-expression-more
	p = new produce(create_ss("ID-more",signWord::ID_MORE));
	p->push_back(create_ss("(",keyWord::LEFT_SMALL));
	p->push_back(create_ss("args",signWord::ARGS));
	p->push_back(create_ss(")",keyWord::RIGHT_SMALL));
	p->push_back(create_ss("term-more",signWord::TERM_MORE));
	p->push_back(create_ss("additive-expression-more",signWord::ADDITIVE_EXPRESSION_MORE));
	p->push_back(create_ss("simple-expression-more",signWord::SIMPLE_EXPRESSION_MORE));
	this->v_produce->push_back(p);

	//48.	ID-mm �� = expression
	p = new produce(create_ss("ID-mm",signWord::ID_MM));
	p->push_back(create_ss("=",keyWord::GIVE));
	p->push_back(create_ss("expression",signWord::EXPRESSION));
	this->v_produce->push_back(p);

	//49.	ID-mm ��term-more additive-expression-more simple-expression-more
	p = new produce(create_ss("ID-mm",signWord::ID_MM));
	p->push_back(create_ss("term-more",signWord::TERM_MORE));
	p->push_back(create_ss("additive-expression-more",signWord::ADDITIVE_EXPRESSION_MORE));
	p->push_back(create_ss("simple-expression-more",signWord::SIMPLE_EXPRESSION_MORE));
	this->v_produce->push_back(p);

	//50.	var-more �� [ expression ]
	p = new produce(create_ss("var-more",signWord::VAR_MORE));
	p->push_back(create_ss("[",keyWord::LEFT_MID));
	p->push_back(create_ss("expression",signWord::EXPRESSION));
	p->push_back(create_ss("]",keyWord::RIGHT_MID));
	this->v_produce->push_back(p);
	
	//51.	var-more �� ��
	p = new produce(create_ss("var-more",signWord::VAR_MORE));
	p->push_back(create_ss("��",keyWord::EMPTY));
	this->v_produce->push_back(p);

	//52.	simple-expression-more �� relop additive-expression
	p = new produce(create_ss("simple-expression-more",signWord::SIMPLE_EXPRESSION_MORE));
	p->push_back(create_ss("relop",signWord::RELOP));
	p->push_back(create_ss("additive-expression",signWord::ADDITIVE_EXPRESSION));
	this->v_produce->push_back(p);

	//53.	simple-expression-more �� ��
	p = new produce(create_ss("simple-expression-more",signWord::SIMPLE_EXPRESSION_MORE));
	p->push_back(create_ss("��",keyWord::EMPTY));
	this->v_produce->push_back(p);

	//54.	relop �� <=
	p = new produce(create_ss("relop",signWord::RELOP));
	p->push_back(create_ss("<=",keyWord::SMALL_EQUAL));
	this->v_produce->push_back(p);

	//55.	relop �� <
	p = new produce(create_ss("relop",signWord::RELOP));
	p->push_back(create_ss("<",keyWord::SMALL));
	this->v_produce->push_back(p);

	//56.	relop �� >
	p = new produce(create_ss("relop",signWord::RELOP));
	p->push_back(create_ss(">",keyWord::BIG));
	this->v_produce->push_back(p);

	//57.	relop �� >=
	p = new produce(create_ss("relop",signWord::RELOP));
	p->push_back(create_ss(">=",keyWord::BIG_EQUAL));
	this->v_produce->push_back(p);

	//58.	relop �� ==
	p = new produce(create_ss("relop",signWord::RELOP));
	p->push_back(create_ss("==",keyWord::EQUAL));
	this->v_produce->push_back(p);

	//59.	relop �� !=
	p = new produce(create_ss("relop",signWord::RELOP));
	p->push_back(create_ss("!=",keyWord::NOT_EQUAL));
	this->v_produce->push_back(p);

	//60.	additive-expression �� term additive-expression-more
	p = new produce(create_ss("additive-expression",signWord::ADDITIVE_EXPRESSION));
	p->push_back(create_ss("term",signWord::TERM));
	p->push_back(create_ss("additive-expression-more",signWord::ADDITIVE_EXPRESSION_MORE));
	this->v_produce->push_back(p);
	
	//61.	additive-expression-more �� addop term additive-expression-more 
	p = new produce(create_ss("additive-expression-more",signWord::ADDITIVE_EXPRESSION_MORE));
	p->push_back(create_ss("addop",signWord::ADDOP));
	p->push_back(create_ss("term",signWord::TERM));
	p->push_back(create_ss("additive-expression-more",signWord::ADDITIVE_EXPRESSION_MORE));
	this->v_produce->push_back(p);

	//62.	additive-expression-more �� ��
	p = new produce(create_ss("additive-expression-more",signWord::ADDITIVE_EXPRESSION_MORE));
	p->push_back(create_ss("��",keyWord::EMPTY));
	this->v_produce->push_back(p);

	//63.	addop �� + 
	p = new produce(create_ss("addop",signWord::ADDOP));
	p->push_back(create_ss("+",keyWord::PLUS));
	this->v_produce->push_back(p);

	//64.	addop �� - 
	p = new produce(create_ss("addop",signWord::ADDOP));
	p->push_back(create_ss("-",keyWord::MINUS));
	this->v_produce->push_back(p);

	//65.	term �� factor term-more
	p = new produce(create_ss("term",signWord::TERM));
	p->push_back(create_ss("factor",signWord::FACTOR));
	p->push_back(create_ss("term-more",signWord::TERM_MORE));
	this->v_produce->push_back(p);
	
	//66.	term-more �� mulop factor term-more
	p = new produce(create_ss("term-more",signWord::TERM_MORE));
	p->push_back(create_ss("mulop",signWord::MULOP));
	p->push_back(create_ss("factor",signWord::FACTOR));
	p->push_back(create_ss("term-more",signWord::TERM_MORE));
	this->v_produce->push_back(p);

	//67.	term-more �� ��
	p = new produce(create_ss("term-more",signWord::TERM_MORE));
	p->push_back(create_ss("��",keyWord::EMPTY));
	this->v_produce->push_back(p);

	//68.	mulop �� * 
	p = new produce(create_ss("mulop",signWord::MULOP));
	p->push_back(create_ss("*",keyWord::MULTIPLY));
	this->v_produce->push_back(p);

	//69.	mulop �� /
	p = new produce(create_ss("mulop",signWord::MULOP));
	p->push_back(create_ss("/",keyWord::DIVIDE));
	this->v_produce->push_back(p);


	//70.	factor �� ( expression )
	p = new produce(create_ss("factor",signWord::FACTOR));
	p->push_back(create_ss("(",keyWord::LEFT_SMALL));
	p->push_back(create_ss("expression",signWord::EXPRESSION));
	p->push_back(create_ss(")",keyWord::RIGHT_SMALL));
	this->v_produce->push_back(p);
	
	//71.	factor �� ID factor-more
	p = new produce(create_ss("factor",signWord::FACTOR));
	p->push_back(create_ss("ID",keyWord::ID));
	p->push_back(create_ss("factor-more",signWord::FACTOR_MORE));
	this->v_produce->push_back(p);

	//72.	factor �� NUM
	p = new produce(create_ss("factor",signWord::FACTOR));
	p->push_back(create_ss("NUM",keyWord::NUM));
	this->v_produce->push_back(p);

	//73.	factor-more �� var-more
	p = new produce(create_ss("factor-more",signWord::FACTOR_MORE));
	p->push_back(create_ss("var-more",signWord::VAR_MORE));
	this->v_produce->push_back(p);

	//74.	factor-more �� (args )
	p = new produce(create_ss("factor-more",signWord::FACTOR_MORE));
	p->push_back(create_ss("(",keyWord::LEFT_SMALL));
	p->push_back(create_ss("args",signWord::ARGS));
	p->push_back(create_ss(")",keyWord::RIGHT_SMALL));
	this->v_produce->push_back(p);

	//75.	args �� arg-list
	p = new produce(create_ss("args",signWord::ARGS));
	p->push_back(create_ss("arg-list",signWord::ARG_LIST));
	this->v_produce->push_back(p);
	
	//76.	args �� ��
	p = new produce(create_ss("args",signWord::ARGS));
	p->push_back(create_ss("��",keyWord::EMPTY));
	this->v_produce->push_back(p);

	//77.	arg-list �� expression arg-list-more
	p = new produce(create_ss("arg-list",signWord::ARG_LIST));
	p->push_back(create_ss("expression",signWord::EXPRESSION));
	p->push_back(create_ss("arg-list-more",signWord::ARG_LIST_MORE));
	this->v_produce->push_back(p);

	//78.	arg-list-more �� , expression arg-list-more
	p = new produce(create_ss("arg-list-more",signWord::ARG_LIST_MORE));
	p->push_back(create_ss(",",keyWord::COMMA));
	p->push_back(create_ss("expression",signWord::EXPRESSION));
	p->push_back(create_ss("arg-list-more",signWord::ARG_LIST_MORE));
	this->v_produce->push_back(p);

	//79.	arg-list-more �� ��
	p = new produce(create_ss("arg-list-more",signWord::ARG_LIST_MORE));
	p->push_back(create_ss("��",keyWord::EMPTY));
	this->v_produce->push_back(p);
	
	//����#;
	create_ss("#",keyWord::END);
}

void BNF::display()
{
	vector<produce*>::iterator i,iend;
	iend = this->v_produce->end();
	int j = 1;
	for(i = this->v_produce->begin();i != iend;i++,j++)
	{
		cout<<j<<": ";
		(*i)->display();
	}
}

BNF::~BNF()
{
	vector<produce*>::iterator i,iend;
	int j = 0;

	iend = this->v_produce->end();
	for(i = this->v_produce->begin();i != iend;i++)
	{
		if((*i)!=NULL)
		{
			delete *i;
			j++;
		}
			
	}
	cout<<"һ��ɾ����"<<j<<"������ʽ��"<<endl;

	j = 0;

	vector<signString*>::iterator i_ss,iend_ss;
	iend_ss = this->v_ss->end();
	for(i_ss = this->v_ss->begin();i_ss != iend_ss;i_ss++)
	{
		if((*i_ss)!=NULL)
		{
			delete *i_ss;
			j++;
		}
			
	}
	cout<<"һ��ɾ����"<<j<<"�����š�"<<endl;

	if(this->v_produce != NULL)
		delete v_produce;
	if(this->v_ss != NULL)
		delete v_ss;

	cout<<"BNF���������������á�"<<endl;
}
