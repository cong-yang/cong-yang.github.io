// symbolKindCode.h: interface for the symbolKindCode class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SYMBOLKINDCODE_H__657B53D7_3C03_484B_81F5_E03E7B7C6345__INCLUDED_)
#define AFX_SYMBOLKINDCODE_H__657B53D7_3C03_484B_81F5_E03E7B7C6345__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class symbolKindCode  
{
public:
	static int
	VAR,			
	NUM,			
	ARRAY,			
	PROC,
	END;


	symbolKindCode();
	virtual ~symbolKindCode();

};

#endif // !defined(AFX_SYMBOLKINDCODE_H__657B53D7_3C03_484B_81F5_E03E7B7C6345__INCLUDED_)
