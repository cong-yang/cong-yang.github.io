// treeNode.cpp: implementation of the treeNode class.
//
//////////////////////////////////////////////////////////////////////

#include "treeNode.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

treeNode::treeNode()
{
	this->node_type = 0;
	this->node_name = NULL;
	this->name = NULL;
	this->return_type = NULL;
	this->line_no = 0;
	this->size = 0;
	this->level = 0;
	this->child = NULL;
	this->parent = NULL;
	this->address = -1;
}

treeNode::treeNode(int node_type,string node_name,string name,basicType *return_type,int line_no,int size)
{
	this->node_type = node_type;
	this->node_name = new string(node_name);
	this->name = new string(name);
	this->return_type = return_type;
	this->line_no = line_no;
	this->size = size;
	this->level = 0;
	this->child = NULL;
	this->parent = NULL;
	this->address = -1;
}
void treeNode::set_node_type(int node_type)
{
	this->node_type = node_type;
}

int treeNode::get_node_type()
{
	return this->node_type;
}

void treeNode::set_node_name(string node_name)
{
	this->node_name = new string(node_name);
}

string *treeNode::get_node_name()
{
	return this->node_name;
}

void treeNode::set_name(string name)
{
	this->name = new string(name);
}

string *treeNode::get_name()
{
	return this->name;
}

void treeNode::set_value(int value)
{
	this->value = value;
}

int treeNode::get_value()
{
	return this->value;
}

void treeNode::set_address(int address)
{
	this->address = address;
}

int treeNode::get_address()
{
	return this->address;
}

void treeNode::set_return_type(basicType *return_type)
{
	this->return_type = return_type;
}

basicType *treeNode::get_return_type()
{
	return this->return_type;
}

void treeNode::set_line_no(int line_no)
{
	this->line_no = line_no;
}

int treeNode::get_line_no()
{
	return line_no;
}

void treeNode::set_size(int size)
{
	this->size = size;
}

int treeNode::get_size()
{
	return this->size;
}

void treeNode::set_level(int level)
{
	this->level = level;
	vector<treeNode*>::iterator i,iend;
	if(this->get_child() != NULL)
	{
		iend = this->get_child()->end();
		for(i = this->get_child()->begin();i != iend;i++)
		{
			(*i)->set_level((*i)->get_parent()->get_level()+1);
		}
	}
}

int treeNode::get_level()
{

	return this->level;
}

void treeNode::set_child(vector<treeNode*> *child)
{
	this->child = child;
}

vector<treeNode*> *treeNode::get_child()
{
	return this->child;
}

void treeNode::set_parent(treeNode *parent)
{
	this->parent = parent;
}

treeNode *treeNode::get_parent()
{
	return this->parent;
}

void treeNode::display()
{
/*	cout<<"node_name:"<<*this->node_name<<' ';
	cout<<"name:"<<*this->name<<' ';
	cout<<"return_type:";
	this->return_type->display();
	cout<<"line_no:"<<this->line_no<<' '<<"size:"<<this->size<<' ';*/
	if(node_name != NULL)
		cout<<*this->node_name<<' ';
	if(name != NULL)
		cout<<*this->name<<' ';
	if(return_type != NULL)
		return_type->display();
	if(line_no !=0)
		cout<<line_no<<' ';
	if(size != 0)
		cout<<size<<' ';
	cout<<this->address<<' ';
}
treeNode::~treeNode()
{

}
