// operateCode.cpp: implementation of the operateCode class.
//
//////////////////////////////////////////////////////////////////////

#include "operateCode.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

operateCode::operateCode()
{

}

int operateCode::END = 1;
int operateCode::GIVE = 2;
int operateCode::SMALL = 3;
int operateCode::SMALL_EQUAL = 3;
int operateCode::BIG = 3;
int operateCode::BIG_EQUAL = 3;
int operateCode::EQUAL = 3;
int operateCode::NOT_EQUAL = 3;
int operateCode::PLUS = 4;
int operateCode::MINUS = 4;
int operateCode::MULTIPLY = 5;
int operateCode::DIVIDE = 5;

operateCode::~operateCode()
{

}
