// symbolRecordParam.cpp: implementation of the symbolRecordParam class.
//
//////////////////////////////////////////////////////////////////////

#include "symbolRecordParam.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

symbolRecordParam::symbolRecordParam(int kind,string name,string proc_name)
{	
	this->name = name;
	this->proc_name = proc_name;
	this->kind = kind;
	this->return_type = basicType::intPtr;
	this->level = 0;
	this->off = 0;
	this->direct = true;
}

void symbolRecordParam::set_return_type(basicType *return_type)
{
	//if(symbolKindCode::PROC == kind)
		this->return_type = return_type;
}

string symbolRecordParam::get_proc_name()
{
	return this->proc_name;
}

void symbolRecordParam::set_proc_name(string proc_name)
{
	this->proc_name = proc_name;
}


void symbolRecordParam::set_level(int level)
{
	if(symbolKindCode::NUM != kind)
		this->level = level;
}

void symbolRecordParam::set_off(int off)
{
	if(symbolKindCode::NUM != kind || symbolKindCode::PROC != kind)
		this->off = off;
}


int symbolRecordParam::get_kind()
{
	return this->kind;
}

int symbolRecordParam::get_level()
{
	return this->level;
}

string symbolRecordParam::get_name()
{
	return this->name;
}

int symbolRecordParam::get_off()
{
	return this->off;
}


basicType *symbolRecordParam::get_return_type()
{
	return this->return_type;
}


bool symbolRecordParam::get_direct()
{
	return this->direct;
}

void symbolRecordParam::set_direct(bool direct)
{
	this->direct = direct;
}
/*
int symbolRecordParam::get_size()
{
	return this->size;
}

void symbolRecordParam::set_size(bool size)
{
	this->size = size;
}
*/
void symbolRecordParam::display()
{
	cout<<this->name<<'\t';
	cout<<this->kind<<'\t';
	cout<<this->level<<'\t';
	cout<<this->off<<'\t';
	cout<<this->direct<<'\t'<<endl;;
}

symbolRecordParam::~symbolRecordParam()
{

}
