// operateCode.h: interface for the operateCode class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_OPERATECODE_H__CBD0E6AE_4C16_483C_8BF2_00ECC35CF369__INCLUDED_)
#define AFX_OPERATECODE_H__CBD0E6AE_4C16_483C_8BF2_00ECC35CF369__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//���������ȼ����룬�������ȼ��ɵ͵���Ϊ#,=,<(<=,>,>=,==,!=),+(-),*(/)
class operateCode  
{
public:
	static int
		END,			//  #
		GIVE,			//  =
		SMALL,			//	<
		SMALL_EQUAL,	//	<=
		BIG,			//	>
		BIG_EQUAL,		//	>=
		EQUAL,			//	==	
		NOT_EQUAL,		//	!=
		PLUS,			//	+
		MINUS,			//	-
		MULTIPLY,		//	*
		DIVIDE;		    //	/
	operateCode();
	virtual ~operateCode();

};

#endif // !defined(AFX_OPERATECODE_H__CBD0E6AE_4C16_483C_8BF2_00ECC35CF369__INCLUDED_)
