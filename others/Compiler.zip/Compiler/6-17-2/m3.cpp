#include "scanner.h"
#include "basicType.h"
#include "parser.h"
#include "syntaxTree.h"
#include "nodeBase.h"
#include "decNode.h"
#include "nodeTypeCode.h"
#include "decArrayNode.h"
#include "expNode.h"
#include "expVarNode.h"
#include "nodeTypeCode.h"
#include "basicTypeCode.h"
#include <iostream>
using namespace std;
int main3()
{
	//static basicType * const intPtr = new basicType(basicTypeCode::INT,basicTypeCode::INT_SIZE,"int");
	//static basicType * const voidPtr = new basicType(basicTypeCode::VOID,basicTypeCode::VOID_SIZE,"void");
	//static basicType * const floatPtr = new basicType(basicTypeCode::FLOAT,basicTypeCode::FLOAT_SIZE,"float");
	//static basicType * const booleanPtr = new basicType(basicTypeCode::BOOLEAN,basicTypeCode::BOOLEAN_SIZE,"boolean");
	/*basicType::intPtr->display();
	basicType::voidPtr->display();
	decNode *var1 = new decNode(23,nodeTypeCode::DECK,"var1",basicType::intPtr);
	var1->display();

	nodeBase *nb = new nodeBase(33,nodeTypeCode::PROCK,"root");
	nb->display();

	nb = var1;
	nb->display();

	decArrayNode *dan = new decArrayNode(44,nodeTypeCode::DECK,"array",basicType::intPtr,10);
	dan->display();*/


	
	scanner *s = new scanner();
	parser *p = new parser(s->get_token());

	delete p;
	delete s;
	
	/*syntaxTree *tree = new syntaxTree();

	treeNode *node1 = new treeNode(nodeTypeCode::DEC_ARRAY,"dec_array","a",basicType::intPtr,1,10);
	tree->set_root(node1);

	treeNode *node2 = new treeNode(nodeTypeCode::DEC_ARRAY,"dec_array","a",basicType::intPtr,1,10);
	tree->add_treeNode(node1,node2);

	treeNode *node3 = new treeNode(nodeTypeCode::DEC_ARRAY,"dec_array","a",basicType::intPtr,1,10);
	tree->add_treeNode(node1,node3);

	treeNode *node4 = new treeNode(nodeTypeCode::DEC_ARRAY,"dec_array","a",basicType::intPtr,1,10);
	tree->add_treeNode(node1,node4);
	
	treeNode *node5 = new treeNode(nodeTypeCode::DEC_ARRAY,"dec_array","a",basicType::intPtr,1,10);
	tree->add_treeNode(node2,node5);

	treeNode *node6 = new treeNode(nodeTypeCode::DEC_ARRAY,"dec_array","a",basicType::intPtr,1,10);
	tree->add_treeNode(node2,node6);

	treeNode *node7 = new treeNode(nodeTypeCode::DEC_ARRAY,"dec_array","a",basicType::intPtr,1,10);
	tree->add_treeNode(node2,node7);

	treeNode *node8 = new treeNode(nodeTypeCode::DEC_ARRAY,"dec_array","a",basicType::intPtr,1,10);
	tree->add_treeNode(node6,node8);

	treeNode *node9 = new treeNode(nodeTypeCode::DEC_ARRAY,"dec_array","a",basicType::intPtr,1,10);
	tree->add_treeNode(node6,node9);

	treeNode *node10 = new treeNode(nodeTypeCode::DEC_ARRAY,"dec_array","a",basicType::intPtr,1,10);
	tree->add_treeNode(node9,node10);

	tree->display_syntaxTree();*/
	
	
	return 0;
}