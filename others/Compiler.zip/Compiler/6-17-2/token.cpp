// token.cpp: implementation of the token class.
//////////////////////////////////////////////////////////////////////

#include "token.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


token::token()
{

}

token::token(string s,int v,int pos)
{

	i_value = 0;				//�����ʼ��Ϊ0,��ʾ��Чtoken;
	i_pos = 0;

	if(keyWord::is_ileagl(v))
	{
		this->i_value = v;
	}

	if(!s.empty())
	{
		this->s_name = s;
	}

	if(pos>0)
		i_pos = pos;
}

//˽�б���s_name�Ĵ�ȡ����;
string token::get_name()
{
	return s_name;
}

void token::set_name(string s)
{
	s_name = s;
}

//˽�б���i_value�Ĵ�ȡ����;
int token::get_value()
{
	return i_value;
}

void token::set_value(int i)
{
	i_value = i;
}

//˽�б���i_pos�Ĵ�ȡ����;
int token::get_pos()
{
	return i_pos;
}

void token::set_pos(int i)
{
	i_pos = i;
}

void token::display()
{
	cout<<"name:"<<s_name<<'\t';
	cout<<"value:"<<i_value<<'\t';
	cout<<"pos:"<<i_pos<<endl;
}

token::~token()
{

}
