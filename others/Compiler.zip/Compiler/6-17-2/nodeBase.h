// nodeBase.h: interface for the nodeBase class.
// �����ڶ����﷨�������ĸ��ڵ�,��stmt��־�ڵ㣻
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NODE_H__ACF28953_62B7_46B2_80A2_344D3D9B7D27__INCLUDED_)
#define AFX_NODE_H__ACF28953_62B7_46B2_80A2_344D3D9B7D27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <string>
#include <iostream>
using namespace std;

/*�﷨�������Ľڵ�����*/
class nodeBase  
{
protected:
	int line_no;
	int node_type;
	string name;
public:
	nodeBase(int line_no,int node_type,string name);
	int get_line_no();
	int get_node_type();
	string get_name();
	virtual void display();
	virtual ~nodeBase();

};

#endif // !defined(AFX_NODE_H__ACF28953_62B7_46B2_80A2_344D3D9B7D27__INCLUDED_)
