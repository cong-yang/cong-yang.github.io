// symbolRecord.cpp: implementation of the symbolRecord class.
//
//////////////////////////////////////////////////////////////////////

#include "symbolRecord.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

symbolRecord::symbolRecord(int kind,string name)
{	
	this->name = name;
	this->kind = kind;
	this->return_type = basicType::intPtr;
	this->level = 0;
	this->off = 0;
	//this->parm = NULL;
	this->param_num = 0;
	this->size = 0;
	this->direct = true;
	this->value = 0;
	this->code = 0;

	if( symbolKindCode::NUM == kind)
	{
		string::iterator i,iend;
		int num = 0;
		iend = name.end();
		for(i = name.begin();i != iend;i++)
			num = 10*num+(int)(*i)-48;
		this->value = num;	
	}
}

void symbolRecord::set_return_type(basicType *return_type)
{
	//if(symbolKindCode::PROC == kind)
		this->return_type = return_type;
}

void symbolRecord::set_code(int code)
{
	if(symbolKindCode::PROC == kind)
	{
		this->code = code;
	}
}

void symbolRecord::set_level(int level)
{
	if(symbolKindCode::NUM != kind)
		this->level = level;
}

void symbolRecord::set_off(int off)
{
	if(symbolKindCode::NUM != kind || symbolKindCode::PROC != kind)
		this->off = off;
}

/*
void symbolRecord::set_parm(symbolRecord *parm)
{
	if(symbolKindCode::PROC == kind)
		this->parm = parm;
}
*/

void symbolRecord::set_param_num(int param_num)
{
	if(symbolKindCode::PROC == kind)
		this->param_num = param_num ;
}

void symbolRecord::set_size(int size)
{
	if(symbolKindCode::PROC == kind ||symbolKindCode::ARRAY == kind)
		this->size = size;
}

int symbolRecord::get_code()
{
	return this->code;
}

int symbolRecord::get_kind()
{
	return this->kind;
}

int symbolRecord::get_level()
{
	return this->level;
}

string symbolRecord::get_name()
{
	return this->name;
}

int symbolRecord::get_off()
{
	return this->off;
}

/*
symbolRecord *symbolRecord::get_parm()
{
	return this->parm;
}
*/

int symbolRecord::get_param_num()
{
	return this->param_num;
}

basicType *symbolRecord::get_return_type()
{
	return this->return_type;
}

int symbolRecord::get_size()
{
	return this->size;
}

bool symbolRecord::get_direct()
{
	return this->direct;
}

void symbolRecord::set_direct(bool direct)
{
	this->direct = direct;
}

int symbolRecord::get_value()
{
	return this->value;
}
void symbolRecord::set_value(int value)
{
	this->value = value;
}


void symbolRecord::display()
{
	cout<<this->name<<'\t';
	cout<<this->kind<<'\t';
	cout<<this->level<<'\t';
	cout<<this->off<<'\t';
	cout<<this->param_num<<'\t';
	cout<<this->size<<'\t';
	cout<<this->direct<<'\t';
	cout<<this->value<<'\t';
	cout<<this->code<<'\t'<<endl;
}

symbolRecord::~symbolRecord()
{

}
