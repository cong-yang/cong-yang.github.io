// syntaxTree.h: interface for the syntaxTree class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SYNTAXTREE_H__C0396D52_32EE_4B6E_B5D8_9B21E0798F0F__INCLUDED_)
#define AFX_SYNTAXTREE_H__C0396D52_32EE_4B6E_B5D8_9B21E0798F0F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <vector>
#include "treeNode.h"
using namespace std;

class syntaxTree  
{
public:
	syntaxTree();
	
	void set_root(treeNode *root);
	treeNode *get_root();

	void set_nodeNum(int nodeNum);
	int get_nodeNum();

	void add_treeNode(treeNode *parent,treeNode *node);

	void display_syntaxTree();
	void display_treeNode(treeNode *node);

	virtual ~syntaxTree();

private:
	treeNode *root;
	int nodeNum;
};

#endif // !defined(AFX_SYNTAXTREE_H__C0396D52_32EE_4B6E_B5D8_9B21E0798F0F__INCLUDED_)
