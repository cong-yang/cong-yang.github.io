// treeNode.h: interface for the treeNode class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TREENODE_H__31C6A28A_707A_4E9A_9E21_7526F027C260__INCLUDED_)
#define AFX_TREENODE_H__31C6A28A_707A_4E9A_9E21_7526F027C260__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <iostream>
#include <vector>
#include <string>
#include "basicType.h"
#include "nodeTypeCode.h"
using namespace std;

class treeNode
{

private:
	int node_type;					//�ڵ����ͱ���
	string *node_name;				//�ڵ�����
	string *name;					//��־������
	int value;						//�����������ȼ����룻
	int address;					//���ű���ڵ�ַ��
	basicType *return_type;			//��������
	int line_no;					//�к�
	int size;						//�����С
	int level;						//�ڵ����ڵĲ��
	vector<treeNode*> *child;		//�ڵ�ĺ���
	treeNode *parent;

public:
	treeNode();
	treeNode(int node_type,string node_name,string name,basicType *return_type,int line_no,int size);
	void set_node_type(int node_type);
	int get_node_type();

	void set_node_name(string node_name);
	string *get_node_name();

	void set_name(string name);
	string *get_name();

	void set_value(int value);
	int get_value();

	void set_address(int address);
	int get_address();

	void set_return_type(basicType *return_type);
	basicType *get_return_type();

	void set_line_no(int line_no);
	int get_line_no();

	void set_size(int size);
	int get_size();

	void set_level(int level);
	int get_level();

	void set_child(vector<treeNode*> *child);
	vector<treeNode*> *get_child();

	void set_parent(treeNode *parent);
	treeNode *get_parent();

	void display();
	virtual ~treeNode();
				//�ڵ�ĸ���
};

#endif // !defined(AFX_TREENODE_H__31C6A28A_707A_4E9A_9E21_7526F027C260__INCLUDED_)
