// keyWord.h: interface for the keyWord class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_KEYWORD3_H__E936B01F_4872_40FC_9EB0_8BDB18D89EF0__INCLUDED_)
#define AFX_KEYWORD3_H__E936B01F_4872_40FC_9EB0_8BDB18D89EF0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class keyWord  
{
public:
	keyWord();
	virtual ~keyWord();
	
	static bool is_ileagl(int v);		//���һ��ֵv�Ƿ�������ඨ��ķ�������;

	static int	ELSE,	//else
		IF,				//if
		INT,			//int
		RETURN,			//return
		VOID,			//void
		WHILE,			//while
		PLUS,			//	+
		MINUS,			//	-
		MULTIPLY,		//	*
		DIVIDE,			//	/
		SMALL,			//	<
		SMALL_EQUAL,	//	<=
		BIG,			//	>
		BIG_EQUAL,		//	>=
		EQUAL,			//	==	���ں�
		NOT_EQUAL,		//	!=
		GIVE,			//	=	��ֵ��
		SEMI,			//	;
		COMMA,			//	,
		LEFT_SMALL,		//	(
		RIGHT_SMALL,	//	)
		LEFT_MID,		//	[
		RIGHT_MID,		//	]
		LEFT_BIG,		//	{
		RIGHT_BIG,		//	}
		LEFT_NOTE,		//	/*	��ע�ͷ�
		RIGHT_NOTE,		//	*/	��ע�ͷ�
		ID,				//��ʶ��
		NUM,			//����
		EMPTY,			//��
		END;			// #

};

#endif // !defined(AFX_KEYWORD3_H__E936B01F_4872_40FC_9EB0_8BDB18D89EF0__INCLUDED_)
