#define		FILENAME_SIZE			20

#define		is_letter(ch)			('A'<=(ch)&&(ch)<='Z'|| 'a' <=(ch)&&(ch)<='z')
#define		is_digit(ch)			('0'<=(ch) && (ch)<='9')		