// decNode.cpp: implementation of the decNode class.
//
//////////////////////////////////////////////////////////////////////

#include "decNode.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

decNode::decNode(int line_no,int node_type,string name,basicType *return_type):nodeBase(line_no,node_type,name),return_type(return_type)
{

}
basicType * decNode::get_return_type()
{
	return this->return_type;
}

void decNode::display()
{
	cout<<"decNode:"<<line_no<<"\t"<<node_type<<"\t"<<name<<endl;
	return_type->display();
}

decNode::~decNode()
{

}
