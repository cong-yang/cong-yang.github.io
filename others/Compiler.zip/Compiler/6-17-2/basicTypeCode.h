// basicTypeCode.h: interface for the basicTypeCode class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BASICTYPECODE_H__E04DD70D_B97D_4BC9_A257_99E63B45A3D3__INCLUDED_)
#define AFX_BASICTYPECODE_H__E04DD70D_B97D_4BC9_A257_99E63B45A3D3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class basicTypeCode  
{
public:
	static int
	INT,			//int
	BOOLEAN,		//bool
	FLOAT,			//float
	DOUBLE,			//double
	VOID,			//void

	INT_SIZE,
	BOOLEAN_SIZE,
	FLOAT_SIZE,
	DOUBLE_SIZE,
	VOID_SIZE;

	basicTypeCode();
	virtual ~basicTypeCode();

};

#endif // !defined(AFX_BASICTYPECODE_H__E04DD70D_B97D_4BC9_A257_99E63B45A3D3__INCLUDED_)
