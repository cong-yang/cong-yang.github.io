// scanner.cpp: implementation of the scanner class.
//
//////////////////////////////////////////////////////////////////////

#include "scanner.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

scanner::scanner()
{
	this->l_tokenlist = new list<token*>();
	li_tokenhead = NULL;
	li_tokentail = NULL;

	char c_filename[FILENAME_SIZE];
	char *cp_f;
	char c_outputchar;
	int i_fileline=1;
	fstream f_file;
	cout<<"�������ļ���:";
	cin>>c_filename;
	cp_f=c_filename;
	f_file.open(cp_f);
	if(!f_file)
		cout<<"�Բ����ļ���ʧ��!"<<endl;
	else
	{
	cout<<"Դ�ļ��������£�"<<endl;
	cout<<i_fileline<<"  ";
	while(f_file.get(c_outputchar))
	{
		cout<<setiosflags(ios::left);
		cout<<c_outputchar;
		if(c_outputchar == '\n')
			cout<<setw(2)<<++i_fileline<<' ';
	}
	cout<<endl;
	int i_line;
	i_line = this->scan(cp_f);
	cout<<"�����һ�׶δʷ�������ʼ......"<<endl;
	cout<<"�����һ�׶δʷ���������......"<<endl;
	cout<<endl;
	if(i_line == 0)
	{
		//cout<<"δ������κδʷ�����token��������:"<<endl;
		//this->print_tokenlist();
	}
	else
	{
		cout<<"��"<<i_line<<"��";
		this->print_lasttoken();
		cout<<"�����д���"<<endl;
	}
	}
	
}

string scanner::get_filename()
{
	return s_filename;
}

void scanner::set_filename(string s)
{
	s_filename = s;
}

void scanner::set_tokenhead(list<token*>::iterator head)
{
	li_tokenhead = head;
}

list<token*>::iterator scanner::get_tokenhead()
{
	return li_tokenhead;
}

void scanner::set_tokentail(list<token*>::iterator tail)
{
	li_tokentail = tail;
}

list<token*>::iterator scanner::get_tokentail()
{
	return li_tokentail;
}

list<token*> *scanner::get_token()
{
	return this->l_tokenlist;
}

int scanner::scan(char *f)
{
	fstream f_file;
	string s_tokenname;
	char c_currentchar;
	char c_nextchar;
	int i_lineid=1;
	token *t;

	f_file.open(f);
	while(f_file.get(c_currentchar))
	{
		s_tokenname.erase(s_tokenname.begin(),s_tokenname.end());
		if(is_letter(c_currentchar))
		{
			s_tokenname.insert(s_tokenname.end(),c_currentchar);
			while(!f_file.eof())
			{
				c_nextchar = f_file.peek();
				if(is_letter(c_nextchar)||is_digit(c_nextchar))
				{
					f_file.get(c_currentchar);
					s_tokenname.insert(s_tokenname.end(),c_currentchar);
				}
				else
				{
					t = new token();
					if(s_tokenname.compare("else") == 0)
					{
						t->set_value(keyWord::ELSE);
					}
					else if(s_tokenname.compare("if") == 0)
					{
						t->set_value(keyWord::IF);
					}
					else if(s_tokenname.compare("int") == 0)
					{
						t->set_value(keyWord::INT);
					}
					else if(s_tokenname.compare("return") == 0)
					{
						t->set_value(keyWord::RETURN);
					}
					else if(s_tokenname.compare("void") == 0)
					{
						t->set_value(keyWord::VOID);
					}
					else if(s_tokenname.compare("while") == 0)
					{
						t->set_value(keyWord::WHILE);
					}
					else	t->set_value(keyWord::ID);
					t->set_name(s_tokenname);
					t->set_pos(i_lineid);
					l_tokenlist->push_back(t);
					break;
				}
			}//while

		}//endelse ID�����Լ��ؼ��ֵ��ʵ�����
		else if(is_digit(c_currentchar))
		{
			s_tokenname.insert(s_tokenname.end(),c_currentchar);
			while(!f_file.eof())
			{
				c_nextchar = f_file.peek();
				if(is_digit(c_nextchar))
				{
					f_file.get(c_currentchar);
					s_tokenname.insert(s_tokenname.end(),c_currentchar);
				}
				else
				{
					t = new token;
					t->set_value(keyWord::NUM);
					t->set_name(s_tokenname);
					t->set_pos(i_lineid);
					l_tokenlist->push_back(t);
					break;
				}
			}//while
		}//endelse NUM���ʵ�����
		else if(c_currentchar == '<')
		{
			t = new token;
			if(!f_file.eof())
			{
				c_nextchar = f_file.peek();
				if(c_nextchar == '=')
				{
					f_file.get(c_currentchar);
					t->set_value(keyWord::SMALL_EQUAL);
					t->set_name("<=");
				}//endif <=���ʵ�����
				else
				{
					t->set_value(keyWord::SMALL);
					t->set_name("<");
				}//endelse <���ʵ����� 
			}
			t->set_pos(i_lineid);
			l_tokenlist->push_back(t);
		}//endelse <��<=���ʵ�����
		else if(c_currentchar == '>')
		{
			t = new token;
			if(!f_file.eof())
			{
				c_nextchar = f_file.peek();
				if(c_nextchar == '=')
				{
					f_file.get(c_currentchar);
					t->set_value(keyWord::BIG_EQUAL);
					t->set_name(">=");
				}//endif >=���ʵ�����
				else
				{
					t->set_value(keyWord::BIG);
					t->set_name(">");
				}//endelse >���ʵ����� 
			}
			t->set_pos(i_lineid);
			l_tokenlist->push_back(t);
		}//endelse >��>=���ʵ�����
		else if(c_currentchar == '=')
		{
			t = new token;
			if(!f_file.eof())
			{
				c_nextchar = f_file.peek();
				if(c_nextchar == '=')
				{
					f_file.get(c_currentchar);
	//				f_file.get(c_currentchar);
					t->set_value(keyWord::EQUAL);
					t->set_name("==");
				}//endif ==���ʵ�����
				else
				{
					t->set_value(keyWord::GIVE);
					t->set_name("=");
				}//endelse =���ʵ����� 
			}
			t->set_pos(i_lineid);
			l_tokenlist->push_back(t);
		}//endelse =��==���ʵ�����
		else if(c_currentchar == '!')
		{
			if(!f_file.eof())
			{
				c_nextchar = f_file.peek();
				if(c_nextchar == '=')
				{
					f_file.get(c_currentchar);
					t = new token;
					t->set_value(keyWord::NOT_EQUAL);
					t->set_name("!=");
					t->set_pos(i_lineid);
					l_tokenlist->push_back(t);
				}
				else 
				{
					f_file.close();
					li_tokenhead = l_tokenlist->begin();
					li_tokentail = l_tokenlist->end();
					return i_lineid;
				}
			}
			else 
			{
				f_file.close();
				li_tokenhead = l_tokenlist->begin();
				li_tokentail = l_tokenlist->end();
				return i_lineid;
			}
		}//endelse !=���ʵ�����
		else if(c_currentchar == '/')
		{
			if(!f_file.eof())
			{
				c_nextchar = f_file.peek();
				if(c_nextchar == '*')
				{
					f_file.get(c_currentchar);
					while(f_file.get(c_currentchar))
					{
						if(c_currentchar == '*')
						{
							c_nextchar = f_file.peek();
							if(c_nextchar == '/')
							{
								f_file.get(c_currentchar);
								break;
							}
						}
						else if(c_currentchar == '\n')	i_lineid++;
					}
					if(f_file.eof() && c_currentchar != '/')	
					{
						f_file.close();
						li_tokenhead = l_tokenlist->begin();
						li_tokentail = l_tokenlist->end();
						return i_lineid;
					}
				}//endif ���˵�ע�ͷ��Լ�ע�ͷ�֮�������
				else 
				{
					t=new token;
					t->set_value(keyWord::DIVIDE);
					t->set_name("/");
					t->set_pos(i_lineid);
					l_tokenlist->push_back(t);
				}//endelse /���ʵ�����
			}
			else
			{
					t=new token;
					t->set_value(keyWord::DIVIDE);
					t->set_name("/");
					t->set_pos(i_lineid);
					l_tokenlist->push_back(t);
			}//endelse /���ʵ�����
		}//endelse /���ʵ����ɻ���˵�ע�ͷ��Լ�ע��ע�ͷ�֮�������
		else if(c_currentchar == '+')
		{
					t=new token;
					t->set_value(keyWord::PLUS);
					t->set_name("+");
					t->set_pos(i_lineid);
					l_tokenlist->push_back(t);
		}//endelse +���ʵ�����
		else if(c_currentchar == '-')
		{
					t=new token;
					t->set_value(keyWord::MINUS);
					t->set_name("-");
					t->set_pos(i_lineid);
					l_tokenlist->push_back(t);
		}//endelse -���ʵ�����
		else if(c_currentchar == '*')
		{
					t=new token;
					t->set_value(keyWord::MULTIPLY);
					t->set_name("*");
					t->set_pos(i_lineid);
					l_tokenlist->push_back(t);
		}//endelse *���ʵ�����
		else if(c_currentchar == ';')
		{
					t=new token;
					t->set_value(keyWord::SEMI);
					t->set_name(";");
					t->set_pos(i_lineid);
					l_tokenlist->push_back(t);
		}//endelse ;���ʵ�����
		else if(c_currentchar == ',')
		{
					t=new token;
					t->set_value(keyWord::COMMA);
					t->set_name(",");
					t->set_pos(i_lineid);
					l_tokenlist->push_back(t);
		}//endelse ,���ʵ�����
		else if(c_currentchar == '(')
		{
					t=new token;
					t->set_value(keyWord::LEFT_SMALL);
					t->set_name("(");
					t->set_pos(i_lineid);
					l_tokenlist->push_back(t);
		}//endelse (���ʵ�����
		else if(c_currentchar == ')')
		{
					t=new token;
					t->set_value(keyWord::RIGHT_SMALL);
					t->set_name(")");
					t->set_pos(i_lineid);
					l_tokenlist->push_back(t);
		}//endelse )���ʵ�����
		else if(c_currentchar == '[')
		{
					t=new token;
					t->set_value(keyWord::LEFT_MID);
					t->set_name("[");
					t->set_pos(i_lineid);
					l_tokenlist->push_back(t);
		}//endelse [���ʵ�����
		else if(c_currentchar == ']')
		{
					t=new token;
					t->set_value(keyWord::RIGHT_MID);
					t->set_name("]");
					t->set_pos(i_lineid);
					l_tokenlist->push_back(t);
		}//endelse ]���ʵ�����
		else if(c_currentchar == '{')
		{
					t=new token;
					t->set_value(keyWord::LEFT_BIG);
					t->set_name("{");
					t->set_pos(i_lineid);
					l_tokenlist->push_back(t);
		}//endelse {���ʵ�����
		else if(c_currentchar == '}')
		{
					t=new token;
					t->set_value(keyWord::RIGHT_BIG);
					t->set_name("}");
					t->set_pos(i_lineid);
					l_tokenlist->push_back(t);
		}//endelse }���ʵ�����
		else if(c_currentchar == ' ')
		{
		}//endelse ���˵��ո�
		else if((int)c_currentchar == 13)
		{
		}//endelse ���˵�Tab��
		else if((int)c_currentchar == 9)
		{
		}//endelse ���˵�ENTER���ĵ�һ����
		else if(c_currentchar == '\n')
		{
			i_lineid++;
		}//endelse ���˵�ENTER���ĵڶ�����
		else	
		{
			f_file.close();
			li_tokenhead = l_tokenlist->begin();
			li_tokentail = l_tokenlist->end();
			return i_lineid;
		}
	}//while �ļ�����

	f_file.close();
	t=new token;
	t->set_value(keyWord::END);
	t->set_name("#");
	t->set_pos(i_lineid);
	l_tokenlist->push_back(t);
	li_tokenhead = l_tokenlist->begin();
	li_tokentail = l_tokenlist->end();
	return 0;
}

void scanner::print_tokenlist()
{
	list<token*>::iterator i,iend;
	iend = l_tokenlist->end();
	int n=0;
	for(i = l_tokenlist->begin();i!=iend;i++)
	{

		cout<<setiosflags(ios::left);
		cout<<setw(2)<<++n<<" name:"<<setw(10)<<(*i)->get_name();
		cout<<"value:"<<setw(10)<<(*i)->get_value();
		cout<<"pos:"<<setw(10)<<(*i)->get_pos()<<endl;
	}
}

void scanner::print_lasttoken()
{
	list<token*>::reverse_iterator last;
	last = l_tokenlist->rbegin();
	cout<<(*last)->get_name();
}
scanner::~scanner()
{
	list<token*>::iterator i,iend;
	int j=0;
	iend = l_tokenlist->end();
	for(i=l_tokenlist->begin();i!=iend;i++,j++)
	{
		delete *i;
	}
	cout<<"��ɾ��"<<j<<"��token"<<endl;
}
