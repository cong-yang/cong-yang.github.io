#include <iostream>
#include "keyWord.h"
#include "signWord.h"
#include "signString.h"
#include "token.h"
#include "scanner.h"
using namespace std;

int main1()
{

	/*
	cout<<keyWord::BIG;			//���Թؼ���,������ų���;
	cout<<'\n';
	cout<<keyWord::BIG_EQUAL;
	cout<<'\n';
	cout<<keyWord::COMMA;
	cout<<'\n';
	cout<<keyWord::DIVIDE;
	cout<<'\n';
	cout<<keyWord::ELSE;
	cout<<'\n';
	cout<<keyWord::EQUAL;
	cout<<'\n';
	cout<<keyWord::GIVE;
	cout<<'\n';
	cout<<keyWord::ID;
	cout<<'\n';
	cout<<keyWord::IF;
	cout<<'\n';
	cout<<keyWord::INT;
	cout<<'\n';
	cout<<keyWord::LEFT_BIG;
	cout<<'\n';
	cout<<keyWord::LEFT_MID;
	cout<<'\n';
	cout<<keyWord::LEFT_NOTE;
	cout<<'\n';
	cout<<keyWord::LEFT_SMALL;
	cout<<'\n';
	cout<<keyWord::MINUS;
	cout<<'\n';
	cout<<keyWord::MULTIPLY;
	cout<<'\n';
	cout<<keyWord::NOT_EQUAL;
	cout<<'\n';
	cout<<keyWord::NUM;
	cout<<'\n';
	cout<<keyWord::PLUS;
	cout<<'\n';
	cout<<keyWord::RETURN;
	cout<<'\n';
	cout<<keyWord::RIGHT_BIG;
	cout<<'\n';
	cout<<keyWord::RIGHT_MID;
	cout<<'\n';
	cout<<keyWord::RIGHT_NOTE;
	cout<<'\n';
	cout<<keyWord::RIGHT_SMALL;
	cout<<'\n';
	cout<<keyWord::SEMI;
	cout<<'\n';
	cout<<keyWord::SMALL;
	cout<<'\n';
	cout<<keyWord::VOID;
	cout<<'\n';
	cout<<keyWord::WHILE;
	cout<<'\n';*/

	/*
	token t("33",keyWord::BIG,32);
	t.display();
	
	token *t1 = new token("33454",keyWord::NUM,33);
	token *t2 = new token("asfda",keyWord::ID,44);

	scanner *s = new scanner("filename");
	s->add_token(*t1);
	s->add_token(*t2);
	s->print_tokenlist();
	*/

	/*
	cout<<signWord::ADDITIVE_EXPRESSION<<endl;		//���Է��ռ�������;
	cout<<signWord::COMPOUND_STMT<<endl;
	cout<<signWord::PARAMS<<endl;
	cout<<signWord::STATEMENT_LIST<<endl;
	cout<<signWord::VAR_MORE<<endl;
	*/
	/*
	string s1 = "abc";
	string *s2 = new string("edf");
	signString ss1(s1,keyWord::BIG);				//���Է��Ŵ�;�ɹ�;
	signString ss2("efg",signWord::ADDITIVE_EXPRESSION_MORE);
	signString ss3(ss2);
	signString ss4;
	//ss4 = ss2;
	ss4.set_name("fff");
	ss4.set_name("eee");
	ss4.set_name(*ss1.get_name());
	ss4.set_value(keyWord::GIVE);
	ss4.set_value(signWord::ARG_LIST);
	ss4.convert_vt_vn();

	signString *ss5 = new signString(ss4);

	ss1.display();
	ss2.display();
	ss3.display();
	ss4.display();
	ss5->display();

	delete ss5;
	*/
	return 0;
}