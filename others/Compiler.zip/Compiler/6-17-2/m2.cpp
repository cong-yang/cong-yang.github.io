#include <iostream>
#include <vector>
#include "keyWord.h"
#include "signWord.h"
#include "signString.h"
#include "token.h"
#include "scanner.h"
#include "produce.h"
#include "BNF.h"
using namespace std;

int main2()
{

	/*
	signString ss1("big",keyWord::BIG);				//���Է��Ŵ�;
	signString ss2("additive_expression_more",signWord::ADDITIVE_EXPRESSION_MORE);
	signString ss3("addop",signWord::ADDOP);

	vector<signString> *v1 = new vector<signString>();
	v1->push_back(ss1);
	v1->push_back(ss2);
	produce p1(&ss3,v1);
	p1.display();
	
	signString *ss1 = NULL;
	signString *ss2 = NULL;
	signString *ss3 = NULL;
	signString *ss4 = NULL;
	vector<signString> *v1 = NULL;


	ss1 = new signString("program",signWord::PROGRAM);
	ss2 = new signString("declaration_list",signWord::DECLARATION_LIST);
	v1 = new vector<signString>();
	v1->push_back(*ss2);
	produce p1(ss1,v1);
	*/
	

	
	//¼�����еķ��Ŵ�,42�����ռ���;
	//1-5
	signString *ss_additive_expression = new signString("additive_expression",signWord::ADDITIVE_EXPRESSION);	
	signString *ss_additive_expression_more = new signString("additive_expression_more",signWord::ADDITIVE_EXPRESSION_MORE);
	signString *ss_addop = new signString("addop",signWord::ADDOP);
	signString *ss_arg_list = new signString("arg_list",signWord::ARG_LIST);
	signString *ss_arg_list_more = new signString("arg_list_more",signWord::ARG_LIST_MORE);
	//6-10
	signString *ss_args = new signString("args",signWord::ARGS);		
	signString *ss_compound_stmt = new signString("compound_stmt",signWord::COMPOUND_STMT);
	signString *ss_declaration = new signString("declaration",signWord::DECLARATION);
	signString *ss_declaration_list = new signString("declaration_list",signWord::DECLARATION_LIST);
	signString *ss_declaration_more = new signString("declaration_more",signWord::DECLARATION_MORE);
	//11-15
	signString *ss_declaration_type = new signString("declaration_type",signWord::DECLARATION_TYPE);		
	signString *ss_expression = new signString("expression",signWord::EXPRESSION);
	signString *ss_expression_stmt = new signString("expression_stmt",signWord::EXPRESSION_STMT);
	signString *ss_factor = new signString("factor",signWord::FACTOR);
	signString *ss_factor_more = new signString("factor_more",signWord::FACTOR_MORE);
	//16-20
	signString *ss_id_mm = new signString("id_mm",signWord::ID_MM);
	signString *ss_id_more = new signString("id_more",signWord::ID_MORE);
	signString *ss_iteration_stmt = new signString("iteration_stmt",signWord::ITERATION_STMT);
	signString *ss_local_declarations = new signString("local_declarations",signWord::LOCAL_DECLARATIONS);
	signString *ss_mulop = new signString("mulop",signWord::MULOP);
	//21-25
	signString *ss_param = new signString("param",signWord::PARAM);
	signString *ss_param_list_more = new signString("param_list_more",signWord::PARAM_LIST_MORE);
	signString *ss_param_more = new signString("param_more",signWord::PARAM_MORE);
	signString *ss_params = new signString("params",signWord::PARAMS);
	signString *ss_params_more = new signString("params_more",signWord::PARAMS_MORE);
	//26-30
	signString *ss_program = new signString("program",signWord::PROGRAM);
	signString *ss_relop = new signString("relop",signWord::RELOP);
	signString *ss_return_stmt = new signString("return_stmt",signWord::RETURN_STMT);
	signString *ss_return_stmt_more = new signString("return_stmt_more",signWord::RETURN_STMT_MORE);
	signString *ss_selection_stmt = new signString("selection_stmt",signWord::SELECTION_STMT);
	//31-35
	signString *ss_selection_stmt_more = new signString("selection_stmt_more",signWord::SELECTION_STMT_MORE);
	signString *ss_simple_expression_more = new signString("simple_expression_more",signWord::SIMPLE_EXPRESSION_MORE);
	signString *ss_statement = new signString("statement",signWord::STATEMENT);
	signString *ss_statement_list = new signString("statement_list",signWord::STATEMENT_LIST);
	signString *ss_term = new signString("term",signWord::TERM);
	//36-40
	signString *ss_term_more = new signString("term_more",signWord::TERM_MORE);
	signString *ss_type_specifier = new signString("type_specifier",signWord::TYPE_SPECIFIER);
	signString *ss_type_specifier_var = new signString("type_specifier_var",signWord::TYPE_SPECIFIER_VAR);
	signString *ss_var = new signString("var",signWord::VAR);
	signString *ss_var_declaration = new signString("var_declaration",signWord::VAR_DECLARATION);
	//41-42
	signString *ss_var_declaration_more = new signString("var_declaration_more",signWord::VAR_DECLARATION_MORE);
	signString *ss_var_more = new signString("var_more",signWord::VAR_MORE);

	//29���ռ���;
	//1-5
	signString *ss_big = new signString(">",keyWord::BIG);
	signString *ss_big_equal = new signString(">=",keyWord::BIG_EQUAL);
	signString *ss_comma = new signString(",",keyWord::COMMA);
	signString *ss_divide = new signString("/",keyWord::DIVIDE);
	signString *ss_else = new signString("else",keyWord::ELSE);
	
	//6-10
	signString *ss_equal = new signString("==",keyWord::EQUAL);
	signString *ss_give = new signString("=",keyWord::GIVE);
	signString *ss_id = new signString("ID",keyWord::ID);
	signString *ss_if = new signString("if",keyWord::IF);
	signString *ss_int = new signString("int",keyWord::INT);
	
	//11-15
	signString *ss_left_big = new signString("{",keyWord::LEFT_BIG);
	signString *ss_left_mid = new signString("[",keyWord::LEFT_MID);
	signString *ss_left_note = new signString("/*",keyWord::LEFT_NOTE);
	signString *ss_left_small = new signString("(",keyWord::LEFT_SMALL);
	signString *ss_minus = new signString("-",keyWord::MINUS);
	
	//16-20
	signString *ss_multiply = new signString("*",keyWord::MULTIPLY);
	signString *ss_not_equal = new signString("!=",keyWord::NOT_EQUAL);
	signString *ss_num = new signString("NUM",keyWord::NUM);
	signString *ss_plus = new signString("+",keyWord::PLUS);
	signString *ss_return = new signString("return",keyWord::RETURN);
	
	//21-25
	signString *ss_right_big = new signString("}",keyWord::RIGHT_BIG);
	signString *ss_right_mid = new signString("]",keyWord::RIGHT_MID);
	signString *ss_right_note = new signString("*/",keyWord::RIGHT_NOTE);
	signString *ss_right_small = new signString(")",keyWord::RIGHT_SMALL);
	signString *ss_semi = new signString(";",keyWord::SEMI);
	
	//26-29
	signString *ss_small = new signString("<",keyWord::SMALL);
	signString *ss_small_equal = new signString("<=",keyWord::SMALL_EQUAL);
	signString *ss_void = new signString("void",keyWord::VOID);
	signString *ss_while = new signString("while",keyWord::WHILE);
	
	vector<signString*> *v1 = new vector<signString*>;
	v1->push_back(ss_additive_expression);
	v1->push_back(ss_additive_expression_more);
	
	vector<signString*> *v2 = new vector<signString*>;
	v2->push_back(ss_small);
	v2->push_back(ss_small_equal);


	return 0;
}