// expNode.cpp: implementation of the expNode class.
//
//////////////////////////////////////////////////////////////////////

#include "expNode.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

expNode::expNode(int line_no,int node_type,string name,basicType *return_type):nodeBase(line_no,node_type,name),return_type(return_type)
{

}

basicType * expNode::get_return_type()
{
	return return_type;
}

void expNode::display()
{
	cout<<"expNode:"<<line_no<<"\t"<<node_type<<"\t"<<name<<endl;
	return_type->display();
}

expNode::~expNode()
{

}
