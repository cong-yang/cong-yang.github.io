// symbolTableParam.h: interface for the symbolTableParam class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_symbolTableParam_H__226035B2_9ABC_44B8_9736_5ECB011CC513__INCLUDED_)
#define AFX_symbolTableParam_H__226035B2_9ABC_44B8_9736_5ECB011CC513__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "treeNode.h"
#include <vector>
#include "symbolRecordParam.h"

class symbolTableParam  
{
private:
	vector<symbolRecordParam*> v_st;

public:
	symbolTableParam();
	
	vector<symbolRecordParam*> *get_v_st();
	void insert_param(symbolRecordParam* srp);//���ββ��뵽���ű����У�
	int find_param(string proc_name);//�����β��ڷ��ű����е�λ�ã�

	virtual ~symbolTableParam();

};

#endif // !defined(AFX_symbolTableParam_H__226035B2_9ABC_44B8_9736_5ECB011CC513__INCLUDED_)
