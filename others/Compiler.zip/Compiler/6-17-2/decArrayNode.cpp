// decArrayNode.cpp: implementation of the decArrayNode class.
//
//////////////////////////////////////////////////////////////////////

#include "decArrayNode.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

decArrayNode::decArrayNode(int line_no,int node_type,string name,basicType *return_type,int size):decNode(line_no,node_type,name,return_type),size(size)
{

}
void decArrayNode::display()
{
	cout<<"decArrayNode:"<<line_no<<"\t"<<node_type<<"\t"<<name<<endl;
	return_type->display();	
	cout<<"array size:"<<size<<endl;
}
decArrayNode::~decArrayNode()
{

}
