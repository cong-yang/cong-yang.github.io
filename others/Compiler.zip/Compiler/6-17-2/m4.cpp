#include "parser.h"
#include "scanner.h"
#include "semanticAnalyzer.h"
#include "tm.h"

int main()
{
	scanner *s = new scanner();
	parser *p = new parser(s->get_token());
	semanticAnalyzer *sa = new semanticAnalyzer(p->get_parse_tree());
	delete sa;
	delete p;
	delete s;

	char filename[20] = "code.tm"; 
	tmain(filename);
	return 0;


}