// nodeBase.cpp: implementation of the nodeBase class.
//
//////////////////////////////////////////////////////////////////////

#include "nodeBase.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

nodeBase::nodeBase(int line_no,int node_type,string name)
{
	this->line_no = line_no;
	this->node_type = node_type;
	this->name = name;
}

int nodeBase::get_line_no()
{
	return this->line_no;
}

int nodeBase::get_node_type()
{
	return this->node_type;
}

string nodeBase::get_name()
{
	return this->name;
}

void nodeBase::display()
{
	cout<<"nodeBase:"<<line_no<<"\t"<<node_type<<"\t"<<name<<endl;
}

nodeBase::~nodeBase()
{

}
