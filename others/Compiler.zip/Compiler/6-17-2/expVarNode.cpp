// expVarNode.cpp: implementation of the expVarNode class.
//
//////////////////////////////////////////////////////////////////////

#include "expVarNode.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

expVarNode::expVarNode(int line_no,int node_type,string name,basicType *return_type):expNode(line_no,node_type,name,return_type)
{

}

void expVarNode::display()
{

	cout<<"decNode:"<<line_no<<"\t"<<node_type<<"\t"<<name<<"\t"<<endl;
	return_type->display();
}

expVarNode::~expVarNode()
{

}
