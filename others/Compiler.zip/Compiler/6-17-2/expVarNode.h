// expVarNode.h: interface for the expVarNode class.
// ��������������Ϊ����ʽ�ı����ͳ���;
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EXPVARNODE_H__AA2C46A8_FD9B_4B1F_82BE_3DE90E480D9F__INCLUDED_)
#define AFX_EXPVARNODE_H__AA2C46A8_FD9B_4B1F_82BE_3DE90E480D9F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "expNode.h"
#include <iostream>

class expVarNode:public expNode
{
private:
	//���ű���ڵ�ַ;

public:
	expVarNode(int line_no,int node_type,string name,basicType *return_type);
	void display();
	virtual ~expVarNode();

};

#endif // !defined(AFX_EXPVARNODE_H__AA2C46A8_FD9B_4B1F_82BE_3DE90E480D9F__INCLUDED_)
