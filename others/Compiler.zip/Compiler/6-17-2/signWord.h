// signWord.h: interface for the signWord class.
// �����ˣ�liaoying
// ����ʱ�䣺2008_3_18
// �����������ռ�������;
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SIGNWORD_H__C8FBE020_E157_4F0E_996F_1F04CC5CBAB6__INCLUDED_)
#define AFX_SIGNWORD_H__C8FBE020_E157_4F0E_996F_1F04CC5CBAB6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class signWord  
{
public:
	signWord();
	virtual ~signWord();
	
	static bool is_ileagl(int v);		//�ж�����������v�Ƿ����ڷ��ռ������뷶Χ��;

	static int	PROGRAM ,	
		DECLARATION_LIST,			
		DECLARATION_MORE,			
		DECLARATION ,			
		DECLARATION_TYPE,		
		TYPE_SPECIFIER_VAR,			
		TYPE_SPECIFIER,			
		PARAMS ,			
		PARAMS_MORE,		
		PARAM_LIST_MORE,		
		PARAM ,			
		PARAM_MORE,	
		COMPOUND_STMT,			
		LOCAL_DECLARATIONS,		
		VAR_DECLARATION,			
		VAR_DECLARATION_MORE,	
		STATEMENT_LIST,			
		STATEMENT ,			
		EXPRESSION_STMT,		
		SELECTION_STMT,		
		SELECTION_STMT_MORE,	
		ITERATION_STMT,		
		RETURN_STMT,	
		RETURN_STMT_MORE,		
		EXPRESSION,		
		ID_MORE ,		
		ID_MM,		
		VAR,				
		VAR_MORE,
		SIMPLE_EXPRESSION_MORE,		
		RELOP ,				
		ADDITIVE_EXPRESSION,
		ADDITIVE_EXPRESSION_MORE,		
		ADDOP,
		TERM,
		TERM_MORE,		
		MULOP,				
		FACTOR,	
		FACTOR_MORE,
		ARGS,			
		ARG_LIST,		
		ARG_LIST_MORE;
};


#endif // !defined(AFX_SIGNWORD_H__C8FBE020_E157_4F0E_996F_1F04CC5CBAB6__INCLUDED_)
