// signWord.cpp: implementation of the signWord class.
//
//////////////////////////////////////////////////////////////////////

#include "signWord.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

signWord::signWord()
{

}


//�����з��ռ�������;
int signWord::ADDITIVE_EXPRESSION		= 101;
int signWord::ADDITIVE_EXPRESSION_MORE	= 102;
int signWord::ADDOP						= 103;
int signWord::ARG_LIST					= 104;
int signWord::ARG_LIST_MORE				= 105;
int signWord::ARGS						= 106;
int signWord::COMPOUND_STMT				= 107;
int signWord::DECLARATION				= 108;
int signWord::DECLARATION_LIST			= 109;
int signWord::DECLARATION_MORE			= 110;
int signWord::DECLARATION_TYPE			= 111;
int signWord::EXPRESSION				= 112;
int signWord::EXPRESSION_STMT			= 113;
int signWord::FACTOR					= 114;
int signWord::FACTOR_MORE				= 115;
int signWord::ID_MM						= 116;
int signWord::ID_MORE					= 117;
int signWord::ITERATION_STMT			= 118;
int signWord::LOCAL_DECLARATIONS		= 119;
int signWord::MULOP						= 120;
int signWord::PARAM						= 121;
int signWord::PARAM_LIST_MORE			= 122;
int signWord::PARAM_MORE				= 123;
int signWord::PARAMS					= 124;
int signWord::PARAMS_MORE				= 125;
int signWord::PROGRAM					= 126;
int signWord::RELOP						= 127;
int signWord::RETURN_STMT				= 128;
int signWord::RETURN_STMT_MORE			= 129;
int signWord::SELECTION_STMT			= 130;
int signWord::SELECTION_STMT_MORE		= 131;
int signWord::SIMPLE_EXPRESSION_MORE	= 132;
int signWord::STATEMENT					= 133;
int signWord::STATEMENT_LIST			= 134;
int signWord::TERM						= 135;
int signWord::TERM_MORE					= 136;
int signWord::TYPE_SPECIFIER			= 137;
int signWord::TYPE_SPECIFIER_VAR		= 138;
int signWord::VAR						= 139;
int signWord::VAR_DECLARATION			= 140;
int signWord::VAR_DECLARATION_MORE		= 141;
int signWord::VAR_MORE					= 142;


bool signWord::is_ileagl(int v)			//�ж�����������v�Ƿ����ڷ��ռ������뷶Χ��;
{
	if(v >= signWord::ADDITIVE_EXPRESSION && v <= signWord::VAR_MORE)
	{
		return true;
	}
	return false;
}


signWord::~signWord()
{

}
