// syntaxTree.cpp: implementation of the syntaxTree class.
//
//////////////////////////////////////////////////////////////////////

#include "syntaxTree.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

syntaxTree::syntaxTree()
{
	this->root = NULL;
}

void syntaxTree::set_root(treeNode *root)
{
	this->root = root;
	this->root->set_level(1);
	nodeNum++;
}

treeNode *syntaxTree::get_root()
{
	return this->root;
}

void syntaxTree::set_nodeNum(int nodeNum)
{
	this->nodeNum = nodeNum;
}

int syntaxTree::get_nodeNum()
{
	return this->nodeNum;
}

void syntaxTree::add_treeNode(treeNode *parent,treeNode *node)
{
	if(parent->get_child() != NULL)
		parent->get_child()->push_back(node);
	else
	{
		vector<treeNode*> *child = new vector<treeNode*>();
		parent->set_child(child);
		parent->get_child()->push_back(node);
	}
	node->set_level(parent->get_level()+1);
	node->set_parent(parent);
	nodeNum++;
	vector<treeNode*>::iterator i,iend;
	if(node->get_child() != NULL)
	{
		iend = node->get_child()->end();
		for(i = node->get_child()->begin();i != iend;i++)
		{
			(*i)->set_level(node->get_level()+1);
		}
	}
}

void syntaxTree::display_syntaxTree()
{
	this->display_treeNode(root);
}

void syntaxTree::display_treeNode(treeNode *node)
{
	vector<treeNode*>::iterator i,iend;
	int j;
	for(j = 0;j < 3*(node->get_level());j++)//��ӡ�����ո��ӡ�ո��������ڵ����ڵĲ�γ����ȣ�
		cout<<' ';
	node->display();//���ȴ�ӡ�ڵ㱾����
	cout<<endl;
	if(node->get_child() != NULL)
	{
		iend = node->get_child()->end();
		for(i = node->get_child()->begin();i != iend;i++)//Ȼ���ӡ���ӽ��
		{
			this->display_treeNode(*i);
		}
	}
}

syntaxTree::~syntaxTree()
{
	//ɾ�������﷨���ڵ�;
}














